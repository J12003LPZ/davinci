# Wave 2: system prompt and behavioral context assembly

Scope: published npm `@anthropic-ai/claude-code` **2.1.80** only. Primary source is `/workspace/research/claude-davinci/artifacts/claude-2.1.80/cli.js` (SHA256 `0b146fe609bd591feb8e6ba689d146b56265076c9c23cee1a351cd2df74b4ec1`). All line spans below refer to the mechanically formatted `cli.pretty.js` in that same directory, counted with literal LF splitting. Original minified identifiers are preserved. `evidence/prompt/source_index.json` records unique raw-source needles, zero-based byte offsets and LF spans; `function_*.js` and numbered `lines_*.txt` are bounded source excerpts. No DaVinci files were changed and no credentials were read. Source strings are implementation evidence for instructions sent to a model, not proof the model obeys them. None of this establishes parity with the native 2.1.302 binary.

## End-to-end state map

```text
CLI flags / settings / agent selection
  -> interactive: HX(default sections), kz(user context), i2(system context)
       -> qS(main agent > custom > default, then append; override wins outright)
  -> headless: CLI optional custom-agent substitution -> lN_ -> iN_ -> mFq -> uFq.submitMessage
       -> typeof-custom-string ? custom (+ optional cowork memory) : HX
       -> append; custom-string suppresses i2, does not suppress kz
  -> th -> zgY: active history + attachments / compaction
       -> systemPrompt = iq(MYq(prompt, systemContext))
       -> messages = qR8(activeHistory, userContext)
  -> uZ6 -> $Eq:
       tool availability -> tool.prompt()/JSON schema -> tools
       normalize messages; pair tool results; bound media
       prepend attribution + identity; optional deferred-tool instructions
       Is1 grouping -> l$_ text blocks/cache annotations -> system
       c$_ message conversion/cache annotations -> messages
       -> request {model, system, messages, tools, ...}
       -> optional CLAUDE_CODE_EXTRA_BODY override -> provider SDK
```

These arrows describe source transitions. Their execution depends on the specified path and gates; they are not a claim that every branch ran.

## Findings

### PROMPT-01 — prompt precedence differs between interactive and headless execution

**Label: source-verified.** `qS` (LF 463201–463222; raw byte 9534362) Descriptive excerpt **sdk_prompt** (actual identifier(s): `uFq.submitMessage`; LF 606648–606785; raw byte 12204876) Descriptive excerpt **headless_agent** (actual identifier(s): `_E_ anonymous CLI action callback`; LF 613487–613525; raw byte 12337187) Descriptive excerpt **headless_dispatch** (actual identifier(s): `_E_ anonymous CLI action callback`; LF 613853–613887; raw byte 12343950) Descriptive excerpt **headless_submit** (actual identifier(s): `iN_ request-processing callback`; LF 608260–608300; raw byte 12233050) Descriptive excerpt **sdk_factory** (actual identifier(s): `mFq`; LF 607245–607308; raw byte 12215811) Descriptive excerpt **main_prompt** (actual identifier(s): `n6A interactive submission callback`; LF 590749–590790; raw byte 11772464)

Interactive submission at 590749–590790 concurrently resolves `HX`, `kz`, and `i2`, invokes `qS`, stores the result in `qK.renderedSystemPrompt`, then passes system/user/system-context separately to `th`. `qS` returns `[overrideSystemPrompt]` immediately when that value is truthy. Otherwise it obtains `mainThreadAgentDefinition.getSystemPrompt` (a built-in definition receives `{toolUseContext:{options:q.options}}`) and chooses **truthy agent prompt, else truthy customSystemPrompt, else defaultSystemPrompt**. A truthy append is added after the selected base. The override branch bypasses append. `iq` is an identity function, not a renderer, sanitizer, or policy layer (`iq` (LF 266184–266186; raw byte 5430361)).

The CLI headless path first selects `D4` from `--agent` or `hA().agent` and, only when noninteractive `f6`, `D4` exists, `!y6`, and `!xO(D4)` (not built-in), fills the absent custom prompt with `D4.getSystemPrompt()`. It passes `y6` and `v6` to `runHeadless`, whose actual exported identifier is `lN_`; it iterates `iN_`, whose request-processing callback calls `mFq` with `j.systemPrompt` and `j.appendSystemPrompt`. `mFq` creates class `uFq` and calls `submitMessage`. Actual driver declarations: `lN_` (LF 607569–607835; raw byte 12220681), `iN_` (LF 607836–609361; raw byte 12225301), `mFq` (LF 607244–607308; raw byte 12215817).

`uFq.submitMessage` uses **`typeof J === 'string'`**, not truthiness, to choose `[J]` instead of `HX` defaults and to replace `i2()` with `{}`. It still obtains `kz()`. It then inserts conditional cowork memory `d`, followed by truthy append `M`. `d` requires both a custom string and `G48()`; `G48` tests whether `oPA` accepts `CLAUDE_COWORK_MEMORY_PATH_OVERRIDE` as a valid path (`G48` (LF 49285–49287; raw byte 948421) `oPA` (LF 49274–49276; raw byte 948140)). Thus custom replacement does not universally preserve the default memory-instruction section, and it does not universally remove CLAUDE.md/currentDate user context. An empty string is an actual replacement on this SDK path but falls through in `qS`; a nonempty explicit custom headless prompt prevents the CLI's custom-agent substitution. This distinction must survive any reconstruction.

### PROMPT-02 — prompt files are CLI input alternatives, and custom replacement still receives wire-level headers

**Label: source-verified.** Descriptive excerpt **cli_prompt_flags** (actual identifier(s): `_E_ CLI option-registration statements`; LF 612845–612882; raw byte 12322677) Descriptive excerpt **cli_prompt_read** (actual identifier(s): `_E_ anonymous CLI action callback`; LF 613175–613242; raw byte 12329913) `TH8` (LF 180823–180830; raw byte 3732831) `kH8` (LF 180835–180844; raw byte 3733076) `$Eq` (LF 545840–546686; raw byte 11019955)

CLI flags include `--system-prompt`, hidden `--system-prompt-file`, `--append-system-prompt`, and hidden `--append-system-prompt-file`. The action reads file contents as UTF-8 using `Xt6` plus `mUq`. A truthy literal prompt together with its file alternative prints an error and exits 1; missing/unreadable files likewise exit. These are programmatic checks. File content is later subject to the precedence in PROMPT-01. When the team gate and teammate identity fields are present, `TEAMMATE_SYSTEM_PROMPT_ADDENDUM` is appended to `v6` before later assembly.

At 545944–545955 `$Eq` prepends `kH8(E)` attribution and `TH8(...)` identity to whichever application prompt was selected. `TH8` returns the ordinary official-CLI identity on Vertex or interactive calls; for noninteractive calls it chooses the official-CLI-with-SDK identity when `hasAppendSystemPrompt` is true and the Claude-agent-built-on-SDK identity otherwise. `kH8` can be disabled by `CLAUDE_CODE_ATTRIBUTION_HEADER` false or its feature gate; otherwise it emits the `x-anthropic-billing-header` string. Therefore `--system-prompt` replaces an application prompt, not the complete eventual wire `system` array. These identity strings are also recognized specially during cache grouping.

### PROMPT-03 — the default prompt is modular and partly memoized; its “dynamic” boundary is for request grouping

**Label: source-verified.** `HX` (LF 304166–304209; raw byte 6613169) `Zg` (LF 265218–265220; raw byte 5411730) `b94` (LF 265221–265223; raw byte 5411786) `x94` (LF 265224–265233; raw byte 5411851) `WX4` (LF 542326–542342; raw byte 10937821) `JX4` (LF 304254–304297; raw byte 6614894) `MX4` (LF 304298–304307; raw byte 6616058)

`HX(tools,model,additionalWorkingDirectories,mcpClients)` early returns one minimal identity/CWD/date string when `CLAUDE_CODE_SIMPLE` is truthy. Otherwise it resolves `vh(cwd)` skills, `WX4()` output style, and `JX4(model,dirs)`, obtains `hA()` settings and actual tool names, then assembles sections in this order:

1. `Ii9` interactive-engineering identity plus authorization/security text and URL caution;
2. `bi9` system/tool-permission/hook/context instructions;
3. `xi9` doing-tasks instructions, omitted when a non-default style lacks `keepCodingInstructions:true`;
4. `ui9` actions/reversibility/user-confirmation guidance;
5. `mi9` tool-use and delegation guidance conditional on available tool names and skills;
6. `Fi9` tone/style and `pi9` output efficiency;
7. optional literal `MY6 = '__SYSTEM_PROMPT_DYNAMIC_BOUNDARY__'`;
8. computed memory, model-override, environment, language, output-style, MCP-instructions, scratchpad, FRC, tool-result-summary and brief sections, filtering only `null` values.

`Zg` marks a section `cacheBreak:false`; `x94` reuses the global section-map entry by **section name** when present, else computes/stores it. `b94` marks `cacheBreak:true`; MCP instructions use it because connections can change between turns. The marker is inserted if `CLAUDE_CODE_FORCE_GLOBAL_CACHE` or `tengu_system_prompt_global_cache` is true. “Dynamic” sections are still often memoized: boundary position and recomputation policy are separate mechanisms. `JX4` inserts cwd, Git/worktree state, extra dirs, platform/shell/OS, model name/exact ID, conditional model-specific knowledge cutoff and fast-mode explanation. `WX4` prefers the first forced plugin style, otherwise configured style/default. `hi9` reads language from settings. Nothing here establishes live feature-flag values.

### PROMPT-04 — the software-engineering/action/tool guidance is model instruction text

**Label: source-verified.** `Ii9` (LF 304030–304036; raw byte 6599821) `bi9` (LF 304037–304048; raw byte 6600339) `xi9` (LF 304049–304077; raw byte 6601761) `ui9` (LF 304078–304090; raw byte 6605453) `mi9` (LF 304091–304131; raw byte 6608309) `Bi9` (LF 304132–304136; raw byte 6610925) `Fi9` (LF 304154–304165; raw byte 6612567) `pi9` (LF 304140–304153; raw byte 6611811)

The default text tells the model to read code before modifying it, act on engineering requests in the current repository, avoid scope expansion/overengineering, consider reversibility, obtain confirmation for risky/shared actions unless authorized, adapt after denied tool calls, prefer dedicated filesystem/search tools, parallelize independent tool calls, use specialized agents judiciously and avoid duplicating their work. The main prompt also describes system-reminder tags, potential prompt injection in tool results, user hooks and conversation compression. Available `TodoWrite`/`Agent`/`Skill`-named tools and `T$()` alter portions of `mi9`/`Bi9`.

Transition: section-building returns strings -> `$Eq` sends strings -> a model may follow them. These functions do **not** dispatch tools, enforce a permission result, confirm an action, validate task success, or guarantee infinite effective memory. The compression sentence must be read alongside actual bounded compaction/recovery source (Wave 1 CTX claims); the instruction is not a context-retention guarantee. Literal `i94` at 265665–265666 contains the authorization-oriented security text interpolated by `Ii9`; its unique raw anchor is retained through the complete `Ii9` interpolation and actual bundle constant, rather than treating this report's paraphrase as runtime policy.

### PROMPT-05 — CLAUDE.md and date enter a meta user message; Git snapshot enters the system suffix

**Label: source-verified.** Descriptive excerpt **context_callbacks** (actual identifier(s): `nV1, i2, kz memoized callbacks`; LF 263527–263637; raw byte 5367253) `MYq` (LF 545308–545314; raw byte 11011042) `qR8` (LF 545315–545334; raw byte 11011144) Descriptive excerpt **model_call** (actual identifier(s): `zgY`; LF 450413–450423; raw byte 9296074) `zgY` (LF 450352–450945; raw byte 9294729) `LcY` (LF 465706–465712; raw byte 9588049)

Memoized `kz` computes `FV1(await hO())`, except when **any nonempty** `CLAUDE_CODE_DISABLE_CLAUDE_MDS` or truthy simple mode disables it. Its result is `{claudeMd:...}` when nonempty plus `currentDate: "Today's date is ..."`. Memoized `i2` returns `{gitStatus:...}` when not remote and `u08()` permits Git instructions. The memoized Git helper `nV1` checks repository state and gathers branch, main branch, short status (truncated after 40,000 characters) and five commits; the text explicitly calls it a conversation-start snapshot. It is not refreshed by every model turn.

`zgY` builds `d=iq(MYq(K,_))`: `MYq` appends joined `key: value` system-context entries. It sends `qR8(I,Y)` as messages. `qR8` prepends a meta **user** `<system-reminder>` with `# claudeMd`/`# currentDate` sections and relevance instructions; model-message normalization may subsequently merge adjacent user messages. A CLI/internal object called “userContext” or “system-reminder” does not acquire API system role. `LcY` notices a date change and clears `kz`'s memoized result before injecting a date-change attachment. Compaction and other reset paths can invalidate caches too (Wave 1 CTX-06); this is different from every-turn re-reading.

### PROMPT-06 — project/user/managed memory selection is source-gated, recursive and ordered

**Label: source-verified.** Descriptive excerpt **memory_loader** (actual identifier(s): `hO and FV1 callbacks`; LF 263204–263517; raw byte 5364520) `MB` (LF 176340–176358; raw byte 3639677) `gH` (LF 45941–45943; raw byte 869405) `XE` (LF 263011–263029; raw byte 5359199) `CI9` (LF 262946–262982; raw byte 5358054) `bI9` (LF 262983–262992; raw byte 5358653) `de` (LF 263030–263083; raw byte 5359569) `B34` (LF 262893–262920; raw byte 5357069)

`hO` is a memoized callback (263382–263505). Its order is managed CLAUDE.md and unconditional managed rules; user CLAUDE.md/user rules if `gH('userSettings')`; then ancestors from outermost to cwd, with project CLAUDE.md, `.claude/CLAUDE.md`, unconditional `.claude/rules`, followed by `CLAUDE.local.md` under their respective setting-source gates. A Git/common-dir/worktree check can suppress project files in the ancestors between common and worktree roots. Explicitly enabled `CLAUDE_CODE_ADDITIONAL_DIRECTORIES_CLAUDE_MD` adds the additional-directory project files/rules. Enabled auto-memory and team-memory entrypoints follow. `MB` maps these types to concrete locations; `gH` tests the active settings-source set plus always-included policy/flag sources.

`XE(path,type,processedPaths,includeExternal,depth,parent)` stops on a normalized path already processed, configured exclusion, or `depth>=II9` (`II9=5`). It resolves symlinks/deduplicates targets, parses content and recursively follows Markdown `@include`s; `CI9` ignores code/code-span tokens, removes fragments and resolves paths relative to the including file. Paths outside the project (`u34`) require `includeExternal`; user memory calls deliberately pass true. `bI9` applies `claudeMdExcludes` only to User/Project/Local types, not Managed. `de` recursively scans `.md` rules, tracks visited dirs including symlinks, and separates conditional rules from unconditional rules. `B34` strips frontmatter/path conditions and standalone HTML comments and imposes 200-line truncation only for AutoMem/TeamMem here; `Jg=40000` is large-file classification, not a blanket project-file truncation in `XE`.

`FV1` (263209–263245, in the memory-loader excerpt) labels provenance and joins contents below `LI9`, whose instruction says these override default behavior. `tengu_paper_halyard` skips Project/Local contents. That instruction is a priority request to the model, not a JavaScript conflict-resolution engine. The result's actual role remains the meta user context in PROMPT-05.

### PROMPT-07 — workspace trust and external memory includes are distinct gates

**Label: source-verified.** `d_` (LF 175879–175881; raw byte 3631563) `Na3` (LF 175882–175895; raw byte 3631596) `xBq` (LF 595070–595191; raw byte 11844043) `XT_` (LF 594631–594633; raw byte 11836865) `sV_` (LF 612477–612484; raw byte 12313604) Descriptive excerpt **trust_cli_help** (actual identifier(s): `_E_ CLI option-registration statements`; LF 612711–612727; raw byte 12319106) `cV1` (LF 263174–263182; raw byte 5362027) `Ef6` (LF 263164–263170; raw byte 5361852) `trY` (LF 477691–477697; raw byte 9791876) `erY` (LF 477698–477704; raw byte 9791987) `XE` (LF 263011–263029; raw byte 5359199)

`d_` caches acceptance through `Na3`, which accepts an internal bypass `J$6()` or a saved trusted project/ancestor. Interactive `xBq` awaits `TrustDialog` when untrusted, then enables trusted operation/context and separately checks `cV1` for external CLAUDE.md includes. Acceptance persists `hasTrustDialogAccepted:true` through `XT_`. `sV_` prefetches `i2` for noninteractive mode or an accepted workspace; otherwise it skips that system-context prefetch. CLI help explicitly says print mode skips the workspace-trust dialog. These are runtime/UI checks, not merely prompt caution strings.

`hO` itself does not test `d_`; it uses the source gates described above and separate `hasClaudeMdExternalIncludesApproved`. `cV1` discovers candidate external includes via `hO(true)` unless approval/warning-shown already exists; `trY` sets external approval and warning-shown true, `erY` sets approval false but warning-shown true. Normal `hO` passes saved approval to recursive includes. Therefore neither “all project instructions require the interactive trust dialog on every invocation” nor “workspace trust approves every arbitrary external include” follows from the source. Specific helper/hook execution gates remain separate (Wave 1 tools report). No experiment here supplies end-to-end guarantees for every trust bypass or mode.

### PROMPT-08 — memory guidance and remembered content can occupy different channels

**Label: source-verified.** `c5` (LF 49235–49247; raw byte 947407) `C08` (LF 262758–262801; raw byte 5354266) `B34` (LF 262893–262920; raw byte 5357069) `VY6` (LF 313213–313238; raw byte 6800593) `R34` (LF 262516–262585; raw byte 5344172) `S34` (LF 262655–262692; raw byte 5350845) `hzq` (LF 462919–462963; raw byte 9528961) `Szq` (LF 462975–463100; raw byte 9530212)

`c5` disables auto memory for a truthy `CLAUDE_CODE_DISABLE_AUTO_MEMORY`; explicit false enables it; remote mode without a remote memory directory disables it; then `autoMemoryEnabled` settings apply, else true. `C08` selects auto/team/co-work memory **guidance** according to gates such as `tengu_swinburne_dune` and `tengu_passport_quail`; `HX` adds it as a cached system section. Ordinary auto `MEMORY.md` **content** is separately read in `hO`, processed with a 200-line bound and delivered by `kz`/`qR8`. Thus this release must not be described as putting all memory contents into the API system prompt.

Custom agent parsing (`hzq` JSON, `Szq` file frontmatter) creates `getSystemPrompt` closures that, when `c5()` and agent memory scope are set, append `VY6(agentType,scope)` to the agent's prompt. `VY6` prepares the agent memory directory and chooses `R34` or typed `S34`; these helpers read the agent's MEMORY.md and include up to 200 lines alongside memory instructions. With an explicit tool allowlist, parser code also adds Read/Write/Edit tools for enabled agent memory. This is an actual configuration mutation, distinct from merely telling a model to save memories. Scopes are user/project/local; no conclusion is drawn about memory correctness or model compliance.

### PROMPT-09 — per-turn attachments add scoped instructions without replacing the base system prompt

**Label: source-verified.** `XcY` (LF 465402–465487; raw byte 9582295) `FcY` (LF 466000–466013; raw byte 9593646) `jwq` (LF 465821–465847; raw byte 9590155) `Al1` (LF 465784–465820; raw byte 9589621) `QV1` (LF 263117–263143; raw byte 5360985) `VU6` (LF 263148–263163; raw byte 5361578) Descriptive excerpt **attachment_expansion** (actual identifier(s): `nc1`; LF 544126–544255; raw byte 10984956) `Q5` (LF 543729–543745; raw byte 10967221) `hcY` (LF 465737–465741; raw byte 9588682) `HZ8` (LF 465729–465736; raw byte 9588493)

`XcY` returns no attachments for `CLAUDE_CODE_DISABLE_ATTACHMENTS` or simple mode. Otherwise it collects date/ultrathink/deferred-tool/MCP deltas, changed files, nested memory, dynamic skills/skill listings, plan-mode and task reminders, team/agent messages and critical system reminders; a separate main-thread-only set adds IDE/output-style/diagnostic/task/token/budget/queued-command context. The wrapper uses an abort controller and 1,000 ms timer, so static availability is not proof every producer completes.

`szq` (LF 464569–464743; raw byte 9559375) adds successfully read text/notebook/image paths to `nestedMemoryAttachmentTriggers`. The Read tool `I9.call` also discovers nested skill directories using `QT6`, stores `dynamicSkillDirTriggers`, and initiates `dT6`/`cT6` discovery (descriptive excerpt **read_skill_triggers**, actual `I9.call`; LF 465049–465082; raw byte 9570021). `FcY` drains `nestedMemoryAttachmentTriggers`; `jwq` checks `Kb` permission access before reading conditional managed/user rules, nested project/local memory and cwd-level matching rules. `QV1`/`VU6` discover scoped files and glob-matching conditional rules. `Al1` adds only not-already-read paths and records the raw/transformed read state. `nc1` at 543948ff expands `nested_memory`, skill-listing, plan, critical-reminder and other attachments into model messages; `Q5` wraps textual user blocks in `<system-reminder>`. The `dynamic_skill` attachment itself expands to no API messages; subsequent skill discovery/listing is the model-visible route. `criticalSystemReminder_EXPERIMENTAL` likewise becomes message text, not a higher protocol role. MCP instructions can move from the default system section to `mcp_instructions_delta` message attachments when `gf6()` chooses that mode. These are explicit input transitions, not guarantees the model treats every reminder correctly.

### PROMPT-10 — skill availability, invocation instructions, content loading and permission changes are separate mechanisms

**Label: source-verified.** Descriptive excerpt **skill_discovery** (actual identifier(s): `qW and vh memoized callbacks`; LF 537305–537350; raw byte 10845724) `ncY` (LF 466175–466200; raw byte 9596947) `aE8` (LF 413719–413724; raw byte 8644237) `Vp1` (LF 413739–413772; raw byte 8644693) Descriptive excerpt **skill_prompt** (actual identifier(s): `oE8 memoized callback`; LF 413798–413830; raw byte 8645915) Descriptive excerpt **skill_tool** (actual identifier(s): `n86 tool-object methods`; LF 414100–414340; raw byte 8651991) `XEY` (LF 407516–407524; raw byte 8531656) `Ds4` (LF 407525–407571; raw byte 8531908) `yr6` (LF 458758–458861; raw byte 9449455) `DE8` (LF 451441–451462; raw byte 9315072) `oyY` (LF 413951–414025; raw byte 8649207)

Memoized `qW` combines enabled bundled/builtin-plugin/skill-directory/remote/MCP/plugin/command sources. `vh` filters model-invocable prompt commands with an eligible source/description/when-to-use. `ncY` requires a Skill tool, sends only newly discovered names using `Fk6`, and returns `skill_listing`. `Vp1` budgets name/description text; defaults are 2% of input-context tokens times 4 characters/token, or fallback 16,000 characters, overridable by `SLASH_COMMAND_TOOL_CHAR_BUDGET`. Bundled descriptions are retained; other descriptions are shortened or reduced to names. A names-only result can exceed an unrealistically tiny character target; this is not a hard token cap on the complete request.

The Skill tool's actual description comes from memoized `oE8`: it tells the model to check matching skills and calls invocation-before-response a “BLOCKING REQUIREMENT.” That is instruction text in `tools[].description`, not a host-side gate preventing ordinary text generation. The host does validate unknown/non-prompt/disable-model-invocation skill requests and applies permission rules before invocation.

On an inline invocation `n86.call` -> `XEY` -> `Ds4`, `getPromptForCommand` content becomes a meta user message plus invocation metadata/attachments and a `command_permissions` attachment. The returned context modifier unions skill allowed-tools into command-scoped allow rules and can change model/effort; this is actual runtime state change. Plugin loader `yr6` also interpolates arguments, plugin paths, `${CLAUDE_SKILL_DIR}`/`${CLAUDE_SESSION_ID}` and calls `Qp` to process allowed shell substitutions before returning content. Skill content is not automatically concatenated into the base system prompt. `context:'fork'` instead uses `DE8` to choose an agent and make skill content its prompt message, then `oyY` runs `kk` and returns the resulting text. No benchmark establishes that either strategy succeeds more often or costs less.

### PROMPT-11 — named subagents, implicit forks and in-process teammates receive different prompt assemblies

**Label: source-verified.** Descriptive excerpt **fork_prompt** (actual identifier(s): `dZ6.call`; LF 413055–413165; raw byte 8632880) `kk` (LF 407672–407881; raw byte 8533987) `fEY` (LF 407929–407937; raw byte 8539053) `WQ6` (LF 304319–304328; raw byte 6616768) `ai9` (LF 304440–304447; raw byte 6620018) `m4Y` (LF 337482–337818; raw byte 7266695) `Dl` (LF 320090–320142; raw byte 6955454) `pR1` (LF 320074–320089; raw byte 6955126) `ak` (LF 462878–462889; raw byte 9527914)

Agent tool `dZ6.call` chooses an implicit fork only when no specialized type is selected and the fork configuration allows it. A fork reuses `renderedSystemPrompt`, or reconstructs it with `HX`/`qS`, and passes parent context messages plus exact parent tools. A named agent obtains `N.getSystemPrompt`, wraps it with `WQ6` environment/output notes and starts with a new task user message. `kk` also supports explicit `override.systemPrompt`; otherwise it calls `fEY`, which tries agent prompt + `WQ6` and falls back to `PX4` + notes/environment if prompt evaluation throws. A named agent does not automatically receive the full default `HX` engineering/action text.

`kk` obtains `kz`/`i2` unless explicitly overridden, selects its model with `cZ6`, and uses `Dl`/`pR1` for actual allowed/disallowed tool resolution unless `useExactTools`. It preloads frontmatter `skills` into user messages by calling their `getPromptForCommand`; it can add SubagentStart hook context and attach agent hooks. Its options set `commands:[]`, preserve append metadata, disable thinking for ordinary non-exact subagent paths, and call `th` with `maxTurns: supplied ?? agent.maxTurns`. Merely carrying `appendSystemPrompt` in options does not mean it was appended to a named agent's base prompt by `fEY`. `ak` resolves same-name definitions by ordered overwrite: built-in, plugin, user, project, flag, policy.

In-process teammate runner `m4Y` handles `systemPromptMode:'replace'` by using the supplied prompt outright. Otherwise it builds `HX` + `xS1` teammate guidance + optional `# Custom Agent Instructions`, then optional `systemPromptMode:'append'` text, wraps that as a definition, and runs the normal agent machinery. This is separate from ordinary named-agent and main-thread precedence.

### PROMPT-12 — tool descriptions carry behavioral policy while schemas and dispatch constrain execution

**Label: source-verified.** `lR8` (LF 545164–545208; raw byte 11008252) `$Eq` (LF 545840–546686; raw byte 11019955) `Xf4` (LF 318636–318732; raw byte 6899358) `Dl` (LF 320090–320142; raw byte 6955454)

`lR8(tool,context)` uses `inputJSONSchema` when supplied, else converts `inputSchema`, and sets **description from `await tool.prompt(...)`**, not the short `description()` UI method. Tool prompt evaluation receives actual tool/agent lists, permission-context access and allowed-agent types. Agent tool prompt `dZ6.prompt` at 412869–412886 filters definitions by MCP requirements and permission rules, then calls `Xf4`. `Xf4` emits available types/tool capabilities and different fork-versus-specialized-agent instructions. Its text includes claimed shared-cache cheapness and don't-peek/don't-race guidance for background forks; those are sent instructions, not experimental cost evidence or a filesystem-read prohibition enforced by that text.

`$Eq` conditionally filters deferred MCP tools based on `nQ6` and discovered references, excludes tool-search when disabled, sets deferred loading flags, and may prepend an available-deferred-tools meta user message. `lR8` can add strict schemas (flag + `tool.strict` + compatible model), beta input examples, deferred loading and first-party fine-grained input-streaming fields. When teams are disabled it removes specified team-only fields from schemas (`I$_`); disabling experimental betas strips extra tool schema fields. Schema filtering/tool allowlists/runtime permission callbacks are programmatic request/dispatch constraints. Wording about how to use tools is not such a constraint. A schema only describes what is advertised; receiving a tool call still invokes the separate parse/validate/permission/call pipeline documented in Wave 1 tools.

### PROMPT-13 — request grouping gives a real cache boundary, subject to provider, flags and tools

**Label: source-verified.** `R56` (LF 173039–173044; raw byte 3571350) `Is1` (LF 545225–545307; raw byte 11009573) `l$_` (LF 546847–546864; raw byte 11039394) `YEq` (LF 545547–545562; raw byte 11015042) `rg` (LF 545563–545569; raw byte 11015352) `u$_` (LF 545570–545581; raw byte 11015470) `$Eq` (LF 545840–546686; raw byte 11019955) `c$_` (LF 546773–546846; raw byte 11037995)

`R56` requires provider `firstParty` or `foundry` and experimental betas not disabled. `$Eq` enables global caching only with `R56` and force/env feature gate; it adds global-cache beta `JS6`. It sets `G = globalEnabled && (any tools are MCP || tool-search present)`. `Is1` classifies attribution header and the three identity strings specially, then:

| Condition | Resulting grouped system text / requested scope |
|---|---|
| Global enabled, `skipGlobalCacheForSystemPrompt` (`G`) | billing uncached; identity org; all other pieces joined org; marker removed |
| Global enabled, boundary present | billing uncached; identity uncached; pieces before boundary joined global; pieces after joined uncached; marker removed |
| Ordinary fallback, including missing boundary | billing uncached; identity org; all other pieces joined org |

`l$_` turns each group into `{type:'text',text,...}` and adds `cache_control` only if enabled and group scope is not null. `rg` emits `type:'ephemeral'`, optional 1h TTL and `scope:'global'` **only** for global scope; the internal org classification produces no explicit `scope:'org'` field. `u$_` allows 1h for enabled Bedrock env, or qualifying non-overage subscription/query-source allowlist. `YEq` honors disable-cache switches by model family.

Because `HX`'s marker insertion does not test `R56` but `Is1`'s special-marker removal branches do, a forced/flagged marker with a noneligible provider can remain literal text in the ordinary fallback group. That is a source-derived conditional edge, not an observed live-provider behavior. This code groups/annotates request prefixes; it neither proves a backend hit nor makes dynamic text disappear. Tool list/schema/order and user-context changes can still change the prefix. Message cache breakpoints and `skipCacheWrite` are applied by `c$_` independently (Wave 1 CTX-11–15).

### PROMPT-14 — stop/continue behavior combines model instructions with host state transitions

**Label: source-verified.** `zgY` (LF 450352–450945; raw byte 9294729) `t9q` (LF 450087–450285; raw byte 9289790) Descriptive excerpt **stop_transition** (actual identifier(s): `zgY`; LF 450680–450775; raw byte 9302760) `$Eq` (LF 545840–546686; raw byte 11019955) `kk` (LF 407672–407881; raw byte 8533987)

The default/agent prompts request persistence through task completion, concise final reports, scoped delegation and adaptive behavior after blocks. Actual continuation is in `zgY`: assistant `tool_use` presence selects tool execution and a later model turn; absence goes through error recovery and stop hooks. `$Eq` records provider `stop_reason` separately; it is not the sole continuation predicate. Tool output and new meta context enter the next request. `maxTurns` is checked before the next post-tool request; cancellation/blocking limits can stop execution without any final task-level proof.

`t9q` runs Stop/SubagentStop hooks, turns blocking errors into meta user input, and reports `preventContinuation` separately. `zgY` returns `stop_hook_prevented` for the latter, or appends hook blocking errors and takes `stop_hook_blocking` back to a model request. On output-limit recovery it inserts the explicit “Resume directly — no apology, no recap...” meta user instruction and retries with a bounded recovery counter. Thus hooks/limits determine whether execution proceeds; textual persistence instructions determine only requested model behavior. A generator terminal `reason:'completed'`, an Agent completed tool payload, or SDK result `subtype:'success'` is not evidence the requested repository change is correct.

### PROMPT-15 — extra request body can override reconstructed prompt fields

**Label: source-verified.** `iR8` (LF 545524–545546; raw byte 11014541) `$Eq` (LF 545840–546686; raw byte 11019955)

`iR8` parses `CLAUDE_CODE_EXTRA_BODY` as a JSON object and merges provider-specific `anthropic_beta`. Within `$Eq` request constructor `n`, `...F6` (the result of `iR8`) is spread **after** computed `model`, `messages`, `system`, `tools`, `tool_choice`, metadata, max tokens, thinking and temperature. Consequently matching extra-body keys can replace those computed fields; output_config/speed are conditionally applied after that spread. This is a supported input/configuration transition, not a claim about external attacker control. Any attempt to predict wire shapes must capture final requests or explicitly exclude this override. No environment values were inspected for this finding.

### PROMPT-16 — actual enablement, model compliance and provider-cache effects remain unestablished here

**Label: unknown.** Scope: live 2.1.80 deployments and native 2.1.302. Actual backend function identifiers/locations are unknown; unavailable backend code has no source citation. Evidence boundary: the locally inspected source functions above construct instructions and requests; this report performs no authenticated provider request or task benchmark. Unknown transitions include backend interpretation/priority of system-reminder text, actual remote-flag values, server cache matching/expiry, model compliance with action/skill/fork guidance, task correctness after compaction, and native-version prompt parity.

PROMPT-17 records the inspected local simulated-provider prompt captures; PROMPT-18 records the targeted project-source-enabled memory capture. See the Wave 2 experiments report for exact fixture conditions. Static claims above retain their source-verified label. A local fixture's synthetic usage cannot establish Anthropic cache performance.

### PROMPT-17 — simulated CLI captures corroborate custom/append/empty replacement and retained user context

**Label: experimentally observed.** Scope: unmodified published 2.1.80 CLI, isolated loopback synthetic Messages API provider; no Anthropic backend observation. Evidence: `evidence/experiments/runs/rerun-final/EXP-09/result.json` through `EXP-13/result.json`, independently inspected first request body from each. Exact commands/environment fixture descriptions and raw requests are retained there. `evidence/prompt/capture_summary.json` records source-result hashes and a bounded shape summary; reproduce it with `summarize_captures.py`. Actual source identifiers associated with these shapes are `uFq.submitMessage`, `$Eq`, `TH8`, `Is1`, `l$_` and `qR8`, as statically cited above; this experiment did not instrument their internal execution.

All five commands use `--print --output-format stream-json --verbose --no-session-persistence --setting-sources ''` with the pinned `cli.js`. Input/options -> one captured Messages request per case -> local synthetic text response -> CLI result. The captured requests contain:

| Case | Observed `system` blocks after billing header | Observed messages/tools |
|---|---|---|
| EXP-09 default | SDK-agent identity; default instructions plus environment/Git snapshot | one user message containing skills reminder, currentDate reminder and input; 22 tools |
| EXP-10 custom string | SDK-agent identity; exactly `CUSTOM FIXTURE SYSTEM BLOCK` | date/skills user context and 22 tools retained |
| EXP-11 append string | official-CLI-with-SDK identity; default instructions containing `APPENDED FIXTURE SYSTEM BLOCK`, followed by Git snapshot | date/skills user context and 22 tools retained |
| EXP-12 CLAUDE.md fixture, project settings excluded | SDK-agent identity; default instructions | no `# claudeMd` or fixture sentinel in message context |
| EXP-13 empty custom string, project settings excluded | SDK-agent identity only; no default-instruction block | date/skills user context and 22 tools retained; no CLAUDE.md section |

Billing has no `cache_control`; each identity and nonempty application-instruction block has `{type:'ephemeral'}`. These captures do not exercise global scope or 1h TTL. Tool schemas in these cases contain only `name`, `description`, `input_schema`. Adjacent initial user content is merged into one API user message. The missing memory in EXP-12/13 is consistent with the explicit empty setting-source set; they cannot support an experimental claim of CLAUDE.md ingestion. The empty-custom result does corroborate the SDK `typeof-string` behavior, independently of project-memory ingestion. Synthetic responses do not validate model obedience or provider cache hits.

### PROMPT-18 — enabling project sources places the CLAUDE.md sentinel in user context

**Label: experimentally observed.** Scope: unmodified published 2.1.80 CLI with the isolated synthetic loopback provider. Raw evidence: `evidence/experiments/runs/rerun-memory/EXP-15/result.json`; command/environment and first outbound request are retained there, and `evidence/prompt/capture_summary.json` records its hash. Actual associated source identifiers are `hO`, `kz`, `qR8`, `YX` and `$Eq`; no instrumentation proved individual function execution.

The command used `--setting-sources project`, a research-owned project `CLAUDE.md` containing the exact `CLAUDE.MD FIXTURE SYSTEM BLOCK` sentinel, and input `Observe project memory context.`. Input/source selection -> one captured request -> synthetic response -> CLI result. The captured request contains that sentinel and the file's absolute path/provenance in the `# claudeMd` section of a user `<system-reminder>`, followed by currentDate and the prompt. The sentinel is absent from `system`. There are 22 advertised tools, and the CLI result reports exit 0/success; that status only establishes fixture completion. The contrast with EXP-12's empty setting sources is one isolated source-selection comparison, not proof of every trust/rule/include condition or model compliance.

## Reproduction and limitations

```bash
python /workspace/research/claude-davinci/evidence/prompt/extract_evidence.py
python -m json.tool /workspace/research/claude-davinci/evidence/prompt/source_index.json
python /workspace/research/claude-davinci/evidence/prompt/summarize_captures.py
rg -n 'function qS|function HX|function Is1|function l\$_|class uFq|SYSTEM_PROMPT_DYNAMIC_BOUNDARY|hasClaudeMdExternalIncludesApproved' /workspace/research/claude-davinci/artifacts/claude-2.1.80/cli.pretty.js
```

The extractor asserts every indexed raw needle occurs exactly once, retains each excerpt and records both bundle hashes. It uses `split('\n')`, never `splitlines()`. Source is the actual npm bundle; no secondary reconstruction was accepted as proof. No attempt was made to recover unpublished original module paths. Paths/flags/strings identify bounded client branches, not enabled production features. Backend behavior, successful task outcomes, prompt-cost advantage and native-version equivalence remain unknown. DaVinci comparison belongs to Wave 3.
