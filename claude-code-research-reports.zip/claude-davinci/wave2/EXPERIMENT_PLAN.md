# Controlled experiment requirements

Run against pinned published 2.1.80 cli.js using Node24. All fixtures, settings, config, transcript paths and side effects must stay under research-owned directories or unique /tmp fixtures; no DaVinci writes. Do not use real credential material. Spawn an isolated environment dictionary with synthetic local-only API key if required and ANTHROPIC_BASE_URL set to an owned loopback server. Disable nonessential traffic and updates; skip user/project MCP, hooks, plugins and settings unless the scenario explicitly tests a research-owned hook/settings fixture. Retain exact commands, stdout/stderr, exit codes, request/response JSON, timestamps and tool-side-effect evidence. Never log ambient secrets.

Required useful scenarios where feasible:

1. Startup/argument validation and ordinary final text, capturing stream-json final result fields.
2. Model returns tool_use; one fixture tool call -> tool_result request -> final text. Tie to loop source.
3. Max turns = 1: does tool work happen before limit? Record num_turns, is_error, subtype, exit, stop_reason.
4. Permission denial: a controlled fixture write (outside DaVinci) with restricted tool exposure/dontAsk -> denial result; record unchanged target.
5. Two safe tools vs mutating tool barriers, timing only if fixture can establish ordering robustly. Do not infer scheduler parallelism from mere API tool array.
6. Contradictory/missing stop_reason and tool_use contents, documenting any SDK validation limitations.
7. Output max_tokens response and retry/resume path, bounded requests/timeouts.
8. Request system and tool/message cache_control shapes with stable vs appended prompt inputs. No backend cache-hit/savings inference.
9. One genuine native 2.1.302 startup/argument behavior if useful; do not call it parity proof.

Use a small simulated Messages API endpoint, JSON response or proper SSE event sequence. Clearly mark all provider behavior synthetic. No paid/live inference. If fixture protocol needs adaptation, capture failed attempts and distinguish harness failures from target behavior. Prefer source-informed reproducible tests with per-scenario deadlines and a global request cap over uncontrolled retry loops. Report scenarios not exercised as unknown; do not silently replace with trivial help checks.
