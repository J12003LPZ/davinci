# Claude Code runtime research and DaVinci comparison

Research deliverables are available below. DaVinci source remains unchanged; the recommendations are proposals for a later implementation phase.

Primary implementation target: official Claude Code npm **2.1.80**, selected because its published JavaScript is directly inspectable. This is actual distributed implementation, not third-party decompiled documentation. The separately installed **2.1.302** native executable is copied and hashed for inventory; this research must not imply cross-version parity. Source findings identify exact minified function names, not invented original names.

DaVinci pin: `53e999a7fc24c721c484a710093eeeff611641bf`.

The uploaded SKILL.md is the leanrea analysis guide. It is treated as supporting reference material, subordinate to the user's requested wave structure and evidence standards. No benchmark scripts from the leanrea repository are run.

## Research files

- Start here: [single end-to-end runtime specification and comparison](final/RUNTIME_SPEC.md)
- Decisions: [prioritized recommendations](final/RECOMMENDATIONS.md)
- Review: [lead contradiction resolutions](final/CONTRADICTIONS.md), [initial independent audit](wave3/audit.md), [final independent audit](wave3/audit-final.md)
- [Evidence protocol](RESEARCH_PROTOCOL.md)
- [Artifact manifest](evidence/artifact-manifest.json) — regenerate with `python3 scripts/artifact_manifest.py`
- Wave 1: [loop](wave1/loop.md), [tools](wave1/tools.md), [context](wave1/context.md), [delegation](wave1/delegation.md)
- Wave 2: [prompt](wave2/prompt.md), [experiments](wave2/experiments.md)
- Wave 3: [detailed comparison](wave3/comparison.md), [source-checked implementation proposals](wave3/recommendation-proposals.md)
- [Canonical experiment index and reproduction notes](evidence/experiments/INDEX.md)
- [Retained-evidence validation](evidence/validation.json) — regenerate with `python3 scripts/validate_research.py`

## Agent allocation

Maximum four simultaneous subagents was maintained. Wave 1 used GPT-6 Luna High for focused loop, tool and delegation tracing and GPT-6.1 Sol High for difficult context analysis. Wave 2 used Sol High for architectural prompt reconstruction and Luna High for controlled experiments. Wave 3 used Sol High for comparison and independent review. After session continuation, focused Sol High follow-ups finished the missing recommendation report and final audit rather than restarting the research. The lead resolved conflicts and authored the integrated specification and priorities.

## Verified outcomes and limits

The official tarball integrity, raw/formatted artifact hashes and original-source byte anchors are retained. The independent audit checked 75 context and117 prompt index entries and reproduced the formatting derivative. All75 context excerpts parse; two prompt excerpts are explicitly partial. Fifteen canonical local-provider scenarios recorded fourteen zero exits and one compound-invalid-stream failure. Three independent differential controls distinguish missing-start-message failure from successful malformed-JSON fallback; three repaired-runner reproductions check memory source selection. Preliminary failed/configuration attempts were not all reliably retained by the original runner; per-record commands and the canonical index are authoritative.

The lead's83 retained-evidence assertions check artifact identity, recorded terminal/permission/memory/fallback outcomes and the unchanged DaVinci source pin. They are not83 product tests or a task-success benchmark. No DaVinci code/test/configuration changes, Rust test execution, worktree cleanup execution, real credential use, live Claude inference or paid API setup occurred in this research. Some CLI fixture tools wrote only research-owned files. Ancillary network activity was not comprehensively packet-captured.

The highest priorities are explicit settled terminal reasons and truthful recoverable worktree cleanup. Optional text-only output continuation depends on terminal consumer correctness. Prompt/context/delegation efficiency changes require a separately authorized, route/model/effort-pinned matched evaluation. No performance percentage, quality gain, backend cache behavior or native2.1.302 parity is claimed.

## Scope limits

Static request construction cannot prove backend cache hits or task success. Local simulated-provider experiments establish client behavior under those inputs, not production Anthropic behavior. No model quality, success-rate, cost or subscription-saving conclusions without an actual benchmark. No paid or authenticated remote inference is needed for static tracing; credentials remain untouched.
