# Wave 1: Claude Code tool execution, permission, and recovery mechanisms

## Scope and method

Pinned artifact: official npm `@anthropic-ai/claude-code` 2.1.80 (`artifacts/claude-2.1.80/cli.js`, SHA-256 `0b146fe609bd591feb8e6ba689d146b56265076c9c23cee1a351cd2df74b4ec1`, 12,373,859 bytes). Human-readable references use the mechanically formatted `cli.pretty.js` (Prettier 3.6.2), whose line numbers are not original source locations. Raw byte offsets and unique needles are in [raw-needles.txt](../evidence/tools/raw-needles.txt). This is static source inspection only; no local executable experiment was run, no live provider was called. The separate installed native 2.1.302 target is outside these conclusions; no parity is implied.

Labels below classify each claim. “Source-verified” means this branch is present in the pinned source, not that a runtime feature flag/config enables it.

## Claim map

### T-ADM-01 — tool exposure/admission is filtered before tool calls

**Label: source-verified.** `pR1` (pretty lines 320074–320087; original offset 6,955,126, needle `function pR1`) filters tools by MCP name, plan-mode exception, excluded tool set, built-in/custom status, async availability and feature checks. `Dl` (320091–320140; offset 6,955,454, needle `function Dl`) then applies `disallowedTools`, resolves configured allowed names, handles wildcard/unspecified allow lists, and separates valid/invalid/resolved tools. This is actual list construction logic rather than a prompt. The exact meanings of imported sets/flags are outside this focused trace; tool names in model-visible prompt alone do not establish executable admission.

### T-PERM-01 — permission approval callback gates execution, supports abort and recheck

**Label: source-verified.** Actual minified identifier `S4Y` (337133–337303; raw offset 7,260,796) wraps `JM(...)`; an `allow` decision returns immediately, while `ask` checks the abort signal and obtains an input description. In the interactive path it registers a pending request keyed by tool use ID, installs an abort listener that resolves as ask/denial text, resolves allow with approved/updated input and permission updates, resolves rejection as ask, and exposes `recheckPermission()` which reruns `JM` and resolves only if now allowed. In the non-pending-list path it registers a request and polls team mailbox responses, aborting on signal. This demonstrates conditional approval handling in source, not that every environment uses UI prompts.

### T-PERM-02 — mode transforms unresolved ask into deny in dontAsk; auto has classifier paths

**Label: source-verified.** Actual identifier `JM` is an async arrow assigned at pretty lines 541119 onward (raw offset 10,915,664, needle `JM=async`). It invokes `hO_` (540965–541115; raw offset 10,912,912), preserves allow, and changes unresolved ask into deny in `dontAsk`. In auto mode it tracks denials; it may allow based on acceptEdits permission checks or a safe-tool allowlist, otherwise runs the classifier and handles unavailable/block/allow outcomes. `S4Y` forwards remaining asks to the interactive/team permission request path.

`hO_` source precedence is: (1) abort signal throws; (2) first matching always-deny rule returns deny; (3) first matching always-ask rule returns ask, except Bash may bypass that rule when sandboxing and auto-allow-bash-if-sandboxed are enabled and command `ug(q)` qualifies; (4) parse input and ask the tool’s `checkPermissions`; (5) return a tool-level deny; (6) preserve ask for `requiresUserInteraction` tools and explicit ask rules; (7) `bypassPermissions` mode (or available bypass in plan mode) allows the remaining action; (8) a matching always-allow rule allows; (9) remaining passthrough becomes ask. Rule collection helpers `JN6`/`S16`/`MN6` use source precedence array `Xs1` at 541417, which is initialized as `[..., "cliArg", "command", "session"]`; exact earlier entries are assembled dynamically at initialization and are not expanded in this trace. In `xBY`, PreTool hook allow can bypass the interactive callback only when no forced `requireCanUseTool` or required-interaction tool applies; it still runs `h9q` so deny/ask permission rules can override. Hook deny returns an error tool result.

The source also contains user-facing prompt instructions at 304040; those are guidance, not enforcement evidence. Static branches do not establish the configured mode or whether relevant gates are enabled in a particular invocation.

### T-SCH-01 — streaming scheduler admits concurrency only for schema-valid, explicitly safe tools

**Label: source-verified.** The query loop `zgY` (pretty 450352–450943) creates `Jr6` when `YYq().gates.streamingToolExecution` is true (450484) and calls `addTool` for each streamed assistant `tool_use` (450605–606). The gate is the feature flag `FY("tengu_streaming_tool_execution2")` (YYq, 450289–450296); it is conditional, so static presence alone does not show streaming execution is enabled. In `Jr6.addTool` (448933–448979), it resolves the tool from definitions, normalizes input with `nL8`, and sets `isConcurrencySafe` only when `inputSchema.safeParse` succeeds and `tool.isConcurrencySafe(parsedData)` returns true; parse errors/exceptions classify unsafe. Missing tool definitions instead get a synthetic completed error result. Built-in examples: Read (`I9`, around 464939–465000) returns true; Edit (`KP`, 421819–421855) and Write (`YP`, 422439–422478) return false; Grep/Glob return true (423138 and 423468); Bash (`M4`, 458288–458318) delegates concurrency safety to `isReadOnly`, so its classification depends on parsed command and permission/sandbox logic. `processQueue` (448985–449002) allows a queued safe tool whenever all active executions are safe, or any tool when none are active. A queued unsafe tool stops the queue scan if it cannot start. There is no concurrency cap in this streaming class; streaming parallelism depends on each tool’s source-defined predicate.

### T-SCH-02 — the non-streaming fallback batches adjacent safe tools, serializes unsafe barriers, and caps batch execution

**Label: source-verified.** If `Jr6` is absent, `zgY` calls `rL8` at pretty 450772. `FBY` (449420–449437) scans tool uses in order and groups only adjacent safe calls into a batch; any unsafe tool forms its own singleton barrier. A group is safe only if schema parsing succeeds and `isConcurrencySafe(parsed)` returns true. `rL8` (449395–449419) executes safe groups with `QBY` and then applies their context modifiers in original block order; unsafe groups use `UBY`, which awaits each tool in sequence and applies each context modifier before proceeding. `QBY` (449457–449473) uses `$E8` (406989–407009), a completion-racing async generator with concurrency bound `pBY()`; `pBY` (449390–449393) reads `CLAUDE_CODE_MAX_TOOL_USE_CONCURRENCY`, defaulting to 10 when unset/invalid/zero. The safe-group cap applies only to this fallback path. The parser does not clamp negative values: the consequence of a negative concurrency limit is an inferred edge case (see below), not an experimentally observed behavior.

### T-SCH-03 — streamed result delivery can follow completion order while preserving tool-use IDs

**Label: source-verified.** In fallback, `$E8` yields whichever per-tool generator next produces a value first; `QBY` therefore emits safe tool messages/progress in completion order. In streaming mode, `Jr6.getCompletedResults` (449155–449173) traverses the original `tools` array: queued progress is drained, completed results are yielded, and an executing unsafe tool blocks yielding later entries; executing safe tools do not block later safe result messages. Thus results for safe calls may become visible before an earlier safe call finishes. The query loop collects yielded user tool-result messages into `q6`, then the next turn is assembled as `[..., I, ...e, ...q6]` (about 450901 onward), with explicit `tool_use_id` association. This establishes ordering behavior in this path, not that API-side validation accepts every possible partial ordering in every provider mode.

### T-SCH-04 — per-tool generator performs schema validation, tool validation, hooks, permission, then call; errors become tool_result

**Label: source-verified.** `jr6` (448141–448241) resolves definitions/aliases and returns an error result for unknown tools. `IBY` (448243–448295) drives `xBY` (448297 onward). `xBY` first `safeParse`s the schema, returns `InputValidationError` result on failure, calls optional `validateInput`, and returns its error without calling the tool when `result === false`. It performs additional Bash permission-context/sandbox validation for the Bash tool, runs PreTool hooks, and invokes the permission callback unless an allowed hook is applicable and `requireCanUseTool` does not force the callback. Any non-allow decision returns an error tool_result; on allow it calls `A.call`, maps the result to a tool-result block, runs post-tool hooks, emits context modifiers/attachments, and catches thrown errors into an `is_error` tool_result. In streaming mode the same generator is called by `Jr6.executeTool` (449074 onward), with a sibling-linked AbortController passed in the context.

### T-SCH-05 — cancellation policy and sibling failure handling are selective

**Label: source-verified.** `Jr6.getAbortReason` (449037–449048) and `getToolInterruptBehavior` (449049–449066) distinguish discarded-for-streaming-fallback, sibling-error, and main abort. On a main `reason === "interrupt"`, the tool is synthesized as interrupted only when its `interruptBehavior()` returns `"cancel"`; absent/throwing predicate defaults to `"block"`, which means this branch does not synthesize cancellation. Other main aborts synthesize cancellation. `executeTool` listens to the sibling controller: a sibling abort propagates to the main context only if its reason is not `sibling_error` and the main signal is still live. It marks `hasErrored` and aborts siblings when an error tool_result occurs specifically for Bash (`E7`); other tools’ errors are recorded but do not trigger that branch. Abort signals cannot establish that the underlying tool side effect stopped or rolled back.

### T-SCH-06 — streaming fallback discards results but does not abort already-running tool calls

**Label: source-verified.** `Jr6.discard()` (448923–448925) only sets `discarded = true`. The query loop calls it when a streaming model fallback is reported, then replaces the runner (`zgY`, around 450535–450554). `getAbortReason` sees the discarded flag and future result collection is suppressed, but `discard()` does not abort `siblingAbortController` or per-tool controllers. Therefore an already-running `A.call` in `executeTool` is not directly cancelled by this method; it may continue while its eventual result is discarded. This establishes absence of a cancellation action in this branch, not that every underlying tool ignores cancellation or that a side effect always completes.

### T-ERR-01 — mismatched tool_use/tool_result API errors are normalized and suggest rewind

**Label: source-verified.** The API error normalization branch at pretty lines 306883–306902 recognizes HTTP 400’s “tool_use ids … without tool_result blocks immediately after” error, extracts a `toolu_…` ID, calls `mn9` when both message arrays are available, and returns `invalid_request` with “API Error: 400 due to tool use concurrency issues” plus `/rewind` guidance outside the relevant mode. A distinct “unexpected tool_use_id” message emits an event. This is error classification/recovery messaging; it does not itself prove that `mn9` replays, commits, or repairs durable state.

### T-REC-01 — in-process teammate state records conversation and active tool-use IDs

**Label: source-verified.** The in-process runner at pretty lines 337550–337700 holds local messages and, as streamed assistant/user messages arrive, appends them to task state. Assistant tool_use IDs are added to `inProgressToolUseIDs`; matching tool_result IDs are removed. It has separate lifecycle and current-work abort signals; lifecycle abort exits the loop, current-work abort marks work interrupted and appends an interrupted marker. `preserveToolUseResults: true` is passed to the `kk` runner (around pretty 337615–337645; needle offset 7,269,205). This is teammate/in-process state handling and should not be generalized to the main session transcript or durable recovery.

### T-REC-02 — durable commit/replay guarantees not established

**Label: unknown.** No evidence in this focused read establishes an atomic durable commit boundary for tool side effects, idempotency keys, exactly-once execution, durable replay after process loss, or automatic re-execution of incomplete tool calls. The mismatch branch points users toward `/rewind`; “persisted” tool-result handling elsewhere concerns large output storage/truncation, not a transaction journal. The main runtime journal/recovery guarantees require separate tracing. Static message-array updates and transcript persistence cannot establish external side-effect rollback.

## State transitions evidenced

1. Candidate tool list → `pR1` capability/mode filtering → `Dl` allow/deny-list resolution.
2. Streamed assistant `tool_use` → `Jr6.addTool` normalization/schema parse/safety predicate → queued/executing/completed/yielded; or, when streaming gate is off, `FBY` groups adjacent safe calls and separates unsafe barriers → bounded safe groups / serial unsafe groups.
3. Per-tool validation and PreTool hooks → permission decision → allow invokes tool call and post-tool hooks, while non-allow or thrown failures emit an error result keyed by `tool_use_id`.
4. Permission result from `JM`: allow returns; ask may become deny in `dontAsk`, may be accepted/blocked by auto logic, or continues to approval callback. Approval request then resolves allow, reject, abort, or recheck.
5. Streaming tool abort → synthetic interrupted/discarded/sibling-error result as policy dictates; Bash tool errors can sibling-abort concurrent calls. This signal flow is not side-effect rollback evidence.
6. Query collects returned tool-result messages → next request history `[..., I, ...e, ...q6]`; API mismatch response → optional `mn9` diagnostic → normalized invalid-request message and rewind suggestion. No proven durable replay guarantee.
7. In-process teammate stream separately tracks active IDs; lifecycle abort exits, current-work abort emits interruption state.

## Negative evidence and limits

- Prompt text and schema declarations do not prove runtime access. `pR1`/`Dl` and `JM`/`S4Y` are the enforcement evidence cited above.
- Presence of a static branch does not establish that it is enabled by flags/config in an invocation.
- This pass did not execute the CLI, simulate tool calls, or exercise cancellation and permission UI; no experimental observations are claimed.
- **Label: inferred.** Since `pBY` returns `parseInt(env, 10) || 10` without a positive-range clamp, a negative nonzero environment value produces a negative concurrency argument. `$E8` initially starts jobs only while `active.size < limit`; with a negative limit that condition is false, so the source implies an empty result stream (and no tools launched) on the fallback safe-batch path. This edge case was not executed. Zero/NaN fall back to 10; streaming mode does not use this cap.
- Per-tool retry behavior after a thrown tool call remains unknown; this scheduler records an error result and does not itself retry the call.
- Retry strings elsewhere include network/MCP reconnect logic and SDK HTTP retry middleware. Those are not evidence that a failed filesystem/shell/MCP tool action is safely retried, nor that external side effects are idempotent.
- Durable session commit/replay and crash recovery were not proven here. Do not claim transactional rollback, exactly-once, or automatic repair.
- Scope is npm 2.1.80 only. No claims about native 2.1.302.

## Reproducibility

```sh
sha256sum /workspace/research/claude-davinci/artifacts/claude-2.1.80/cli.js
rg -n 'function pR1|function Dl|function S4Y|JM = async|API Error: 400 due to tool use concurrency issues|preserveToolUseResults' /workspace/research/claude-davinci/artifacts/claude-2.1.80/cli.pretty.js
cat /workspace/research/claude-davinci/evidence/tools/raw-needles.txt
```

All investigation was read-only against the target DaVinci tree. Only this report and the assigned evidence directory were written.
