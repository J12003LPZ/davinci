# Wave 1: Claude Code agent loop and completion states

## Scope and method

Pinned target: published `@anthropic-ai/claude-code` **2.1.80**, as distributed at `/workspace/research/claude-davinci/artifacts/claude-2.1.80/cli.js`. The formatted file is a mechanically formatted derivative at `cli.pretty.js`; all line references below refer to that derivative. Descriptive terms like “agent turn” refer to the implementation, not upstream source names. This is static source analysis; no provider calls or behavioral experiments were run. It does not establish parity with the separately inventoried 2.1.302 native binary.

Reproduce the source locations and byte needles:

```sh
P=/workspace/research/claude-davinci/artifacts/claude-2.1.80
rg -n 'async function\* (th|zgY|uZ6|zEq)|query_api_loop_start|query_recursive_call|query_tool_execution_start|message_delta|error_max_turns|error_during_execution' "$P/cli.pretty.js"
python3 - <<'PY'
p='/workspace/research/claude-davinci/artifacts/claude-2.1.80/cli.js'
b=open(p,'rb').read()
for n in [b'max_turns_reached', b'max_output_tokens_recovery', b'model_context_window_exceeded', b'cli_streaming_idle_timeout', b'cli_nonstreaming_fallback_started', b'error_max_turns', b'error_max_budget_usd']:
    hits=[]; start=0
    while (i:=b.find(n,start))>=0: hits.append(i); start=i+1
    print(n.decode(), hits)
PY
```

Original-byte needles are exact ASCII searches; some occur multiple times, so use the derivative function/branch location to disambiguate. Relevant original offsets include: `max_turns_reached` 8,538,251; `max_output_tokens_recovery` 9,302,570; `model_context_window_exceeded` 11,029,755; `cli_streaming_idle_timeout` 11,025,211; `cli_nonstreaming_fallback_started` 11,032,340; `error_max_turns` 12,211,888; `error_max_budget_usd` 12,213,512.

## Structured claims

### LOOP-01 — A query turn streams a model response, then either returns or executes requested tools

- **Scope/version:** CLI and SDK query path, 2.1.80.
- **Label:** source-verified.
- **Actual identifiers:** `th(A)` wrapper and `zgY(A, q)` async generator; model adapter `uZ6({...})`; streaming fallback helper `zEq(A, q, K, Y, _, z)`.
- **Locations:** `cli.pretty.js:450346-450350` (`th`); `450352-450943` (`zgY`); model request invocation and iteration at `450513-450629`; no-tool continuation/completion at `450680-450771`; tool execution and next-turn setup at `450772-450929`; request adapter at `545729-545743`; fallback implementation at `545746-545760` and the response stream handling around `546000-546650`.
- **Transition:** `zgY` initializes `turnCount: 1`, emits `stream_request_start`, and calls `j.callModel(...)` (default dependency `uZ6`). Assistant messages accumulate. If no `tool_use` block was emitted (`!K6`), the code handles error/recovery and stop hooks, then returns `{reason: "completed"}`. If tool use exists, completed tool results are yielded/appended, user/tool context is refreshed, and the recursive-state object is set with `turnCount: N + 1`, `transition: {reason: "next_turn"}`; the enclosing `while (!0)` then starts another request.
- **Evidence:** `cli.pretty.js:450359-450394`, `450513-450629`, `450680-450771`, `450772-450929`.
- **Limit:** `reason: "completed"` means the generator has reached its completion branch; it is not itself proof that the final model `stop_reason` was `end_turn`.

### LOOP-02 — Stream events assemble content blocks and capture API stop reason; token exhaustion can trigger recovery

- **Scope/version:** model adapter stream processing, 2.1.80.
- **Label:** source-verified.
- **Actual identifiers:** `uZ6({...})` (async generator); fallback helper `zEq(...)`.
- **Locations:** `cli.pretty.js:545729-545743` entry, request `.beta.messages.create({ ...g6, stream: !0 }, { signal: _ }).withResponse()` around `546140-546151`; event reconstruction and `message_delta` around `546230-546370`; fallback around `546365-546520`.
- **Transition:** request parameters include normalized `messages`, `system`, `tools`, `tool_choice`, `max_tokens`, thinking/output options and optional betas. The stream assembles text/thinking/tool JSON from block start/delta/stop events and yields assistant content at block stop. On `message_delta`, it stores `delta.stop_reason`. `max_tokens` and `model_context_window_exceeded` produce API-error assistant messages. If the stream throws or completes without a usable message/content block, it may fall back to non-streaming via `zEq`; a flag disables that fallback. A stream 404 has its own non-stream fallback branch.
- **Evidence:** `cli.pretty.js:546040-546151`, `546230-546370`, `546365-546520`.
- **Limit:** branch presence does not prove watchdog/fallback feature activation for a particular invocation; e.g. watchdog is gated by `CLAUDE_ENABLE_STREAM_WATCHDOG`.

### LOOP-03 — Tool use is the loop-continuation signal in this generator; the API stop reason is recorded separately

- **Scope/version:** `zgY` query coordinator, 2.1.80.
- **Label:** source-verified.
- **Actual identifier:** `zgY(A, q)`.
- **Locations:** `cli.pretty.js:450588-450630` sets `K6` from assistant `tool_use` blocks; `450680-450771` handles the no-tools path; `450772-450929` runs tools and starts `next_turn`.
- **Transition:** the coordinator tests whether accumulated assistant messages contain tool blocks (`K6`), not whether `stop_reason` equals a specific string, to choose the tool execution path. The no-tool path proceeds to stop hooks, recovery, or returns. Tool-result output is appended to the transcript and passed into the next model request. Therefore `tool_use` commonly accompanies continuation, while the exact API `stop_reason` is telemetry/message metadata, not the sole branch predicate here.
- **Evidence:** See LOOP-01 and LOOP-02 locations.
- **Limit:** It does not establish all provider-specific stop reason semantics. Server-side tool loops may be represented differently and are not inferred here.

### LOOP-04 — Turn limit stops after tool work when the next turn would exceed configured `maxTurns`

- **Scope/version:** `zgY` query coordinator, 2.1.80.
- **Label:** source-verified.
- **Actual identifier:** `zgY(A, q)`.
- **Locations:** `cli.pretty.js:450850-450874` abort-after-tools limit reporting and `450917-450942` normal `maxTurns` guard and transition.
- **Transition:** after tool results/attachments, code computes `R6 = N + 1`; when `$` is truthy and `R6 > $`, it yields `max_turns_reached` with `turnCount: R6` and returns `{reason: "max_turns", turnCount: R6}`. Otherwise it records `turnCount: R6` and recurs. Aborted tool work uses a separate `aborted_tools` return and only yields `max_turns_reached` if the calculated post-tool count exceeds the maximum. The limit is optional (`$` undefined means no guard in these branches).
- **Evidence:** `cli.pretty.js:450850-450874`, `450917-450942`; original needle `max_turns_reached` at byte 8,538,251 (plus other occurrences).
- **Limit:** The CLI driver’s default/argument selection for `maxTurns` is outside this claim; this is the coordinator’s conditional behavior.

### LOOP-05 — Stop-hook continuation can block the natural completion or force another loop iteration

- **Scope/version:** coordinator and stop-hook handler, 2.1.80.
- **Label:** source-verified.
- **Actual identifiers:** `zgY(A, q)`; `t9q(A, q, K, Y, _, z, w, O)` stop-hook path.
- **Locations:** `cli.pretty.js:450680-450771` and `450087-450285` for `t9q` (hook message inspection and return fields); the two loop transitions are `reactive_compact_retry` and `stop_hook_blocking` in `450706-450771`.
- **Transition:** with no tool calls, the coordinator invokes `t9q`. `preventContinuation` returns `stop_hook_prevented`; blocking errors are appended and transition back with `stop_hook_blocking`; otherwise it returns `completed`. Tool execution can also return `hook_stopped` for a hook-stopped continuation attachment. These are distinct from user interrupt and model error.
- **Evidence:** `cli.pretty.js:450087-450285`, `450680-450771`, `450790-450862`.

### LOOP-06 — Abort while streaming and abort during tool execution have separate outcomes

- **Scope/version:** `zgY` and outer query driver, 2.1.80.
- **Label:** source-verified.
- **Actual identifiers:** `zgY(A, q)` and outer class `uFq`, async generator method `submitMessage(A, q)` (`cli.pretty.js:606648`, `606664`), which calls `th(...)` at `606942`.
- **Locations:** `cli.pretty.js:450630-450655` catches streaming/query exceptions; `450656-450679` abort-after-stream path; `450850-450873` abort-after-tools. Outer result/yield driver is `606942-607227`; its public `interrupt()` calls `this.abortController.abort()` at `607228`.
- **Transition:** aborted signal after model iteration yields failed tool results or drains streaming tool work and returns `aborted_streaming`; abort after tool execution returns `aborted_tools`. Only abort reasons other than literal `"interrupt"` yield the internal `pp(...)` progress marker in these branches. The outer driver records assistant stop reason when present and ultimately emits a `result` subtype based on the terminal path.
- **Limit:** This does not claim exact TTY rendering or every interrupt input path.

### LOOP-07 — API retries are externally observable as retry system messages; exhausted execution has distinct result subtypes

- **Scope/version:** outer query/result driver, 2.1.80.
- **Label:** source-verified.
- **Actual identifier:** `uFq.submitMessage(A, q)`, in class `uFq` (`cli.pretty.js:606648`, `606664`); it calls `th(...)` at `606942`.
- **Locations:** `cli.pretty.js:606942-607227`; retries converted to `system` subtype `api_retry` at `607080-607091`; result branches `error_max_turns` at `607024-607045`, budget at `607111-607138`, structured retry cap at `607141-607176`, execution error at `607178-607207`, success at `607211-607227`.
- **Transition/observable output:** `uFq.submitMessage` consumes `th(...)` events; forwards assistant/user/progress and optionally stream events; remembers last assistant stop reason from message or `message_delta`. It emits result objects with fields including `subtype`, `is_error`, `duration_ms`, `duration_api_ms`, `num_turns`, `stop_reason`, `session_id`, `total_cost_usd`, usage/model usage, permission denials and UUID. Terminal branches include `success`, `error_max_turns`, `error_max_budget_usd`, `error_max_structured_output_retries`, and `error_during_execution`. Notably some limit/error subtypes set `is_error: false`; structured retry and outer-catch paths set it true. Success result text is derived from the last message only when its first content block is non-meta text, and may be empty.
- **Evidence:** `cli.pretty.js:606942-607227`; source needles `error_max_turns` offset 12,211,888 and `error_max_budget_usd` offset 12,213,512.
- **Limit:** `api_retry` is emitted from a `system` event in this driver; this source alone does not establish the precise user-interface rendering of each protocol consumer.

### LOOP-08 — Streaming failures may fall back, while custom API retry policy is separate from the agent-turn loop

- **Scope/version:** request adapter and outer driver, 2.1.80.
- **Label:** source-verified.
- **Actual identifiers:** `uZ6`, `$Eq`, `zEq`, and `Uf8`; the streaming request callback is passed to `Uf8(...)` in `$Eq`, which `uZ6` invokes through `WV1`.
- **Locations:** `cli.pretty.js:545840-546151` (`$Eq` request builder and call to `Uf8`); `546365-546520` stream catch/fallback; `545746-545785` `zEq` non-stream retry helper. Outer driver converts system `api_error` retry metadata into `api_retry` at `607080-607091`.
- **Transition:** the request SDK client is configured with `maxRetries: 0`; `Uf8` supplies the application retry loop. Streaming errors can invoke non-stream fallback unless disabled; retry metadata is yielded as system events. `zEq` also wraps non-streaming fallback requests in `Uf8`. Model fallback is another distinct route: `zgY` catches fallback condition `yY6`, clears orphaned assistant/tool state, switches to fallback model, yields a warning, and retries the model stream.
- **Evidence:** `cli.pretty.js:450617-450630`, `545840-546151`, `546365-546520`, `545746-545785`, `313846-314147`, `607080-607091`.
- **Limit:** Provider-specific conditions remain in `qo9`, `sP4`, `tP4`, and related helpers; the listed classes reflect those predicates, not a universal retry contract. The streaming request itself uses `maxRetries: 0` at the SDK layer, while `Uf8` is the app-level retry loop.

## State map

```text
zgY init (turnCount=1)
  -> stream_request_start -> callModel (stream)
     -> no tool_use: recover/stop hooks -> completed | hook-blocked retry | aborted/error
     -> tool_use: execute/drain tool results
          -> abort => aborted_tools (possibly max-turn attachment)
          -> hook stopped => hook_stopped
          -> refresh context + attachments
          -> next turn > maxTurns => max_turns_reached / max_turns
          -> else transition next_turn -> stream again
```

The outer driver turns generator events and terminal conditions into protocol events and `result` records. API `stop_reason` is captured independently and reported as metadata; this query coordinator’s continuation decision is the presence of tool-use blocks.

## Unknowns and limitations

- No controlled execution was performed, so all findings are source-verified implementation paths, not experimentally observed behavior. `uFq.submitMessage` is the enclosing user-submission driver; it pushes normalized prompt messages into `mutableMessages`, appends model/tool/system events to both its working message list and (when the persistence condition `E` is true) invokes `Gx`. `Gx` deduplicates by UUID and calls `f_().insertMessageChain(...)` for new messages (`cli.pretty.js:538060-538072`). This establishes the persistence call path, while whether persistence is enabled depends on `E` and session backend state.
- The source slice does not prove whether feature gates/environment settings are enabled in a given deployment.
- Exact default `maxTurns`, consumer-specific display of result records, and every retry-classification condition remain unclaimed.
- No inference is made from 2.1.80 to native Claude Code 2.1.302.

### LOOP-09 — Several recovery/compaction branches are statically unreachable in the default query path

- **Scope/version:** default coordinator dependencies and request construction in 2.1.80.
- **Label:** source-verified.
- **Actual identifiers:** `zgY(A,q)`, `zYq()`, `lg(A,q,K)`, `$Eq(...)`.
- **Locations:** `cli.pretty.js:450352-450505`, global initialization `450946`; `lg` at `317852-317854`; `zYq` at `450310-450319`; `$Eq` local `D` and cache-edit branches around `545860-545975`.
- **Reachability:** the module initializes `qw6 = null` at 450946, and all bundle references to `qw6` are reads (no assignment). Thus `zgY`’s `qw6?.isReactiveCompactEnabled()`, withheld-error checks, and `tryReactiveCompact` branch cannot activate in this artifact. `zgY` calls `j.microcompact`; absent caller-supplied `A.deps`, default `zYq()` supplies `lg`, whose body simply returns `{messages:A}`. This makes microcompact a pass-through on the default path, while injected dependency overrides are outside this conclusion. Separately, `$Eq` initializes local `D = !1` and does not assign it; the branches conditioned on `D` for cache-edit setup and cache-edit request handling are unreachable in that function.
- **Evidence:** `rg -n '\\bqw6\\b' cli.pretty.js` shows the reads and sole initialization; `cli.pretty.js:317852-317854`, `450310-450319`, `450946`, and `545860-545975`.
- **Effect:** the max-output-token recovery path in `zgY` is a separate reachable code branch (counter capped by `_gY = 3`); it should not be grouped with the dead reactive-compaction recovery path.

### LOOP-10 — `Uf8` supplies bounded custom API retries with classified errors and backoff

- **Scope/version:** 2.1.80 API request wrapper used by streaming and non-streaming query calls.
- **Label:** source-verified.
- **Actual identifiers:** `Uf8(A,q,K)`, `Ko9(A)`, `UQ6()`, `qo9(A)`, `Vh(A,q,K)`, `aP4(A)`, `oP4(A)`; `Ff8()` is a constant-false function.
- **Locations:** `cli.pretty.js:313852-314147`; streaming invocation at `546118-546151` and non-streaming invocation at `545746-545760`.
- **Transition:** `Uf8` loops for `H=1..Ko9(K)+1`, checks abort between attempts, and throws `RetryError` when it exhausts. `Ko9` defaults to `UQ6`, which honors `CLAUDE_CODE_MAX_RETRIES` or defaults to 10; both main query call sites construct SDK clients with `maxRetries:0` but omit `Uf8`’s `maxRetries` option, so the app wrapper supplies the retry loop. `qo9` accepts retryable network classes, overloaded responses, parsed context-overflow errors, `x-should-retry:true` subject to auth-mode gating, SDK API errors, 408, 409, qualifying 429, 401, revoked OAuth token, and 5xx; `x-should-retry:false` suppresses its override. An eligible context-overflow 400 can instead lower `maxTokensOverride` and immediately retry. The default delay honors `retry-after`, else exponential delay with jitter, capped at 32 seconds (`Vh(H, D)`); `aa9=500ms` is the base. A separate fast-mode rate-limit path can use unified reset headers and turn fast mode off. Since `Ff8()` returns false, `M = Ff8() && rP4(J)` is always false: the persistent long-wait retry path and its six-hour cap are unreachable in this artifact. Retry waits poll abort in chunks only in that persistent path; ordinary delay uses one `ZE(P, signal)` wait.
- **Evidence:** function source lines above; `na9=10`, `aa9=500`, `nP4=300000`, `BL1=21600000`, `oa9=30000`, `Yo9=1800000`, `_o9=20000`, and `zo9=600000` at `314139-314147`.
- **Limit:** the retry predicates incorporate provider/auth feature gates, so the status list is conditional. This describes the default main-query call options, not unrelated uses of `Uf8`.

### LOOP-11 — The query driver persists messages through the session message-chain store

- **Scope/version:** SDK/query driver in 2.1.80.
- **Label:** source-verified.
- **Actual identifiers:** class `uFq`, async generator method `submitMessage(A,q)`; persistence helper `Gx(A,q,K)`.
- **Locations:** `cli.pretty.js:606648-606944` setup and call to `th`; message event handling and append at `606942-607227`; `Gx` at `538060-538072`.
- **Transition/observable output:** `submitMessage` normalizes the prompt, pushes user messages into its mutable transcript, calls `th` with `maxTurns` from config, pushes assistant/user/system messages into both working transcript and `mutableMessages`, then calls `Gx` when its session persistence guard is true. `Gx` deduplicates message UUIDs and writes new messages via `f_().insertMessageChain(...)`. The method yields structured assistant/user/progress/stream/system events and one terminal `result` object. Its `interrupt()` method aborts the shared controller at `607228-607230`.
- **Limit:** the `E` guard and session backend determine whether a given run performs persistence; source presence alone does not prove a particular host configuration.

## Simulated-provider experiment suggestions for Wave 2

A local Messages API fixture can test these paths without Anthropic credentials or live calls:

1. With `maxTurns: 1`, return an assistant `tool_use`, then return a matching tool result through the controlled executor, and verify the coordinator emits `max_turns_reached` and `uFq.submitMessage` emits `result.subtype === "error_max_turns"` after tool work rather than issuing another model request.
2. Return a text-only `end_turn` response and verify no tool execution occurs and the outer driver emits `success` with captured `stop_reason` and the expected first text block.
3. Return `max_tokens` once, then a final text response; verify the recovery prompt/second request occurs and that only the eventual terminal response determines success.
4. Return stream events with `message_start` but no completed content block, then support non-streaming create; verify the fallback branch and `didFallBackToNonStreaming` telemetry. Separately toggle the feature gate that disables fallback to verify the error path.
5. Return retryable 429 with a short `retry-after`, followed by success; set `CLAUDE_CODE_MAX_RETRIES=1` and verify the bounded second attempt and retry event metadata. This should use a local fixture with a small delay, never a real provider.

For minimizing side traffic during local harness work, source-verified environment checks include `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1` (multiple nonessential telemetry/client-data branches check it) and `DISABLE_AUTOUPDATER=1` (the auto-updater disabled-reason helper checks it). These do not replace network isolation of the mock harness; `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC` itself does not disable the model API request.
