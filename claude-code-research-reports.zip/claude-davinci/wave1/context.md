# Wave 1: context, compaction, and prompt caching

This report concerns only the official npm `@anthropic-ai/claude-code` **2.1.80** published bundle. All locations below are in `/workspace/research/claude-davinci/artifacts/claude-2.1.80/cli.pretty.js`, the mechanically formatted derivative of `cli.js`. Raw SHA256: `0b146fe609bd591feb8e6ba689d146b56265076c9c23cee1a351cd2df74b4ec1`. No inference of implementation parity with native 2.1.302 is made. No authenticated CLI/API execution or provider caching measurement occurred.

`evidence/context/source_index.json` contains the exact original function identifier, derivative start/end line, zero-based **raw byte offset**, unique raw needle and needle occurrence count for 75 functions. `function_*.js` files are verbatim bounded excerpts of the derivative, not reconstructed pseudocode. `lines_*.txt` preserve additional control flow with source line numbers. `extract_integrity.json` records that all 75 excerpts contain their declaration, parse with `node --check`, and have a unique raw needle. Raw offsets are authoritative for reproduction; formatting does not create original source paths.

## Principal conclusions

- Real proactive auto-compaction and manual compaction exist. The nominal threshold is the effective input window minus a 13,000-token reserve; the effective window itself subtracts up to 20,000 output tokens. This yields 167,000 with a 200,000 context and an output allowance of at least 20,000. It is not a universal fixed 95% rule.
- The shipped `lg` microcompaction function is a literal no-op for message content. Reactive-compaction and cached-microcompaction branches are present but their controlling values are null/false in this artifact. Their surrounding strings do not establish active behavior.
- Caching annotations select a final-message content block (or penultimate message with `skipCacheWrite`) and system prompt blocks. They are request construction, not proof of a cache hit. One-hour TTL is conditional; absent TTL is emitted on the ordinary path.
- Compaction can replace earlier history with a generated summary and selected restored state; the session-memory alternative can retain a recent verbatim tail, subject to dependency closure. Neither path establishes retained task accuracy without a benchmark.

## Findings

### CTX-01 — context sent to a model is a normalized suffix, not the complete stored transcript

**Label: source-verified. Scope: npm 2.1.80.** Functions `Xk` (544646–544650; raw 10995585), `zgY` (450352–450945; raw 9294723), `YX` (543217–543360; raw 10958461), `$Eq` (545840–546686; raw 11019949).

At each loop iteration `zgY` starts `I=[...Xk(P)]`. `Xk` finds the newest `system/compact_boundary` and returns its suffix, including the marker; no marker means the original array. It then applies `N54` tool-result replacement, calls `lg`, then `sW4` auto-compaction. A successful compaction replaces `I` with `$l(result)`. This is the active model history; it does not mean old on-disk transcript records are erased.

The model request gets `qR8(I,userContext)` plus system prompt `iq(MYq(systemPrompt,systemContext))` at 450418–450421 and 450520ff. `MYq` (545308–545314) appends a joined key/value system-context string to system prompt pieces. `qR8` (545315–545334; raw 11011144) prepends user context as a meta user `<system-reminder>` containing keyed sections. `$Eq` runs `YX` normalization again, optional tool-reference normalization, `sVq` tool pairing repair and `U$_` media-count trimming, and then converts to wire messages with `c$_`.

`YX` removes progress and non-local-command system messages (including compact-boundary metadata), filters API-error messages through `Vs1`, normalizes assistant tool names/inputs, merges same-ID assistant blocks, merges neighboring user messages, and expands attachments via `nc1`. It does not filter a summary user message merely because `isVisibleInTranscriptOnly` is true. The summary is model context. `sVq` (544855ff) removes orphaned/duplicate tool results and creates explicit error tool results for missing pairs. These transformations must precede reasoning about wire-message count or breakpoint position.

### CTX-02 — ordinary token accounting uses usage plus estimates; it is not a tokenizer on every turn

**Label: source-verified. Scope: npm 2.1.80.** `hf` (263712–263734; raw 5370430), `uc` (263633ff), `hU6` (263656ff), `DE` (263664ff), `N5` (464222–464224; raw 9553494), `RU6`/`ic1`/`cc1`/`xdY` (464266–464299).

`hU6(usage)` sums input + cache-creation input + cache-read input + output. `DE` retrieves this total from the latest valid assistant usage. `hf` searches backward for valid assistant usage, walks back through the same message-ID run, then returns that usage total plus `RU6` of subsequent entries; without usage, it estimates the entire supplied array. `uc` excludes specified synthetic/error text and the synthetic model sentinel. This is implementation accounting, not a claim that these fields exactly equal the next request's server tokenization.

`N5(text,q=4)` is `Math.round(text.length/q)`. `xdY` estimates text and serialized tool inputs with `N5`; image/document blocks cost a fixed 2,000; tool results recurse; thinking and redacted-thinking use their string lengths. Attachments are expanded for counting. Separate count-token API helpers exist in the surrounding code, but `Ls9` uses `hf`, not a live count-token call. `FZ6` (317828–317851) is another estimator used by session-memory compaction: it sums supported message block estimates and multiplies by 4/3, rounding up. Do not conflate these estimators.

### CTX-03 — model/window limits and compaction thresholds have layered overrides

**Label: source-verified. Scope: npm 2.1.80.** `UM` (172896–172906; raw 3568447), `io` (172930ff), `aQ6` (546948ff), `ig` (318129–318138), `eQ6` (318139–318152), `IY6` (318153–318173), constants 318224–318229.

`UM` returns 1,000,000 for a permitted `[1m]` model suffix; otherwise uses a configured model's `max_input_tokens >=100000`, capped to 200,000 when the 1M-disable switch applies; otherwise enabled 1M beta/eligibility branches; otherwise 200,000. `CLAUDE_CODE_DISABLE_1M_CONTEXT` affects those branches. Provider/model eligibility remains conditional.

`io` chooses default/upper output allowances by model string (e.g. Opus 4.6 64,000/128,000; Sonnet 4.6 32,000/128,000) with configured model max-token overrides. `aQ6` resolves `CLAUDE_CODE_MAX_OUTPUT_TOKENS` against those limits.

Descriptive formulas, not original function aliases:

```
output_reserve = min(aQ6(model), 20000)
window = UM(model,bH())
if positive parsed CLAUDE_CODE_AUTO_COMPACT_WINDOW:
    window = min(window, override)
effective_window = window - output_reserve                  // ig
threshold = effective_window - 13000                        // eQ6
if valid 0 < CLAUDE_AUTOCOMPACT_PCT_OVERRIDE <= 100:
    threshold = min(floor(effective_window * pct / 100), threshold)
blocking_limit = effective_window - 3000                    // IY6
```

A positive `CLAUDE_CODE_BLOCKING_LIMIT_OVERRIDE` replaces the blocking limit. Warning/error thresholds are each 20,000 below the percentage-display reference window. With auto-compaction enabled that reference is the compaction threshold; otherwise it is the effective window. The branch tests are inclusive `>=`. Small positive window overrides can produce nonpositive effective/auto thresholds; no lower clamp appears in `ig`/`eQ6`. These are static calculations; no actual context size was experimentally exercised.

### CTX-04 — proactive auto-compaction has exclusions, a memory-first fallback and a failure counter

**Label: source-verified. Scope: npm 2.1.80.** `Lh` (318174–318178), `Ls9` (318179–318190), `sW4` (318191–318223; raw 6890891), `zgY` 450420–450479.

`Lh` is false if truthy `DISABLE_COMPACT` or `DISABLE_AUTO_COMPACT`; otherwise it returns `D8().autoCompactEnabled`. `Ls9` also excludes exact query sources `session_memory` and `compact`, then tests `IY6(hf(messages)-freedTokens,model)`. The main loop currently supplies `b=0` as freed tokens. Microcompaction does not supply an actual freed-token count in this bundle.

`sW4` skips when compaction is disabled, passed tracking has `consecutiveFailures >=3`, or `Ls9` is false. If due, it first tries `vZ8` session-memory compaction. A successful memory result clears the summarized pointer (`L66(undefined)`), resets compaction-related caches/state with `Jl(querySource)` and returns it. Otherwise it calls `bZ6(...,Y=true,customInstructions=undefined,z=true,tracking)` to generate an automatic summary. Success returns `consecutiveFailures:0`; failure increments the previous counter and returns no compaction. At three failures it emits a circuit-breaker warning. `zgY` stores this tracking for subsequent iterations. The warning says “this session,” but the demonstrated storage is loop-chain tracking; persistence across separately created `zgY` calls is not established here.

When no successful compaction occurred and the source is neither compact nor session_memory, the main loop checks the blocking limit before a model call (450498–450512). The reactive bypass cannot activate in this bundle (CTX-09). Thus failure/disabled compaction can lead to a locally generated prompt-too-long error and `reason:'blocking_limit'`.

### CTX-05 — manual `/compact` has a concrete command path and different continuation behavior

**Label: source-verified. Scope: npm 2.1.80.** Original variable callback `LrY` (476217–476252; raw needle `LrY=async`, offset 9769054), command object `hrY` (476274–476289), `eOq` (476187–476215), `bZ6` (316897–317055; raw 6863533).

The command object is named `compact`, supports noninteractive use, and is enabled unless `DISABLE_COMPACT` is truthy. Empty history fails. With no custom instruction text, `LrY` first attempts `vZ8`; with nonempty instructions it bypasses that memory-only shortcut. It then obtains `(await lg(messages,context)).messages` and calls `bZ6(...,Y=false,customInstructions,z=false)`. `eOq` constructs current default/custom/append system prompt, user/system context and fork history for the cache-sharing branch.

Manual success returns `{type:'compact',compactionResult,displayText}` and clears state/caches. Manual errors are mapped to canceled/not-enough-messages/interrupted/general errors. `tOq` is initialized null (raw 9769045); the reactive-only manual alternative cannot run in the inspected bundle. The automatic `Y=true` argument causes the injected summary wrapper to request immediate continuation; normal manual `Y=false` omits that instruction. A request to compact is not itself evidence the subsequent user task was completed.

### CTX-06 — generated compaction creates a summary plus selected state and explicit history metadata

**Label: source-verified. Scope: npm 2.1.80.** `bZ6` (316897–317055; raw 6863533), `$l` (316866–316874), `rQ6` (544604–544624; raw 10994928), `dQ6` (314914–314933), `YW4`/`OZ8`/`_W4`/`zW4`/`wW4` (317366–317441).

`bZ6` calls pre-compact hooks (`xZ6`), combines hook-provided custom instructions, generates the summary via `KW4`, and rejects absent summary text, API-error text or a prompt-too-long summary response. It snapshots/clears read-file state and reconstructs attachments from up to five recent eligible files (`t04=5`), each read with a 5,000-token read limit and aggregate estimated attachment cap of 50,000; plan and memory files are excluded from this file restore. It also restores completed/unretrieved local-agent task statuses, a plan-file reference, plan-mode reminder, invoked skills, and currently relevant dynamic tool/MCP information. SessionStart hooks with source `compact` and PostCompact hooks run; their results/display text are included.

The boundary marker records manual/auto trigger, preTokens and logical parent UUID; discovered tool names are saved sorted in metadata. The summary is a meta user message flagged `isCompactSummary` and `isVisibleInTranscriptOnly`. `dQ6` embeds the summary, a transcript path when available and, for auto continuation, the explicit resume instruction. `Co9` removes an `<analysis>...</analysis>` block and converts `<summary>` into retained summary text. This is output processing; completeness/accuracy is not programmatically proven.

`$l` orders the new context as **boundary, summary messages, optional messagesToKeep, attachments, hook results**. `bZ6` ordinarily has no `messagesToKeep`. Its `postCompactTokenCount=DE([summaryResponse])` includes summary-request usage, while `truePostCompactTokenCount=RU6(newContext)` estimates the newly assembled context. These telemetry fields must not be treated as equivalent. `Jl` resets cached microcompaction scaffolding, selected memory/prompt caches, tool-discovery/permission-related transient state and other compaction state; main-thread or SDK sources additionally clear `kz`/memory-related state. Ordinary generated summary compaction clears old API usage from active history so next estimates are initially local estimates.

### CTX-07 — compaction request can share the previous request prefix, behind a feature flag

**Label: source-verified. Scope: npm 2.1.80.** `KW4` (317213–317365; raw 6870381), `xf` (451534ff), `nE` (451411–451419), `y04` (314878–314893), `zs9` (316831ff).

If `A1('tengu_compact_cache_prefix',false)` is true, `KW4` first forks through `xf` with the supplied `cacheSafeParams`, the summary request appended, `querySource:'compact'`, `maxTurns:1`, `skipCacheWrite:true` and a tool-denial callback `ws9`. `xf` retains supplied system/user/system context and existing history; this makes reuse of the prior request prefix possible. If the returned assistant has text, it uses it and logs a cache-hit ratio calculated from provider usage. Error/no text falls back.

The fallback normalizes `zs9([...Xk(history),summaryRequest])`, replacing user image/document content (including nested tool-result media) with textual placeholders. It uses a dedicated summarizing system prompt, thinking disabled, main-loop model and max output `min(20000,aQ6(model))`. Its selected tools are Read, or a conditional Read/search/MCP set; therefore the *fallback* tool prohibition is in the `y04` prompt, not the same programmatic `ws9` permission callback. `y04` requests only `<summary>...</summary>` text, but this does not prove model compliance.

`A1('tengu_compact_streaming_retry',false)` permits two total fallback attempts rather than one, specifically when no assistant message was obtained; backoff is abortable. It does not establish blanket retry on every thrown compaction error. Flag values and actual provider hit rates were not measured.

### CTX-08 — session-memory compaction is a separate, conditional path with tail preservation

**Label: source-verified. Scope: npm 2.1.80.** `GZ8` (317983–317989; raw 6887200), `vZ8` (318019–318051; raw 6888046), `Ts9` (317956–317982), `JR1` (317919–317955), `ks9` (317990–318018), `SW4`/`EW4` (317706–317747; raw 6881752), `Ak_` callback (597039ff), `ugq` (596970–596974; raw 11876778).

`GZ8`: explicit enable env `ENABLE_CLAUDE_CODE_SM_COMPACT` wins first; else disable env `DISABLE_CLAUDE_CODE_SM_COMPACT`; else both `tengu_session_memory` and `tengu_sm_compact` must be true. This switch controls consuming session memory. Memory *production* has its own `tengu_session_memory` gate in `rT_`.

`ugq` registers `Ak_` as a post-sampling hook only outside its `i4()` excluded mode and while `Lh()` is enabled. `Ak_` runs only for exact query source `repl_main_thread`, when session-memory flag and update thresholds pass. Defaults are 10,000 tokens to initialize, 5,000 tokens between updates and three tool calls between updates; the condition also permits updates when the current tail is not a tool-use continuation. It creates/reads `session-memory/summary.md`, forks with an update prompt, and `qk_` permits only the Edit tool on that exact memory file. Custom template/prompt files are supported. This is a real implementation path but not evidence those flags were enabled for a user.

`vZ8` waits for a pending extraction, bounded by 15 seconds of wait and a 60-second stale-operation cutoff (`XW4`, 317508–317515), then reads the memory file. Missing/empty-template memory causes fallback to generated compaction. It uses the last summarized UUID when available; an absent UUID in history causes fallback. On resumed state without a pointer it records the resumed branch.

`Ts9` chooses a recent tail using defaults min 10,000 estimated tokens **and** five messages with text, or max 40,000, configured by `tengu_sm_compact_config`. `JR1` moves the split backward to include assistant tool calls referenced by retained results and all prior blocks sharing retained assistant message IDs. This dependency closure can expand the tail past the nominal token bound. `ks9` constructs boundary + memory-summary wrapper + preserved tail + optional plan reference + compact SessionStart hook results. `SW4` truncates each memory section to roughly `2000*4` characters and points to the full file if truncated. `vZ8` rejects a result whose estimated new-context tokens are **>=** supplied auto threshold. There is no generated-summary call within the successful memory-compaction path itself; background memory extraction may have called a model earlier. Cost/quality benefit remains unmeasured.

### CTX-09 — microcompaction and reactive compaction scaffolding are dormant here

**Label: source-verified. Scope: npm 2.1.80.** `lg` (317852–317854; raw 6884759), `qw6=null` (450946; raw 9306525), `tOq=null` (476216; raw identifier 9769045; declaration `var tOq=null` at raw 9769041), `$Eq` local values (545887ff; raw needle `D=!1,P="",W=` offset 11020898).

The complete implementation is `async function lg(A,q,K){return IW4(),{messages:A}}` in raw syntax. It resets a flag through `IW4` and returns the same array. Helpers for cache edits, tool-result estimation and pinned deletions exist, but this function performs no deletion, summarization or replacement.

The main-loop reactive-compaction object `qw6` is initialized null and has no assignment elsewhere in the inspected bundle; all later property accesses are guarded. Therefore the `tryReactiveCompact` request retry and media-error withholding cannot activate through this object. The manual counterpart `tOq` is also null with no assignment. In `$Eq`, cached-microcompact `D=false` and beta-name `P=''` remain unchanged, so its `D && ...` cache-edit injection/beta path cannot activate. `c$_` implements that optional branch but the ordinary caller passes false.

Separately, `N54` tool-result persistence can mutate request context when replacement state exists; `G54` creation is gated by `tengu_hawthorn_steeple`. It must not be mistaken for an active `lg` microcompaction implementation. `tx7` (180631–180637; raw 3728997) conditionally builds server `context_management:{edits:[{type:'clear_thinking_20251015',keep:'all'}]}` when thinking is on and `tengu_marble_anvil` is true; the request includes it only with the relevant beta. The string names alone do not prove server-side deletion or active client microcompaction.

### CTX-10 — output exhaustion retries three times; input-too-long does not gain active reactive recovery

**Label: source-verified. Scope: npm 2.1.80.** `$Eq` (546347–546375), `zgY` (450685–450756), `$Yq` (450339–450341), `_gY=3` (450948; raw 9306543), `Mf8` (306788ff).

On streamed stop reason `max_tokens`, `$Eq` emits an assistant API error with `apiError:'max_output_tokens'`; `model_context_window_exceeded` maps to the **same** `apiError`. The main loop withholds these sentinel messages. If the last response is this error and recovery counter is <3, it appends prior partial assistant output plus a meta user instruction (“Output token limit hit. Resume directly… Break remaining work into smaller pieces”), clears max-output override, increments the counter and loops with transition `max_output_tokens_recovery`. The next iteration can run ordinary auto-compaction. At the cap it yields the error and returns through the API-error completion path. This is bounded continuation, not guaranteed successful recovery.

`Mf8` maps error text containing “prompt is too long” to an invalid-request assistant sentinel. With `qw6=null`, no reactive compaction occurs for it: the sentinel is yielded, then `W6?.isApiErrorMessage` returns `{reason:'completed'}`. That reason describes stopping the loop, not successful work. A proactive local blocking-limit error stops earlier with `reason:'blocking_limit'`. Distinguish API input-too-long errors from streamed model-window exhaustion mapped into output recovery.

### CTX-11 — prompt cache enablement is conditional but on by default in the helper

**Label: source-verified. Scope: npm 2.1.80.** `YEq` (545544–545562), `$Eq` (545965ff and 546013ff).

`YEq` returns false for truthy global `DISABLE_PROMPT_CACHING`, or matching canonical Haiku/Sonnet/Opus model IDs when the corresponding per-family disable variable is set; otherwise true. `$Eq` uses `options.enablePromptCaching ?? YEq(model)`, so an explicit boolean option wins over env-derived enablement. It resolves this for system blocks and again for message controls during request construction. Do not infer an option's value from the helper's default. Schema/tool content and extra-body overrides can also alter the final request. The visible cache controls are client instructions to a provider, not evidence of acceptance or reuse.

### CTX-12 — message breakpoints are chosen by position after normalization

**Label: source-verified. Scope: npm 2.1.80.** `c$_` (546773–546846; raw 11037995), `B$_` (545650–545682), `g$_` (545683–545713).

`c$_` chooses index `messages.length-1`, or `messages.length-2` with `skipCacheWrite:true`. For the chosen user message, string content becomes a text array with cache control; array content gets it on its last block. Assistant strings behave similarly; assistant array content is annotated only if its last block is neither thinking nor redacted-thinking. It does **not** search backward for another eligible block if the selected last assistant block is thinking. A one-message `skipCacheWrite` request has index -1, hence no new message breakpoint. The implementation copies existing fields, so incoming cache controls can survive; the helper is not a proof of a globally enforced maximum breakpoint count.

In the optional cache-edit branch it replays pinned edits, deduplicates by cache reference, injects a pending edit into a recent user message and gives preceding eligible tool results cache references. CTX-09 explains why the ordinary `$Eq` path does not activate it here.

### CTX-13 — TTL generation omits the TTL field unless a gate permits one hour

**Label: source-verified. Scope: npm 2.1.80.** `rg` (545563–545569; raw 11015352), `u$_` (545570–545581; raw 11015470).

`rg` always returns `{type:'ephemeral'}`, adds `ttl:'1h'` if `u$_(querySource)`, and serializes `scope:'global'` only for that exact scope. Internal `org` cache scope is not emitted as a scope field.

`u$_`: Bedrock plus truthy `ENABLE_PROMPT_CACHING_1H_BEDROCK` immediately returns true. Otherwise `nA()` must be true and `lG.isUsingOverage` false. It loads a session-stored allowlist from `tengu_prompt_cache_1h_config` if not already stored, then requires a defined query source matching an exact allowlist entry or a trailing-`*` prefix pattern. No default 1h is emitted outside those gates. The helper itself does not emit `ttl:'5m'`; inferring actual five-minute expiry would require the provider contract or observation, not this code. `nA()` identity classification is not independently expanded in this report; treat it as the exact predicate named here.

### CTX-14 — system prompt caching can separate a static global prefix from dynamic context

**Label: source-verified. Scope: npm 2.1.80.** `Is1` (545225–545307; raw 11009573), `l$_` (546847–546865), `R56` (173039–173045), default prompt assembly (304175–304210), marker `MY6` (304359).

Global system caching requires `R56()`—firstParty or foundry and no truthy `CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS`—plus force-env or `tengu_system_prompt_global_cache`. The default prompt assembly places `__SYSTEM_PROMPT_DYNAMIC_BOUNDARY__` after its static blocks, before assembled memory/environment/MCP/scratchpad and similar variable blocks.

If global mode and marker exist, `Is1` separates attribution/billing and identity blocks, joins pre-marker content into a `global`-cacheable text block and joins post-marker content into an unannotated dynamic block. If global mode is requested but marker absent, it logs and falls back to normal grouping. If `skipGlobalCacheForSystemPrompt` is set (the `$Eq` caller does this when MCP tools or tool-search schema require that handling), it omits the marker, groups identity/rest with internal `org` scope and does not create the global block.

Without global mode, billing is uncacheable, identity and the joined rest are internal `org`-cacheable blocks. `l$_` converts these to text wire blocks and attaches `rg` controls only when enabled and `cacheScope!==null`. Thus in ordinary nonglobal grouping, dynamic system text may share the same annotated system block; do not claim a universal static/dynamic cache split. `lR8` supports schema `cacheControl`, but `$Eq`'s normal schema-map call shown here does not pass it. Global handling computes beta/scope variables but does not itself prove an extra tool breakpoint is attached.

### CTX-15 — source contains stability measures and observability, not an authoritative backend cache key

**Label: source-verified. Scope: npm 2.1.80.** `xf` (451534ff), `KW4` (317213ff), `j78` (39529ff), `qEq` (545215ff), `K19`/`Ou7` (180861–180894), `kH8` (180835–180849), `J16` (546693–546732; raw 11036006), `YR8` (546733–546763; raw 11037058).

Concrete measures relevant to prefix stability are reuse of system/user/system-context/history via `cacheSafeParams`, penultimate-message breakpoint placement for forked compact/suggestion requests, fixed boundary grouping, persisted tool-result replacements, and memoized user/system context. These measures retain specified inputs when reused by the caller; byte-identical wire prefixes have not been measured here. Changing model, prompt blocks, tool descriptions/order/deferred schemas, media normalization, history compaction or injected context can change the serialized request. Exact cache invalidation/prefix-matching rules live on the provider side and are not established by this bundle.

`qEq` hashes the first grouped system block for telemetry. `Ou7` derives a three-hex-character attribution suffix from characters 4,7,20 of the first normalized user text and version; `kH8` embeds it in the billing header. These are not evidence of the provider's cache-key algorithm. `j78` stores the request minus messages for main-thread diagnostics; its exact field capture is distinct from cache ownership.

`J16` merges response usage and per-TTL cache-creation counters; `YR8` aggregates totals. `KW4` can log `cache_read/(cache_read+cache_creation+input)` from the returned usage. Counter-plumbing source is not an observed cache hit. No benchmark here supports cache savings, reduced latency, retained task success, superior compaction quality or native-version parity.

### CTX-16 — backend cache behavior and task-level effects remain unmeasured

**Label: unknown. Scope: npm 2.1.80 and native 2.1.302. Function: unknown (backend implementation unavailable).** The provider cache-key algorithm, actual TTL expiry, cross-request hit rate, latency/cost savings, retained task accuracy and parity with the native version are not established by any source or experiment in this report. CTX-11 through CTX-15 demonstrate request construction and usage-counter processing only. No benchmark or authenticated provider trace was performed.

## Reproduction and evidence integrity

Run from any cwd:

```bash
python /workspace/research/claude-davinci/evidence/context/extract_evidence.py
python -m json.tool /workspace/research/claude-davinci/evidence/context/source_index.json
rg -n 'qw6|tOq|function lg|function\* \$Eq|cache_control|tengu_compact_cache_prefix' /workspace/research/claude-davinci/artifacts/claude-2.1.80/cli.pretty.js
```

Search the raw `cli.js` for the exact `raw_needle` in the index, or seek to `raw_byte_offset`. Every cataloged needle had occurrence count one. Excerpts were syntax-checked locally; no full CLI import/execution was used for this validation. Initial extractor used Python `splitlines()`, which wrongly counted Unicode line separators inside string literals; it was corrected to literal LF splitting, all excerpts regenerated, and all 75 checked. Earlier invalid excerpt files were replaced.

`helper-fixtures.cjs` is a **draft** pure-helper VM fixture for Wave 2. It is not a controlled CLI test or provider observation. An initial attempt failed on the earlier extraction issue before assertions; the corrected fixture has intentionally **not been executed** in Wave 1. There is no successful fixture-result artifact or experimental claim. Wave 2 should inspect the fixture dependencies before execution.

## Uncertainties, contradictions and proposed experiments

1. **Unknown actual feature flags.** This bundle contains remote flags with false defaults and optional env overrides; static presence does not establish live enablement. Controlled fixtures should distinguish forced true/false paths and mark them simulated.
2. **Dormant vs active contradiction resolved.** Names/log strings suggest cached microcompaction/reactive compaction, but the actual controlling functions/values here are no-op/null/false. Do not import claims from third-party reverse engineering or another version. This is the most consequential source constraint.
3. **Circuit-breaker lifetime.** Source log says session-wide but tracked state is visibly loop-chain-local. Run repeated calls in an isolated harness to establish whether caller state carries it across query chains; current claim is bounded to demonstrated tracking.
4. **Threshold fixtures.** Pure helper cases: effective 180k/auto167k/block177k for a 200k context with >=20k output cap; 100k override gives effective80k/auto67k; 1M gives effective980k/auto967k; 50% overrides lower threshold; 99% cannot exceed reserved threshold. Test exact boundaries, disabling switches and small overrides. These are suggested expected formulas, not executed outcomes.
5. **Cache serialization fixture.** Test normalized final-user/assistant/thinking blocks, disabled cache, one-message `skipCacheWrite`, stale preexisting annotations, all global-boundary branches and one-hour allowlist/overage cases. Capture complete request JSON to an explicitly simulated local provider. Compare identical prefixes byte-for-byte; do not label a local fixture's synthetic usage as Anthropic cache performance.
6. **Compaction transitions.** Simulate pre-hook custom instructions, summary with/without text, two no-assistant fallback attempts, cache-prefix fork fallback, auto failure counter and blocking limit, session-memory stale/missing UUID and dependency-crossing tail preservation. Verify exact post-summary request ordering and restored attachments, not merely UI output.
7. **Recovery cases.** Simulate `max_tokens`, `model_context_window_exceeded`, input-too-long HTTP error and no text. Count resume attempts and assert the distinction between loop completion reason and meaningful task completion. Provider-side truncation/caching remains unknown.
8. **User-visible memory fidelity.** A future authorized benchmark should include exact-code, pending-task, user-correction and tool-dependency retention across ordinary/memory compaction. Savings/task-success claims require controlled comparison and realistic workloads; source prompts are insufficient.
