# Claude Code / DaVinci runtime research

User-authorized research only. Do not modify /workspace/davinci. Research files belong below /workspace/research/claude-davinci. Maximum four concurrently active subagents. Three ordered waves.

Primary target: official npm @anthropic-ai/claude-code 2.1.80, whose published cli.js contains inspectable implementation. cli.pretty.js is a mechanically formatted derivative, not reconstructed pseudocode. Cite exact original minified function identifiers and derivative line ranges; retain a unique raw-source needle or byte offset for reproducibility. Do not assign invented original source paths or semantic function names without marking descriptive aliases.

Separately inventoried installed target: native Claude Code 2.1.302, ELF x86-64 with Bun bytecode. SHA256 60d7eb7f12fbb28a52533fe8be5884097403562aa02dc73991a021c7067e29a5. Its strings establish presence, not execution or parity with 2.1.80. Never generalize 2.1.80 mechanisms to 2.1.302 without evidence.

DaVinci source pin: 53e999a7fc24c721c484a710093eeeff611641bf at /workspace/davinci. Read applicable AGENTS.md. No source, test, manifest, lockfile, or configuration mutations there.

Each finding must have a stable claim ID, scope/version, exact path, actual function name (or explicitly unknown), source locations/byte offsets or reproducible experiment output, state transitions, and one label: source-verified, experimentally observed, inferred, unknown. Static paths are conditional implementation evidence, not proof a feature is enabled. Strings/prompts are not runtime enforcement. Documentation and third-party decompiled material are secondary leads only.

Each wave agent owns one report and its own evidence subdirectory; do not overwrite other agents' files. Reports must include reproducible commands, unresolved contradictions, unknowns and limitations. Avoid dumping whole bundles into tool output. Retain raw logs and machine-readable results for experiments. No task-success or efficiency claims without a benchmark; no live authenticated model calls or paid API setup without lead coordination. Controlled local fixture endpoints are permitted and must be identified as simulated providers, never Anthropic observations. Never print, copy or persist credentials. Inspect credential names/presence only if necessary.

Wave 1: loop/completion, tools/permissions/recovery, context/compaction/cache, delegation/worktrees/teams.
Wave 2: prompt assembly and controlled pinned-version experiments.
Wave 3: DaVinci source comparison and independent evidence audit.

Lead integrates results into a single bounded end-to-end specification, resolves contradictions explicitly, and prioritizes recommendations by evidence, expected engineering benefit and verification cost. Missing evidence remains unknown.
