# Wave 3: source-checked DaVinci implementation proposals

Scope: DaVinci commit **53e999a7fc24c721c484a710093eeeff611641bf**, read at `/workspace/davinci`. This is a research deliverable, not an implementation. No DaVinci source, tests, dependencies, settings or credentials were changed; no Rust build/test, worktree cleanup or provider request was executed. The checkout was clean and every proposal-specific source file was byte-compared with its pinned Git object. `rtk` was unavailable in PATH, so inspection used raw shell commands.

Paths and inclusive LF line spans below refer to that checkout. Actual identifiers are used for existing functions; proposed types, fields, states and test names are explicitly future design. Additional numbered source excerpts and SHA-256 hashes are in [`evidence/proposals/source_index.json`](../evidence/proposals/source_index.json), alongside [`inspection.json`](../evidence/proposals/inspection.json). Existing comparison evidence remains unchanged. These recommendations do not infer Claude Code native 2.1.302 behavior from npm 2.1.80.

**Evidence labels:** **source-verified** means conditional behavior established from the pinned implementation and call sites. **Inferred** marks a plausible consequence or expected benefit, not an observed incident or measured improvement. **Unknown** means this research has no adequate execution/measurement evidence. Proposed state machines and validation scenarios are future requirements, not claims about current code.

## Priorities and dependencies

| ID | Priority | Smallest useful delivery | Basis and limit |
| --- | --- | --- | --- |
| REC-01 | P1: correctness | Typed run termination through the host, print/JSON/RPC consumers and worker adapter | Source-verified outcome ambiguity. Does not prove any real task was falsely completed. |
| REC-02 | P1: recoverability | Checked cleanup postconditions, retained tracking, truthful caller metadata | Source-verified ignored cleanup failures. Fault frequency and platform incidence are unknown. |
| REC-03 | P2: optional recovery, after REC-01 | Opt-in bounded continuation for a genuinely tool-free text `Length`, with explicit exhausted outcome | Expected completion benefit is inferred; subscription-route prevalence and cost are unknown. |
| REC-04 | P1 as an evidence prerequisite for tuning; no live campaign authorized here | Freeze a route/model/effort-specific comparison and reuse the existing benchmark with its limits visible | Source comparison cannot establish task-quality or subscription savings. Run only within a separately requested finite campaign. |

REC-01 and REC-02 can be delivered independently. REC-03 needs REC-01 because the present exit reducer can treat a recovered earlier `Length` as a final failure. REC-04 is required before claiming performance/quality gains or changing defaults on efficiency grounds; it need not delay deterministic correctness fixes. There is no proposal to replace the scheduler, permission/journal authority, existing completion gates, prompt architecture, teams or context VM.

## REC-01 — Make run termination typed and consume the settled outcome

### REC-01-S1: current state transitions

**Source-verified.** `Agent::run_loop_body`, `crates/davinci-agent/src/turn.rs:402–428`, checks persistence, then abort, then a positive `max_model_turns`. On exhaustion it appends and persists an ordinary assistant notice, emits `MessageStart/MessageEnd`, calls `finish_run`, and returns `Ok(events)`. `finish_run`, `turn.rs:317–331`, emits `AgentEnd { messages, will_retry: false }`, clears streaming and flushes pending Bash messages. `AgentEvent::AgentEnd`, `crates/davinci-agent/src/events.rs:43–48`, has no terminal reason.

The cap is **not** an unconditional failure once N responses have been obtained. It is checked only when another loop iteration is entered. On the Nth turn, tool execution and result persistence occur at `turn.rs:972–997`; tools, completion reminders or queued input may require another iteration (`859–881,967–969,1014–1036`), which then encounters the cap. Conversely, an Nth-turn no-tool response that passes the gates and has no pending work reaches ordinary termination (`1039–1053`) without the max-turn notice. Effects from that Nth tool batch are not rolled back when the next iteration is refused.

`turns_this_run` is initialized per run (`367`), incremented just before `complete_with_retry` (`645–653`), and is independent of the lifetime `stats.model_turns`. `complete_with_retry`, `1194–1218,1254–1327`, can call the completion closure multiple times for one such increment. Therefore this cap bounds coordinator model turns, **not physical provider attempts**. None and zero omit this cap (`409`); worker defaults/overrides are applied in `crates/davinci-coding-agent/src/main.rs:2395,2521–2522`. Existing test definition `the_loop_stops_at_max_model_turns`, `turn.rs:5304–5337`, asserts three closure calls, cumulative stats, notice and idle state; it does not assert a typed failure or downstream worker handling. This test was not run here.

**Source-verified consumer chain.** `print_text_exit`, `main.rs:4476–4537`, recognizes design-command and session-persistence metadata plus any `Length/Error/Aborted` assistant update. A max-turn notice has none of those fields. `complete_prompt_with_host` selects the last nonempty assistant text (`3550–3571`); `run_worker_turn`, `2693–2706`, returns `Ok(text)` when the exit reducer yields zero and text is nonempty. `run_nested_subagent`, `2746–2771`, passes this result to oneshot or teammate execution. `run_journaled_subagent`, `crates/davinci-agent/src/subagent.rs:1361–1400`, converts runner `Ok` to a successful `ToolResult`; `run_tool` maps it to `AgentState::Completed` and a completed tool status (`1164–1213`, multi-worker `1250–1257`). Async completion similarly uses `outcome.is_ok()` (`1060–1089`). Teammate turns use the result to report/reset failure count and wait (`runtime/team.rs:423–458`). This is a concrete chain through which a limit notice **can** be treated as completed, absent another recognized error. It is not evidence that every bounded run is misclassified.

### REC-01-S2: two terminal consumer constraints

**Source-verified.** `print_text_exit` scans all events backward but does not return success upon encountering a later successful response (`main.rs:4497–4535`). An earlier `Length` can therefore still yield exit 1 after a later successful continuation. This applies to the source-defined truncated-tool retry path as well as a future text continuation. Do not fix it merely by choosing the last message: persistence, session or admission failures can supersede the provider answer.

The host deliberately withholds final `AgentEnd { will_retry:false }` while session calls settle (`main.rs:3379–3393`), then can replace it for conversation/session failures (`3794–3834`). It also synthesizes terminal events for runtime attachment errors (`3124–3148`), Codemode activation errors (`3168–3187`) and outright loop errors (`3528–3544`). A type added only to the ordinary Agent completion branch would miss these paths. Existing event documentation says the base event shape is locked to a vendor contract (`events.rs:5`), so compatibility needs explicit handling.

### Proposed implementation scope

1. Introduce an additive, versioned terminal descriptor at the Agent/host boundary. A candidate field is `outcome` on `AgentEnd` with an explicit legacy/unknown default on deserialization; the exact Rust/JSON spelling must be reviewed against the vendor contract. Candidate reason values are `loop_completed`, `model_turn_limit`, `output_limit`, `aborted`, `provider_error`, `persistence_error`, `admission_error`, and `session_error`. These are **proposed identifiers**. Do not deserialize an absent reason as successful. Keep `willRetry` as retry lifecycle information rather than repurposing it as success.
2. Classify every terminal producer, including `finish_run`, normal no-tool finish, error/abort/length branch, top-of-loop cancellation and host-synthesized failures. Keep detailed strings as display data and include observed turns/configured limit where relevant. Preserve the persistence-before-notice guarantee: a failed notice write must yield a persistence failure, never a successful limit outcome. Do not emit a duplicate final terminal event to compensate for a missing field.
3. Use a shared outcome reducer for print, JSON/RPC and `run_worker_turn`. The host's final settled outcome is authoritative for the current run; intermediate provider `Length` stays in diagnostics without poisoning a later recovered outcome. Persistence/admission/session failures remain failures even if a provider answer exists. Preserve events from earlier runs rather than allowing a new run's success to erase an earlier failed run in a multi-prompt print invocation (`main.rs:4149,4207` consume `all_events`). Legacy-only streams require a documented conservative fallback and retain existing errors; do not infer success solely from nonempty prose.
4. The smallest compatible worker fix may map limit/abort/error outcomes to `Err` through the existing runner API, carrying partial output and reason. A larger typed worker-result API may represent incomplete separately, but it must update oneshot, multi-worker, async and teammate call sites together. Do not automatically mark related tasks done or silently relaunch a turn-limited worker. Preserving its worktree and showing a resumable limit is preferable to classifying it as completed.
5. Keep run termination distinct from task correctness and verification evidence. `loop_completed` means the loop reached its normal completion boundary, not “all requested work has passed independent tests.” Existing requirement/capability/mutation gates and incomplete-evidence telemetry stay intact. Do not broaden the semantic meaning of runtime provider status `completed` (`turn.rs:654–659`) into task success.

**Proposed transition:** Running → either normal gates and no pending work → LoopCompleted; next request needed with bound exhausted → ModelTurnLimit; cancellation → Aborted; unrecovered Length → OutputLimit; producer/settlement failure → corresponding Failure. Host settlement may replace an earlier provisional completion with a failure before one final event reaches consumers. Limits do not authorize effect replay or rollback.

**Inferred benefit/risk.** A structured reason should prevent status confusion in scripts and delegation, and make failures auditable without parsing English notices. Compatibility churn, consumers that ignore additive fields, precedence mistakes and accidental loss of intermediate diagnostic events are implementation risks. Real-world incidence, quality benefit and token/latency effect are **unknown**.

### Reproducible future validation scenarios

Use `Agent::run_loop` with deterministic completion closures and disposable repositories, not live providers. Extend the existing max-turn fixture with consumer tests; proposed case names below do not exist yet.

| Scenario | Input and deterministic assertion |
| --- | --- |
| REC-01-V1 next-iteration cap | Set cap 1; closure returns a complete allowed Read tool call. Assert one model turn, one terminal tool result, no second closure call, final `model_turn_limit`, print nonzero and worker non-completed. No task-board completion side effect. |
| REC-01-V2 final answer exactly at cap | Cap 1; a no-tool Stop text answer with no unsatisfied gates/queues. Assert one call and `loop_completed`, not `model_turn_limit`. |
| REC-01-V3 reminders/steering | At the last allowed turn make a requirement/hook reminder or queued follow-up require continuation. Assert a limit outcome before another request, with durable input retained and no artificial success. |
| REC-01-V4 cap meaning | Start lifetime stats at 7; verify the per-run bound remains independent. Test zero and None. With controlled retryable completions, show provider attempts can exceed coordinator turns; preserve this distinction rather than relabeling the cap. |
| REC-01-V5 recovery precedence | Feed a Length response then successful Stop under a supported continuation; assert intermediate Length remains visible and final exit is zero. Follow success with a session/persistence failure and assert failure wins. With two print prompts, a failed earlier run must remain a failed invocation. |
| REC-01-V6 compatibility and all producers | Round-trip new terminal events; deserialize old events into explicit unknown. Cover abort before request, abort during response, runtime/Codemode admission, closure error and final settlement failure. Assert one settled terminal event to the stream sink. |
| REC-01-V7 delegation | Drive oneshot, async, multi-worker and teammate adapters with bounded/aborted worker results; retain partial output, preserve worktree metadata, and do not emit completed status for the bounded turn. Keep separate explicit teammate stopped/idle-timeout semantics. |

Existing coverage can be rerun later with `cargo test --locked -p davinci-agent the_loop_stops_at_max_model_turns` and `cargo test --locked -p davinci-agent zero_max_model_turns_does_not_limit_a_run`. After implementation, run new affected Agent and coding-agent consumer tests, formatting and appropriate package checks. These commands were **not run** in this research; existing tests alone do not validate the proposed contract.

## REC-02 — Preserve tracking until worktree cleanup is proven complete

### REC-02-S1: current state transitions and caller differences

**Source-verified.** `WorktreeManager::{is_dirty,check_dirty}`, `crates/davinci-agent/src/runtime/worktree.rs:283–323`, treats unreadable Git status/revision as error/dirty, retains untracked/uncommitted work, and checks worker commits against current repository HEAD ancestry or patch equivalence. A missing path returns clean (`301–302`); this is not proof Git registration or the branch is gone. `release_lease`, `327–386`, checks dirty state and preserves it unless forced. It then attempts `git worktree remove --force` (`347–350`), attempts `remove_dir_all` if the directory remains (`351–354`), and deletes only default-prefix branches with `git branch -D` (`357–359`). Each of those operation results is discarded. If the later lease lock succeeds, it removes tracking (`362–367`), emits `WorktreeRemoved` (`370–383`) and returns `Ok(())` even when removals failed. It can still return errors for dirty inspection, invalid Unicode path or lease-lock failure; “always returns Ok” would be inaccurate.

State: Leased → known clean or explicit force → attempted Git/directory/branch removal → lease forgotten and removal observation. **Inferred risk:** partial failures can leave a directory, Git registration or branch without a lease and with a misleading removal observation. There is no cleanup-fault execution evidence here, so frequency and exact OS failure modes are **unknown**.

All located production callers are in `subagent.rs` and differ:

| Actual caller | Behavior at the pin |
| --- | --- |
| `LaunchRollback::drop`, `493–513` | Cancels unstarted operations and discards lease-release results. |
| `run_tool` async worker, `1063–1074` | Keeps worktree on runner failure or dirty state; otherwise discards release result. |
| `run_tool` background launch registration failure, `1095–1116` | Attempts cancellation/roster cleanup and discards lease-release result (`1107`). |
| `run_tool` single-worker oneshot, `1175–1185` | On success + clean, discards release result (`1178`); preserved metadata is only set by the opposite outcome/dirty branch. |
| `run_tool` multi-worker oneshot, `1261–1277` | Handles returned `Err` with `preserved:true` and `cleanup_error`. Cannot catch ignored lower-level errors that became `Ok`. |

The previous comparison's claim that the single-worker path uses `.is_ok()` and records preservation on release error is incorrect. It is the multi-worker branch that explicitly handles an error.

### Proposed implementation scope

1. Make cleanup status cover independent facts: worktree directory, Git worktree registration, owned default-prefix branch and tracking. Record checked subprocess exit/error and inspect postconditions through Git, not path existence alone. `run_git` already returns command failures (`worktree.rs:69–87`); stop discarding them. A branch failure after directory removal is a partial cleanup, not proof the whole worktree was preserved.
2. Retain the lease or a structured cleanup-pending record until required postconditions are established. Proposed states are `leased`, `preserved_dirty`, `cleanup_pending`, `released`, with fields for path/registration/owned-branch status and last error. Keep these identifiers explicitly new. A directory already absent with a leftover registration/branch must be reconcilable without treating a failed `git status` in the absent directory as permission to discard evidence.
3. Emit `WorktreeRemoved` only with its defined successful postcondition. Prefer a separate structured incomplete-cleanup observation with component status; do not emit a generic full-success event when only the directory was removed. Keep model/work completion separate from cleanup status: a valid answer may coexist with `cleanup_pending`, but no consumer may report fully cleaned up. Retain exact path and branch in user-visible metadata so manual recovery is possible.
4. Update **all** callers above. Single, multi and async workers should use the same cleanup-result mapping. Drop/launch rollback cannot return an error directly, so route failure into retained manager state plus a structured observation; avoid a second silent discard. Do not present `preserved:true` when only a branch remains; report which components still exist or are unknown.
5. Preserve dirty/unreadable-state fail-closed behavior, current-HEAD/cherry equivalence, parent authority, cancellation and branch ownership constraints. Do not expand prefix-based branch deletion to arbitrary branches. No forced retries on dirty work. Reconsider automatic raw-directory deletion after an arbitrary Git removal failure: require an explicit ownership/postcondition policy rather than escalating from a Git refusal to deletion. Recheck safety on a retry; the earlier clean check is not perpetual authorization.
6. A retained in-memory lease improves same-process recovery only. Crash/restart recovery requires a durable cleanup intent/receipt in the existing runtime persistence owner, with lease identity and component postconditions; do not claim crash safety from the current `HashMap` alone. Keep that extension explicit in the implementation scope or state that first delivery covers same-process retries only. It must not create an unconditional destructive startup sweep. For any durable version, test failure to save the pending record before destructive work and failure to commit final cleanup afterward.

**Proposed transition:** Leased → dirty/inspection error → preserved with evidence; Leased → safe cleanup intent → checked removals → all required postconditions true → Released and success observation. Any command, postcondition or tracking-commit failure → CleanupPending with identity and partial state; later reconciliation retries only unresolved owned components after current safety checks. An idempotent successful retry removes tracking exactly once.

**Inferred benefit/risk.** Better cleanup truth should make orphaned artifacts discoverable and retries possible. More retained records, platform-specific Git metadata handling, stale-record reconciliation and concurrency with live workers need care. No comparative correctness or resource-saving measurement is available. This proposal does not claim an atomic filesystem/Git/journal transaction.

### Reproducible future validation scenarios

Use disposable Git repositories and an injected command/filesystem adapter that deterministically fails the selected cleanup operation. Do not depend on Unix permissions under a privileged runner to simulate failure. Real-Git end-to-end cases should complement injected faults.

| Scenario | Deterministic assertions |
| --- | --- |
| REC-02-V1 existing safety | Dirty file, unmerged commit and unreadable `.git` remain intact with tracking; no removal success event. An ancestor-merged or squash-integrated commit can still clean up normally. |
| REC-02-V2 removal refusal | Return failure from `git worktree remove`; ensure fallback cannot erase work merely because Git refused. Preserve pending record/error and all unresolved components; no false full success. |
| REC-02-V3 directory failure | Simulate the allowed filesystem cleanup step failing; retain path/registration status and tracking, rather than reporting released. |
| REC-02-V4 branch-only residue | Let Git worktree removal succeed but branch deletion fail. Assert directory absent, branch pending, truthful metadata, no claim that the whole directory was kept. Repair adapter and retry; branch is removed and final state clears exactly once. |
| REC-02-V5 missing path/stale registration | Remove only the fixture directory, retain Git registration/branch. Reconcile that precise owned lease; an absent path alone cannot produce success. |
| REC-02-V6 identity/force/idempotence | Never delete an unrelated branch or path from a mismatched record. Explicit force remains required to remove dirty work. Repeated release/reconciliation has documented idempotent behavior and does not duplicate the removal event. |
| REC-02-V7 all callers | Run each single/multi/async/launch-rollback path with cleanup failure. Confirm manager tracking and structured diagnostics survive, independent of worker answer status. |
| REC-02-V8 optional durable phase | Crash between intent, directory removal, branch removal and receipt commit. On restart, inspect the record and actual Git state, do not replay completed destructive steps blindly, and preserve unknown state pending reconciliation. Required only if claiming durable recovery. |

Existing definitions include `test_dirty_worktree_preservation` (`worktree.rs:594–625`), `a_failing_git_status_preserves_the_lease_instead_of_reading_clean` (`640–659`), `integrated_worker_commits_do_not_keep_the_lease_dirty` (`661–689`) and `a_squash_integrated_worker_commit_is_also_clean` (`691–708`). Later verification should run these plus the new injected-failure/caller tests, for example `cargo test --locked -p davinci-agent runtime::worktree::tests`. No such test was executed here; none of these existing safety definitions by itself establishes truthful removal on command failure.

## REC-03 — Add optional bounded text continuation without weakening partial-call safety

### REC-03-S1: current transitions

**Source-verified.** `ResponsesDecoder::finalize`, `crates/davinci-ai/src/stream_decoder.rs:786–887`, calls `map_stop_reason` and maps incomplete `max_output_tokens` to `Length` (`956–983`). It rejects unfinished tool calls on a purported successful terminal, and on non-success removes executable tool blocks while marking `DROPPED_TOOL_CALLS_KEY` if calls existed (`830–858`). The correct method name for the comparison's `811–884` slice is **`finalize`**, not `finish`.

`Agent::run_loop_body`, `turn.rs:714–745`, detects the dropped flag or retained calls and strips calls/native continuation on Error/Aborted/Length. It persists partial assistant output (`747–764`) and emits its updates. For `Length` with dropped calls it queues the existing smaller-call reminder and retries at most **two** times per run (`15–16,362,796–810`). When that path cannot retry it ends at `812–841`. A tool-free `Length` does not meet the dropped-call predicate or Error/Aborted predicate, so it reaches the ordinary no-tool gates (`844–969`) and can finish normally or continue for a different gate/queue. There is no dedicated text-only continuation policy in that branch.

The print reducer already reports `Length` as a nonzero output-limit error (`main.rs:4506–4515`). Because it scans all updates, it may also report an earlier recovered Length; REC-01 must resolve that before adding new recovery. Neither “all output limits silently succeed” nor “every Length is automatically retried” describes the source.

**Unknown route prevalence.** `apply_chatgpt_plan_preview_constraints`, `davinci-ai/src/stream.rs:1692–1735`, strips explicit `max_output_tokens` on the public-plan path. This does not prove the backend can never return a Length, and does not justify adding an unsupported output-cap field to force it. Public API documentation or Claude's Messages stop reasons do not establish the selected authenticated route's accepted shapes.

### Proposed implementation scope

1. Add an explicit opt-in policy for tool-free text Length, default off pending REC-04 evidence. Start with a small finite per-run bound, such as **one** extra continuation, rather than copying Claude's three retries automatically. Count every continuation against the existing model-turn/request/deadline budgets. Never raise the cap, model, effort or speed tier to salvage a response without authorization.
2. Admit only a validated `Length` that contains useful visible text, no executable tool block and **no decoder-dropped-call flag**. Keep truncated-call recovery separate. Unsupported non-text output, empty/no-progress output, Error/Aborted or an unknown incomplete reason must not enter this path. Treat reasoning content as diagnostic, not a reason to expose or reconstruct hidden reasoning.
3. Persist the partial answer and append a clearly host-owned reminder asking the model to resume the unfinished visible answer without repeating it. Do not rewrite the stable instructions/tool schema or fabricate a server response ID/native item for the truncated response. Retain the existing native-continuation clearing. If mandatory context cannot be assembled or persisted, stop through that failure boundary.
4. Show a specific continuation reason/count in events and retain all usage/attempt observations. Keep partial fragments distinct in history; user-facing assembly must avoid silently discarding either fragment. Do not guarantee that the model will obey a no-repeat instruction. A repeated/no-progress fragment should exhaust/stop under the finite policy rather than invite an unbounded loop.
5. On exhaustion, policy-off Length or inability to continue, emit the REC-01 `output_limit` outcome and preserve partial text. A later successful answer passes the normal requirement, capability and mutation-verification gates before `loop_completed`. If the continuation returns a new, complete tool call, use the ordinary authorization/journal path; it must not resurrect any call from the truncated response or replay a prior mutation. New tools and final text still consume existing budgets.

**Proposed transition:** partial tool-free Length → policy/budget/cancellation/persistence checks → one appended continuation request → either normal fully gated completion, normal authorized tool cycle, or explicit non-completed terminal outcome. Dropped-call Length stays in the existing separate bounded smaller-call path. Error/abort/context failures do not masquerade as text continuation.

**Inferred benefit/risk.** This may recover long answers without another manual user turn. It can also consume allowance, repeat text, reduce coherence or delay an inevitable failure. The route's truncation frequency, task-completion benefit and net usage change are **unknown**. Do not promote it on the basis of Claude's synthetic EXP-06 continuation alone.

### Reproducible future validation scenarios

Use deterministic Agent completion closures, plus recorded/synthetic Responses SSE fixtures for decoder-to-coordinator coverage. Fixtures are simulated provider behavior, not backend observations.

| Scenario | Deterministic assertions |
| --- | --- |
| REC-03-V1 opt-in success | Text `part A`, Length, then text `part B`, Stop. Assert exactly two coordinator turns, one reasoned reminder, retained partial history, normal gates and a successful settled outcome/print exit. |
| REC-03-V2 policy off/exhaustion | Policy off makes one call and explicit output-limit failure. With bound one and repeated Length, stop after two calls with partial text and nonzero outcome. Bound zero is unambiguously disabled, not unlimited. |
| REC-03-V3 cap/cancellation | Cap one prevents a second request even when text continuation is allowed; classify model-turn limit when that bound stops admission. Cancellation before continuation makes no extra call. Request/deadline admission is also binding. |
| REC-03-V4 partial tool boundary | Length containing a raw ToolCall or only the decoder dropped flag executes zero calls and uses the existing two-retry smaller-call policy, never the text path. Missing/malformed tool JSON cannot bypass this test. |
| REC-03-V5 error distinctions | Error, Aborted, no visible text, unknown incomplete reason or unsupported non-text fragment does not start text continuation. Context-overflow compaction remains its separately gated recovery. |
| REC-03-V6 persistence/replay | Fail partial-output/reminder persistence; assert no second request and persistence failure. Verify native items/resume are cleared for the partial response and stable request prefixes are otherwise retained. |
| REC-03-V7 effects and quality limits | After a prior mutation, truncate the final text and continue without repeating the mutation. A fresh complete continuation tool call uses normal gates. A repeated fragment stops under the policy and is retained as a diagnostic, never reported as proven task success. |

After implementation, run targeted decoder/Agent/host-consumer cases together, because testing only reminder insertion would miss the existing exit-reducer issue. No product tests or simulated DaVinci requests were run in this research.

## REC-04 — Measure matched tasks on the actual subscription route before tuning

### REC-04-S1: reuse existing instrumentation and respect its admission limits

**Source-verified.** The current runtime's `require_codex_subscription_route`, `crates/davinci-ai/src/stream.rs:970–1014`, admits public-plan OAuth or the explicitly marked backend login with the matching backend URL, and rejects API-key fallback/header mismatch. The live transport call site chooses the backend WebSocket path only when `model.api == "openai-codex-responses"` and the model is not public-plan (`1070–1074`). Native-history replay (`2179–2245`), transport `previous_response_id` delta reuse and backend cache hits are separate mechanisms. Public-plan constraints strip stored continuation and unsupported fields (`1692–1735`); a generic capability struct is not evidence to enable them.

`scripts/bench/bench.py::command`, `245–270`, already pins provider/model/effort for the two supported arms. Its module defaults are `gpt-6-luna`/`medium` (`49–50`), so never rely on defaults to preserve the user's selection. `run_one`, `499–550`, checks binary/catalog/budget identity, records raw stdout/stderr and confirms cleanup through the campaign owner. `aggregate_available/summarize`, `733–787`, keep unavailable telemetry separate and expose input/cache/output, logical requests, actual attempts, reminders and cleanup counts. The README describes public tasks and process/boundary limits (`scripts/bench/README.md:1–61`); its public fixtures are diagnostic screening, not an independent secret holdout or full promotion evidence.

**Important concrete limitation:** the bounded `--subscription-policy` helper **hard-codes** `gpt-6-luna/high`, DaVinci-only and SSE with retries disabled. `scripts/bench/subscription_campaign.py::prepare`, `13–41`, enforces the model at `18` and effort/arm at `19`; changing `BENCH_MODEL` alone cannot run another model under that policy. The runtime's `CodexSubscriptionPolicy::validate_request`, `davinci-ai/src/subscription_policy.rs:23–77`, is more general about the pinned model, but still requires public OAuth, public `/v1/responses`, SSE, no retry and no output cap. It is **not** a universal capability claim or a benchmark mode for the marked backend route.

Therefore do not silently change a requested model to Luna/high, bypass policy to use the runner, or label this strict SSE policy as a measurement of ordinary auto/WebSocket/backend behavior. If the desired campaign uses another selected model, first generalize the Python model equality to an explicitly approved exact model pin, retaining fixed effort, arm, request/task/time bounds and runtime route checks. If it targets a different authenticated route/transport, it needs a separately evidenced route-specific policy; broadening this policy from public OAuth is not an incidental benchmark fix. The researcher/agent model label is not by itself a measured runtime catalog identity.

### Proposed experiment scope and state

REC-04 is a plan, **not permission for live usage**. No model calls are included in this report. A future campaign proceeds through FrozenManifest → OfflineValidated → BoundedPreflight → ScheduledMatchedRuns → CleanupAndGrading → ReportedWithMissingness. Failed admission/cleanup/accounting halts it and retains the failed row. API spending authorization remains zero; actual subscription/account billing effects remain unmeasured unless observed.

1. **Freeze the comparison.** Record exact baseline/candidate source commits and clean trees, immutable binary hashes/build receipts, fixture commit/content hashes, platform/toolchain, settings, prompt/tool schemas, context mode, route/transport/auth-source class, actual model ID and effort, service tier, task caps and wall/request budget. Do not record credentials. Compare one treatment at a time: terminal semantics, cleanup truth, text continuation off/on, or a separately specified context-mode/prompt change. Do not combine all four proposals into an efficiency attribution.
2. **Preserve the user's selected runtime.** Resolve the exact accepted model ID from selected settings/catalog before scheduling; never silently downgrade effort/model. Use `openai-codex` subscription authentication with no API key or paid fallback. If selected route/model cannot satisfy finite safe admission, report the unsupported configuration and complete offline work; do not substitute another provider. Keep public-plan SSE, public-plan WebSocket and marked backend campaigns separate unless transport itself is the declared treatment.
3. **Offline conformance first.** Run REC-01–03 deterministic cases, source/binary identity checks, fixture reference/regression validation and parser tests before any model usage. Reuse the existing runner's owned-process cleanup, fresh workspace, complete failure rows and missing-data semantics. Do not remove its transaction/artifact/cleanup checks or call public graders a protected holdout. Source fingerprints can diagnose prefix changes but cannot stand in for provider cache-hit observations.
4. **Bounded preflight and schedule.** After a future explicit finite campaign is requested, use one representative task per arm to verify accepted request/event/usage shapes within the same campaign budget. Freeze a mixed small/medium/context-heavy task set with task-specific check commands. A diagnostic starting sample can use at least five families and three repetitions, with counterbalanced order/seed and fresh fixture copies; it remains a small diagnostic sample. For parent/candidate campaigns retain the actual target merge-base and immutable identities as the runner requires. A throughput/team trial is a separate declared treatment; no speculative/prewarm/background model calls.
5. **Matched evidence.** Run sequentially on the same account/host and avoid unrelated account jobs. Record available before/after backend allowance windows without printing credentials, separately from per-request telemetry. Keep complete raw events and grading/cleanup receipts privately. Keep failed, timed-out, limited, denied, cancelled, unknown-accounting and successful rows in denominators; do not reward early failures as speedups. A row passes only when process/outcome, task checks, scope and cleanup evidence all pass.
6. **Report useful work and uncertainty.** Show completion/pass rates, each baseline-pass/candidate-fail pair, full and both-successful latency distributions, fresh/cached/output/reasoning token counts with availability denominators, logical calls versus provider attempts/retries/continuations, tool dispatch counts, compactions, reminder reasons, context/verification failures and cleanup residues. Report per-route/model/effort. Use paired task/repetition comparisons and task-cluster uncertainty where sample size supports it. Missing values stay unknown, not zero; API dollar prices, structural cache keys, warm transport and partial transcript totals do not establish included-plan savings.
7. **Declare decision rules before collection.** Correctness and preservation cannot regress silently. For REC-03 retain off by default unless measured completion improvement is worth its additional attempts/latency under the requested budget, with adverse tasks reviewed. For context changes verify retained-evidence recall and independent task correctness, not summary size alone. Existing `bench.py report/gate/compare` are evidence tools; a successful screening gate is not independent acceptance. Do not invent an efficiency percentage or promote from a single favorable sample.

**Inferred benefit/risk.** Matched evidence should prevent optimizing token counts while harming useful completion. Evaluation time/allowance, fixture leakage, incomplete usage accounting, account contention and route drift can confound conclusions. No measured savings or quality advantage follows from this report. The current harness's documented credential/holdout boundaries limit what its outputs can certify.

### Reproducible future validation scenarios

| Scenario | Required evidence/decision |
| --- | --- |
| REC-04-V1 model/route mismatch | Offline policy test requests a nonmatching model, effort, auth route or API-key/header override. Deny before launch; no downgrade, fallback or model call. Generalized exact model pins still reject changes mid-campaign. |
| REC-04-V2 bounded accounting | Synthetic ledger fixtures exhaust request/task/deadline bounds or leave an unresolved reservation. Next launch is blocked; original failure stays in results. Missing usage does not become zero. |
| REC-04-V3 truth versus prose | A fixture emits the max-turn notice with otherwise nonempty text; new parser classifies limited/non-pass using typed outcome. A recovered intermediate Length plus a successful final outcome is not falsely failed; grader can still fail the task. |
| REC-04-V4 cleanup gate | A worker or supervised descendant remains, or a cleanup receipt is unknown. Retain failed row, stop, and do not grade while a writer may be active. Worktree component residue is reported separately. |
| REC-04-V5 matched tasks | Verify identical fixture/task hashes, selected model/effort/route, prompt preamble and grading commands per pair; retain all repetitions and failures. Mismatch invalidates that comparison. |
| REC-04-V6 optional live diagnostic | Only after bounded authorization and successful offline gates: record actual sent/returned model/effort/route/usage shapes on a preflight task, then the frozen schedule. Stop on unknown response identity, quota or unusable accounting. Simulated results cannot replace live savings evidence. |

The existing offline comparison command shape is `python3 scripts/bench/bench.py compare --baseline /absolute/parent-campaign --candidate /absolute/candidate-campaign --base-ref <declared-target-ref>` from the checkout; it requires real retained campaigns. No campaign directories are fabricated here. There is intentionally no copy-and-run live command that would use the wrong fixed Luna policy or spend allowance under this research authorization.

## Comparison corrections and interpretation limits

These checked refinements should accompany integration of this report:

| Comparison claim | Source-checked correction |
| --- | --- |
| CMP-02 maximum-turn semantics | Keep the typed-outcome concern; add that the cap applies only before another coordinator turn, tools from the last admitted turn already run, an Nth-turn final answer may complete normally, and retries can produce multiple provider attempts per counted turn. |
| CMP-03 decoder function | `stream_decoder.rs:811–884` is within `ResponsesDecoder::finalize` (declaration `786`), not `finish`. Keep decoder and loop partial-call protections. |
| CMP-03 print failure | Existing Length failure is real. Add that the backward scan can retain an earlier Length failure after later recovery; this makes terminal consumer correctness a dependency for REC-03. |
| CMP-11 single-worker oneshot cleanup | `subagent.rs:1177–1178` discards the result. Multi-worker `1266–1269` handles a returned Err. Both still suffer from ignored removal errors inside `release_lease`. No `.is_ok()` cleanup predicate exists in the single-worker branch. |
| CMP-11 cleanup success | `release_lease` is capable of returning Err for safety/encoding/lock failures. The defect is ignored removal errors followed by apparent success when later tracking removal succeeds, not unconditional Ok on every path. |
| REC-04 tool availability | Existing strict Python campaign policy cannot honor an arbitrary selected model or backend/WebSocket route. Preserve its finite limits and route safeguards while making any future exact-pin/route extension explicit. |

All proposed benefits remain **inferred**. Worktree-fault execution, new terminal/continuation behavior, live route acceptance, quality, compaction recall, backend cache reuse and subscription savings remain **unknown/unrun**. Existing source-defined tests and Claude local fixture observations are not DaVinci test results.

## Reproduce this source verification

```sh
python3 /workspace/research/claude-davinci/evidence/proposals/extract_sources.py
python3 -m json.tool /workspace/research/claude-davinci/evidence/proposals/source_index.json
git -C /workspace/davinci rev-parse HEAD
git -C /workspace/davinci status --short
```

The extractor reads pinned Git objects and current source, checks byte identity, and writes only its own research evidence directory. It runs no product code/tests/providers or cleanup operations. It does not overwrite the earlier comparison/experiment/audit evidence. The successful extraction here established **12 source files matching the pin and zero checkout-status entries**, not a passing implementation or ready runtime.
