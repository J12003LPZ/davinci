# Wave 3: independent evidence audit

Scope: official npm `@anthropic-ai/claude-code@2.1.80`; native 2.1.302 is a separate identity-only inventory. Audit conducted against all Wave 1 reports, Wave 2 prompt/experiment reports, the draft `final/RUNTIME_SPEC.md`, contradiction register, raw bundles, canonical captures, and harness source. Initial report/harness hashes are retained in `evidence/audit/report-hashes-at-initial-audit.json`; the harness snapshot is `evidence/audit/harness-at-audit.js`. This report does not modify those sources, the original captures, or DaVinci.

**Audit outcome:** source identity and corrected LF source indexes check out. The important new correction is EXP-14's compound-invalid input: its first `message_start` is already missing the required `message` object. Independent differential controls show that malformed JSON after a valid start *does* reach a successful nonstream fallback in this pinned client. The original failure remains valid evidence for its exact input, but the claim that it starts with a valid message is false. The current harness also does not reproduce all recorded canonical command arguments and can overwrite retained summaries.

All source line numbers below are literal-LF lines in `artifacts/claude-2.1.80/cli.pretty.js` (**P**), with actual bundle identifiers. Descriptive experiment names are not implementation function names. Severity concerns research conclusions/reproducibility, not vulnerability severity.

## Actionable corrections

### AUD-01 — high: EXP-14 starts with a missing message object; the malformed-JSON-only behavior is different

- **Exact claim audited:** Wave 2 `experiments.md` EXP-14 and its source-mapping paragraph call the first SSE event a “valid `message_start`,” followed by malformed JSON. The draft spec correctly bounds the observed failure but should add the now-observed successful fallback control.
- **Actual evidence:** `evidence/experiments/runs/rerun-final/EXP-14/result.json`, `responses[0].sse`, starts with `event: message_start\ndata: {"type":"message_start"}\n\n`; no `message`, `message.usage`, model or content exists. The following event also has broken JSON. Harness `runScenario` at snapshot lines 109–112 constructs these exact bytes. `responses[0].response` contains a well-formed *unsent helper object*; for wire conclusions, use `sse`, not this object.
- **Implementation:** `$Eq` P:546214–546219 assigns `s=J8.message` and reads `J8.message?.usage`; it yields the event at P:546377–546382. The outer `uFq.submitMessage` P:606988–606990 reads `W6.event.message.usage` without an optional guard. Raw unique needles: `J8.message?.usage` byte **11026805** and `W6.event.message.usage` byte **12211270**, independently recomputed in `evidence/audit/raw-anchors.json`.
- **Reproduction:** `node evidence/audit/control-harness.cjs` from the research root. It creates only audit-owned files and uses isolated child settings, a loopback simulated Messages API, synthetic key/model/usage, 30-second child deadlines and the original three-request bound. The retained executable is derived from the original snapshot with only the evidence directory, scenarios, malformed payloads and correct JSON response handling for nonstream fallback changed. Exact commands, bytes, stdout, exit and timestamps are in each `evidence/audit/controls/runs/rerun-final/AUD-STREAM-*/result.json`.

| Control | Exact first response | Observed next state |
|---|---|---|
| AUD-STREAM-A | Only `message_start` with missing `message`; no later malformed JSON | One request; exit 1; `error_during_execution`; same `Cannot read properties of undefined (reading 'usage')`; zero turns. |
| AUD-STREAM-B | Well-formed message_start containing message and usage, then malformed event JSON | Two requests; second request omits `stream:true` and receives application/json; exit 0, `success`, final fixture text. |
| AUD-STREAM-C | Ordinary valid text SSE | One request; exit 0, `success`, final fixture text. |

- **Correct classification:** The original compound failure and these differential outcomes are **experimentally observed**. The unguarded outer `.usage` access is **source-verified**. Identifying that precise access as the thrown origin remains **inferred**, because no stack/in-process instrumentation was added. The missing message object is experimentally sufficient for the failure; this does not establish every malformed-stream variant or any Anthropic backend behavior.
- **Recommendation:** Preserve EXP-14 unchanged, describe it as a compound malformed event sequence, remove “valid message_start,” add these A/B/C controls to final evidence, and distinguish the inner adapter fallback from outer protocol-consumer validation. Do not state or imply that malformed JSON generally fails without fallback.

### AUD-02 — medium: current harness does not reproduce the canonical memory-negative arguments and can overwrite provenance

- **Exact claim audited:** The experiment report's reproduction commands imply the current `scripts/experiment_fixture.js` recreates the canonical final run set with empty setting sources for EXP-12/13 and preserves preliminary runs.
- **Source/function/locations:** `runScenario`, snapshot P-independent JS lines **89–91**, uses `s.settingSources ? [...] : s.claudeMd ? [] : ['--setting-sources','']`. Thus EXP-12/13 now omit `--setting-sources` entirely. Their canonical `result.json` records explicitly contain `--setting-sources ''`. `main`, snapshot lines **160–170**, runs every current scenario (now 15) without a selector, labels every selector run `rerun-memory`, and unconditionally overwrites `summary-rerun-corrected.json` with whichever results just ran. Fixed `runs/rerun-final/EXP-*` paths and shared fixture files are also overwritten/deleted on rerun.
- **Reproduction:** Read `command.args` in canonical EXP-12/13 and compare with the snapshot's `settingArgs` expression; inspect `main`'s final `writeJson`. This is a static mismatch, so rerunning the original harness over evidence is unnecessary. The audit intentionally did not do so. Canonical raw captures remain sufficient to establish their originally recorded inputs/outcomes.
- **Correct classification:** Code path and command mismatch are **source-verified**; an exact future rerun's memory outcome is **unknown**. No false inference follows about the validity of the preserved negative captures.
- **Recommendation:** Preserve the initial harness snapshot, make setting-source selection explicit per scenario, default the full suite to a separately named new run directory, accept an output-root/run-label option, refuse overwrite unless explicitly requested, and stop unconditionally writing the preliminary summary. Save a harness hash in future result records. Until corrected, present raw recorded CLI commands as authoritative reproduction inputs, not the drifted runner as an exact replay.

### AUD-03 — low: delegation report names the schema getter as the executable Agent tool

- **Exact claim/source:** `wave1/delegation.md` D-02/D-03 refer to `UyY.call`. P:412791 assigns `UyY=p6(...)` as a memoized schema getter; P:412870 assigns the actual tool object **`dZ6`**, whose `async call` begins P:412901. Wave 2 PROMPT-11 correctly says `dZ6.call`.
- **Reproduction:** Inspect P:412785–412806 and P:412868–412915, retained in `evidence/audit/source_*.txt`; raw unique `UyY=p6` byte **8627189**, `dZ6={async prompt` byte **8629253**.
- **Correct classification:** **source-verified citation/identifier defect**. The underlying fork/model/tool/worktree branches remain supported; this is not a refutation of those behavioral conclusions.
- **Recommendation:** Replace `UyY.call` with `dZ6.call` in D-02/D-03 and any integrated table.

### AUD-04 — low: some prose spans/cross-references and bounded excerpts are not complete function spans

- **Source/location:** LOOP-05 cites `t9q` P:450065–450179, while its actual declaration is P:**450087** and complete body ends **450285** (PROMPT-14 has the correct full span; raw `async function*t9q(` byte **9289784**). The draft S2 links dormant-path evidence to LOOP-11 (persistence), where LOOP-09 is intended. CTX-05/09 cite the `tOq` initialization at P:476211; its actual line is **476216** (raw `var tOq=null` byte **9769041**; identifier itself byte 9769045).
- **Excerpt reproduction:** Independent `node --check` over all `function_*.js` files passes all 75 context excerpts and 94/96 prompt excerpts. `evidence/prompt/function_Xf4.js` and `function_kk.js` end inside template text/interpolation, and are verbatim *partial* spans, not complete syntactically valid functions. The prompt report describes bounded excerpts and does not claim all 96 parse, so this is a usability/citation issue, not a substantive unsupported conclusion. Results: `evidence/audit/syntax-checks.json`.
- **Correct classification:** **source-verified citation/excerpt nits**. Unique raw anchors and existing complete source permit reproduction.
- **Recommendation:** Correct the prose locations and LOOP cross-reference; extend those two excerpts with an AST-aware function boundary finder or clearly label them partial. Avoid a first standalone `}` heuristic where template literals contain such lines.

## Confirmed evidence and resolved apparent contradictions

### AUD-CONF-01 — source identity and mechanical formatting independently verified

**Source-verified.** `evidence/audit/recomputed.json` recomputes all four manifest file sizes/SHA256 values, tarball SHA512 and tar-member identity. The tarball's `package/cli.js` is byte-identical to the extracted `cli.js`; package metadata says `@anthropic-ai/claude-code` version `2.1.80`. A fresh unauthenticated HTTPS read of the official version metadata independently returned the same dist integrity and tarball URL (`registry-version.json`, `registry-check.json`). That is a package-registry metadata request, not a model/provider call. All original target files remained unchanged.

`npx --yes --cache /tmp/claude-audit-npm-cache prettier@3.6.2 --parser babel artifacts/claude-2.1.80/cli.js > evidence/audit/reformatted.pretty.js` produced a byte-identical derivative (`cmp` exit 0), SHA256 **b6daf37bb2bb905a09d62f2c513de6d7f0f8a556c688a80c7961af8de1516fcf**. Thus the supplied readable implementation is a reproducible formatting derivative, not reconstructed pseudocode. Native binary hash matches its manifest; no execution parity follows.

### AUD-CONF-02 — corrected LF indexes and context snippets are sound

**Source-verified.** Independent code uses `decode().split('\n')` only. All **75 context** and **117 prompt** indexed raw byte offsets and declared occurrence counts recompute correctly; every cataloged needle is unique. Existing `function_*.js` excerpts match their indexed LF spans byte-for-byte after UTF-8 decoding/reencoding. All 75 context excerpts parse. The earlier Unicode `splitlines` extraction defect is corrected in these artifacts; this does not magically validate every prose citation, hence AUD-04.

Reproduce with `python3 evidence/audit/recompute.py`. It writes only audit-owned `recomputed.json` and prints bounded verification results. It does not invoke the original mutating extractors.

### AUD-CONF-03 — active versus dormant compaction is correctly separated

**Source-verified.** Actual `zYq` P:450318–450320 selects `microcompact:lg`, `autocompact:sW4`; `lg` P:317852–317854 returns the same messages after flag reset. All inspected `qw6` references are guarded reads except the null initialization P:450946; manual counterpart `tOq` is null at P:476216. `$Eq` initializes cache-edit local `D=!1` at P:545881ff and has no subsequent assignment enabling it. `Ff8` P:313846–313848 returns false, separately disabling the persistent long-wait retry route. These facts support dormant-path conclusions only in this pinned bundle/default dependency path. They do not disable reachable `sW4`/`bZ6` automatic/manual compaction, output-limit continuation or ordinary request retries, and do not establish live feature flags or native-version parity.

### AUD-CONF-04 — terminal metadata is not task success; tool presence is distinct from stop reason

**Source-verified plus experimentally observed, kept separate.** `zgY`'s tool-block predicate P:450588–450630 and post-tool max-turn guard P:450917–450942 agree with canonical raw stdout/requests in EXP-03,05,08. The controlled Write side-effect snapshot in EXP-05 says content `controlled fixture write`; tool-result events precede `error_max_turns`, exit 0, `is_error:false`, `num_turns:2`, no next API request. EXP-08 executes Read despite synthetic `end_turn`. EXP-07 retains null stop reason with a success subtype. This confirms these protocol-state distinctions for the scripted cases and provides no task-quality evidence.

### AUD-CONF-05 — streaming/fallback schedulers and permission paths are not conflated

**Source-verified.** `Jr6.addTool/processQueue/executeTool/getCompletedResults` P:448933–449173 implement safe-call overlap/barriers and completion delivery without the fallback numerical cap; `executeTool` launches an internal async promise and returns without awaiting its completion, so `processQueue`'s `await this.executeTool` does not serialize the full tool body. `rL8/FBY/QBY/UBY` P:449395–449473 and `$E8` P:406989–407014 implement adjacent safe groups, unsafe singleton barriers and `pBY`'s default cap 10. No controlled timestamps establish either scheduler's live ordering/concurrency.

`hO_` P:540965–541039 and `JM` P:541119ff verify the source precedence and dontAsk transformation. `S4Y` P:337133ff is the distinct interactive/team request wrapper. Canonical EXP-04 uses headless print mode and proves only its local Write denial and absent fixture target. It does not experimentally exercise the interactive wrapper.

### AUD-CONF-06 — persistence is not a durable external-effect transaction

**Source-verified with explicit unknown.** `Jr6.discard` P:448923–448925 only sets a flag; `Gx` P:538060–538072 UUID-deduplicates and appends transcript messages. Neither function establishes undoing already-running side effects. The tools/delegation/spec reports correctly bound cancellation, ordinary TaskUpdate versus locked claims, mailbox catch/mark-read behavior, and cleanup-error reporting. Exactly-once external execution, crash-safe tool-effect/result commit, enabled-team availability, compaction fidelity and task success remain **unknown**. No mechanism absent from the bounded inspected branch is generalized absent from all versions.

### AUD-CONF-07 — canonical memory/cost/network interpretation is now bounded correctly

**Experimentally observed.** Independently parsed all 15 canonical result files, stdout JSON, request/response counts, terminal fields, traffic-flag spelling, selected tool-result payloads and fixture side effects; `recomputed.json` retains capture hashes and summaries. All canonical environments set `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1` and the provider URL is owned loopback. EXP-12/13 marker is absent from system and messages; EXP-15 explicitly selects project settings and contains the marker in user messages only. This is a negative/positive source-selection control, not arbitrary memory/trust validation. Captured cost/modelUsage are derived from fixture usage and CLI price rules; they are not spend or efficiency measurements. In the audit fallback control, aggregate usage remains zero while modelUsage/cost is populated, reinforcing that these fields should not be silently combined as one measured quantity.

The available evidence proves neither comprehensive absence of ancillary outbound traffic nor actual Anthropic cache hits, TTL, cache keys, latency/savings, task-quality improvement or 2.1.302 parity. Corrected environment spelling does not substitute for packet capture.

## Remaining review

Architecture comparison `wave3/comparison.md` and the final integrated synthesis will receive a follow-up audit once available. This first audit supplies concrete corrections rather than acceptance of summaries. The contradiction register still marked rerun/memory diagnosis “in progress” when inspected despite the canonical completed follow-up; update its statuses to refer to actual retained outcomes and this audit.
