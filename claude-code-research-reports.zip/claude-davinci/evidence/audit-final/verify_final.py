#!/usr/bin/env python3
"""Read-only audit checks; write only audit-final-owned evidence."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/research/claude-davinci')
DAVINCI = Path('/workspace/davinci')
OUT = ROOT / 'evidence/audit-final'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def capture_summary(relative):
    path = ROOT / relative
    record = json.loads(path.read_text())
    command = record.get('command', {})
    args = command.get('args', [])
    settings = args[args.index('--setting-sources') + 1] if '--setting-sources' in args else None
    body = record.get('requests', [{}])[0].get('body', {})
    marker = 'CLAUDE.MD FIXTURE SYSTEM BLOCK'
    return {'path': relative, 'sha256': digest(path), 'exit': record.get('exit'),
            'requests': record.get('requestCount'), 'verbose': '--verbose' in args,
            'setting_sources': settings, 'traffic_flags': [name for name in command.get('envNames', []) if 'NON' in name and 'TRAFFIC' in name],
            'marker_system': marker in json.dumps(body.get('system')),
            'marker_messages': marker in json.dumps(body.get('messages')),
            'harness_sha256': record.get('harnessSha256')}

SLICES = [
 ('crates/davinci-agent/src/turn.rs', 'Agent::finish_run/run_loop_body', 317, 428),
 ('crates/davinci-agent/src/turn.rs', 'Agent::run_loop_body Length handling', 715, 847),
 ('crates/davinci-agent/src/events.rs', 'AgentEvent::AgentEnd', 40, 48),
 ('crates/davinci-coding-agent/src/main.rs', 'run_worker_turn/run_nested_subagent', 2693, 2778),
 ('crates/davinci-coding-agent/src/main.rs', 'print_text_exit', 4476, 4537),
 ('crates/davinci-agent/src/runtime/worktree.rs', 'WorktreeManager::release_lease', 327, 389),
 ('crates/davinci-agent/src/subagent.rs', 'run_tool async cleanup', 1059, 1084),
 ('crates/davinci-agent/src/subagent.rs', 'run_tool oneshot cleanup', 1160, 1215),
 ('crates/davinci-agent/src/runtime/team.rs', 'run_teammate_loop', 407, 484),
 ('crates/davinci-ai/src/stream.rs', 'require_codex_subscription_route caller', 934, 945),
 ('crates/davinci-ai/src/stream.rs', 'require_codex_subscription_route', 972, 1014),
 ('crates/davinci-ai/src/stream.rs', 'live_complete_streaming_with_sink_envelope_inner transport gate', 1054, 1172),
 ('crates/davinci-ai/src/stream.rs', 'apply_chatgpt_plan_preview_constraints', 1692, 1735),
 ('crates/davinci-ai/src/stream.rs', 'native_responses_replay_skip/apply_native_responses_resume', 2179, 2245),
 ('crates/davinci-ai/src/codex.rs', 'acquire_cached_continuation/store_cached_continuation', 472, 536),
 ('crates/davinci-ai/src/codex.rs', 'get_cached_websocket_input_delta/build_cached_websocket_request_body', 582, 653),
 ('crates/davinci-ai/src/codex_ws.rs', 'public_websocket_selected', 1230, 1233),
]

OUT.mkdir(exist_ok=True)
index = []
for n, (relative, function, start, end) in enumerate(SLICES):
    path = DAVINCI / relative
    lines = path.read_text().split('\n')
    excerpt = '\n'.join(lines[start - 1:end]) + '\n'
    target = OUT / f'source_{n:02d}.txt'
    target.write_text(''.join(f'{i}: {line}\n' for i, line in enumerate(lines[start-1:end], start)))
    index.append({'path': str(path), 'function': function, 'lf_start': start, 'lf_end': end,
                  'file_sha256': digest(path), 'excerpt_sha256': hashlib.sha256(excerpt.encode()).hexdigest(),
                  'retained': str(target.relative_to(ROOT))})

captures = [f'evidence/experiments/runs/{run}/{exp}/result.json' for run, exp in [
    ('', 'EXP-01'), ('', 'EXP-03'), ('rerun-corrected', 'EXP-03'),
    ('rerun-final', 'EXP-12'), ('rerun-final', 'EXP-13'), ('rerun-memory', 'EXP-15')]]
captures += [f'evidence/experiments/reproductions/lead-reproduction-validation/{exp}/result.json' for exp in ['EXP-12','EXP-13','EXP-15']]
result = {'source_pin': subprocess.check_output(['git', '-C', str(DAVINCI), 'rev-parse', 'HEAD'], text=True).strip(),
          'davinci_status': subprocess.check_output(['git', '-C', str(DAVINCI), 'status', '--short'], text=True),
          'source_slices': index, 'capture_spot_checks': [capture_summary(p.replace('//','/')) for p in captures],
          'current_harness_sha256': digest(ROOT / 'scripts/experiment_fixture.js')}
(OUT / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k != 'source_slices'}, indent=2))
