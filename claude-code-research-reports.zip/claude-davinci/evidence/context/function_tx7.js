function tx7(A) {
  let { hasThinking: q = !1 } = A ?? {},
    K = [];
  if (q && A1("tengu_marble_anvil", !1))
    K.push({ type: "clear_thinking_20251015", keep: "all" });
  return K.length > 0 ? { edits: K } : void 0;
}
