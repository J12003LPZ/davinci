function sVq(A) {
  let q = [],
    K = !1;
  for (let Y = 0; Y < A.length; Y++) {
    let _ = A[Y];
    if (_.type !== "assistant") {
      if (
        _.type === "user" &&
        Array.isArray(_.message.content) &&
        q[q.length - 1]?.type !== "assistant"
      ) {
        let Z = _.message.content.filter(
          (G) =>
            !(typeof G === "object" && "type" in G && G.type === "tool_result"),
        );
        if (Z.length !== _.message.content.length) {
          K = !0;
          let G =
            Z.length > 0
              ? Z
              : q.length === 0
                ? [
                    {
                      type: "text",
                      text: "[Orphaned tool result removed due to conversation resume]",
                    },
                  ]
                : null;
          if (G !== null)
            q.push({ ..._, message: { ..._.message, content: G } });
          continue;
        }
      }
      q.push(_);
      continue;
    }
    let z = new Set();
    for (let Z of _.message.content)
      if ("tool_use_id" in Z && typeof Z.tool_use_id === "string")
        z.add(Z.tool_use_id);
    let w = new Set(),
      O = _.message.content.filter((Z) => {
        if (Z.type === "tool_use") {
          if (w.has(Z.id)) return ((K = !0), !1);
          w.add(Z.id);
        }
        if (
          (Z.type === "server_tool_use" || Z.type === "mcp_tool_use") &&
          !z.has(Z.id)
        )
          return ((K = !0), !1);
        return !0;
      }),
      $ = O.length !== _.message.content.length;
    if (O.length === 0)
      O.push({ type: "text", text: "[Tool use interrupted]", citations: [] });
    let H = $ ? { ..._, message: { ..._.message, content: O } } : _;
    q.push(H);
    let j = [...w],
      J = A[Y + 1],
      M = new Set(),
      X = !1;
    if (J?.type === "user") {
      let Z = J.message.content;
      if (Array.isArray(Z)) {
        for (let G of Z)
          if (
            typeof G === "object" &&
            "type" in G &&
            G.type === "tool_result"
          ) {
            let v = G.tool_use_id;
            if (M.has(v)) X = !0;
            M.add(v);
          }
      }
    }
    let D = new Set(j),
      P = j.filter((Z) => !M.has(Z)),
      W = [...M].filter((Z) => !D.has(Z));
    if (P.length === 0 && W.length === 0 && !X) continue;
    K = !0;
    let f = P.map((Z) => ({
      type: "tool_result",
      tool_use_id: Z,
      content: "[Tool result missing due to internal error]",
      is_error: !0,
    }));
    if (J?.type === "user") {
      let Z = Array.isArray(J.message.content)
        ? J.message.content
        : [{ type: "text", text: J.message.content }];
      if (W.length > 0 || X) {
        let v = new Set(W),
          k = new Set();
        Z = Z.filter((N) => {
          if (
            typeof N === "object" &&
            "type" in N &&
            N.type === "tool_result"
          ) {
            let E = N.tool_use_id;
            if (v.has(E)) return !1;
            if (k.has(E)) return !1;
            k.add(E);
          }
          return !0;
        });
      }
      let G = [...f, ...Z];
      if (G.length > 0) {
        let v = { ...J, message: { ...J.message, content: G } };
        (Y++, q.push(FY("tengu_chair_sermon") ? nVq([v])[0] : v));
      } else Y++;
    } else if (f.length > 0) q.push(g8({ content: f, isMeta: !0 }));
  }
  if (K) {
    let Y = A.map((_, z) => {
      if (_.type === "assistant") {
        let w = _.message.content
            .filter((H) => H.type === "tool_use")
            .map((H) => H.id),
          O = _.message.content
            .filter(
              (H) => H.type === "server_tool_use" || H.type === "mcp_tool_use",
            )
            .map((H) => H.id),
          $ = [`id=${_.message.id}`, `tool_uses=[${w.join(",")}]`];
        if (O.length > 0) $.push(`server_tool_uses=[${O.join(",")}]`);
        return `[${z}] assistant(${$.join(", ")})`;
      }
      if (_.type === "user" && Array.isArray(_.message.content)) {
        let w = _.message.content
          .filter(
            (O) =>
              typeof O === "object" && "type" in O && O.type === "tool_result",
          )
          .map((O) => O.tool_use_id);
        if (w.length > 0) return `[${z}] user(tool_results=[${w.join(",")}])`;
      }
      return `[${z}] ${_.type}`;
    });
    (Q("tengu_tool_result_pairing_repaired", {
      messageCount: A.length,
      repairedMessageCount: q.length,
      messageTypes: Y.join("; "),
    }),
      $6(
        Error(
          `ensureToolResultPairing: repaired missing tool_result blocks (${A.length} -> ${q.length} messages). Message structure: ${Y.join("; ")}`,
        ),
      ));
  }
  return q;
}
