async function hW4(A, q) {
  let K = await js9(),
    Y = Js9(A),
    _ = N5(A),
    z = Ms9(Y, _);
  return Xs9(K, { currentNotes: A, notesPath: q }) + z;
}
