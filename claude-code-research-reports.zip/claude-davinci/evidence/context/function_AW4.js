async function AW4(A, q, K, Y, _) {
  try {
    let z = A.slice(q),
      w = A.slice(0, q).filter((u) => u.type !== "progress");
    if (z.length === 0)
      throw Error("Nothing to summarize after the selected message.");
    let O = hf(A);
    (K.onCompactProgress?.({ type: "hooks_start", hookType: "pre_compact" }),
      K.setSDKStatus?.("compacting"));
    let $ = await xZ6(
        { trigger: "manual", customInstructions: null },
        K.abortController.signal,
      ),
      H;
    if ($.newCustomInstructions && _)
      H = `${$.newCustomInstructions}

User context: ${_}`;
    else if ($.newCustomInstructions) H = $.newCustomInstructions;
    else if (_) H = `User context: ${_}`;
    (K.setStreamMode?.("requesting"),
      K.setResponseLength?.(() => 0),
      K.onCompactProgress?.({ type: "compact_start" }));
    let j = E04(H),
      J = g8({ content: j }),
      M = await KW4({
        messages: A,
        summaryRequest: J,
        appState: K.getAppState(),
        context: K,
        preCompactTokenCount: O,
        cacheSafeParams: Y,
      }),
      X = MZ8(M);
    if (!X)
      throw (
        Q("tengu_partial_compact_failed", {
          reason: "no_summary",
          preCompactTokenCount: O,
        }),
        Error(
          "Failed to generate conversation summary - response did not contain valid text content",
        )
      );
    else if (sc(X))
      throw (
        Q("tengu_partial_compact_failed", {
          reason: "api_error",
          preCompactTokenCount: O,
        }),
        Error(X)
      );
    else if (X.startsWith(xg))
      throw (
        Q("tengu_partial_compact_failed", {
          reason: "prompt_too_long",
          preCompactTokenCount: O,
        }),
        Error(e04)
      );
    let D = bV1(K.readFileState);
    (K.readFileState.clear(), jl());
    let [P, W] = await Promise.all([YW4(D, K, t04), wW4(K)]),
      f = [...P, ...W],
      Z = OZ8(K.agentId);
    if (Z) f.push(Z);
    let G = await zW4(K);
    if (G) f.push(G);
    let v = _W4(K.agentId);
    if (v) f.push(v);
    for (let u of $Z8(K.options.tools, K.options.mainLoopModel, w))
      f.push(V4(u));
    for (let u of HZ8(
      K.options.mcpClients,
      K.options.tools,
      K.options.mainLoopModel,
      w,
    ))
      f.push(V4(u));
    K.onCompactProgress?.({ type: "hooks_start", hookType: "session_start" });
    let k = await dD("compact", { model: K.options.mainLoopModel }),
      N = DE([M]),
      E = uc(M);
    Q("tengu_partial_compact", {
      preCompactTokenCount: O,
      postCompactTokenCount: N,
      messagesKept: w.length,
      messagesSummarized: z.length,
      trigger: "message_selector",
      compactionInputTokens: E?.input_tokens,
      compactionOutputTokens: E?.output_tokens,
      compactionCacheReadTokens: E?.cache_read_input_tokens ?? 0,
      compactionCacheCreationTokens: E?.cache_creation_input_tokens ?? 0,
    });
    let h = rQ6("manual", O ?? 0, w[w.length - 1]?.uuid, _, z.length),
      R = cg(A);
    if (R.size > 0) h.compactMetadata.preCompactDiscoveredTools = [...R].sort();
    let m = J_(),
      I = [
        g8({
          content: dQ6(X, !1, m),
          isCompactSummary: !0,
          ...(w.length > 0
            ? {
                summarizeMetadata: {
                  messagesSummarized: z.length,
                  userContext: _,
                },
              }
            : { isVisibleInTranscriptOnly: !0 }),
        }),
      ];
    (JZ8(),
      K.onCompactProgress?.({ type: "hooks_start", hookType: "post_compact" }));
    let g = await jZ8(
      { trigger: "manual", compactSummary: X },
      K.abortController.signal,
    );
    return {
      boundaryMarker: _R1(h, h.uuid, w),
      summaryMessages: I,
      messagesToKeep: w,
      attachments: f,
      hookResults: k,
      userDisplayMessage: g.userDisplayMessage,
      preCompactTokenCount: O,
      postCompactTokenCount: N,
      compactionUsage: E,
    };
  } catch (z) {
    throw (qW4(z, K), z);
  } finally {
    (K.setStreamMode?.("requesting"),
      K.setResponseLength?.(() => 0),
      K.onCompactProgress?.({ type: "compact_end" }),
      K.setSDKStatus?.(null));
  }
}
