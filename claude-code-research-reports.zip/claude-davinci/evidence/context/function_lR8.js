async function lR8(A, q) {
  let K = FY("tengu_tool_pear"),
    Y =
      "inputJSONSchema" in A && A.inputJSONSchema
        ? A.inputJSONSchema
        : id(A.inputSchema);
  if (!S7()) Y = I$_(A.name, Y);
  let _ = {
    name: A.name,
    description: await A.prompt({
      getToolPermissionContext: q.getToolPermissionContext,
      tools: q.tools,
      agents: q.agents,
      allowedAgentTypes: q.allowedAgentTypes,
    }),
    input_schema: Y,
  };
  if (K && A.strict === !0 && q.model && h56(q.model)) _.strict = !0;
  if (q.betas?.includes(Pq8) && A.input_examples)
    _.input_examples = A.input_examples;
  if (q.deferLoading) _.defer_loading = !0;
  if (q.cacheControl) _.cache_control = q.cacheControl;
  if (
    gA() === "firstParty" &&
    eN() &&
    (A1("tengu_fgts", !1) ||
      n6(process.env.CLAUDE_CODE_ENABLE_FINE_GRAINED_TOOL_STREAMING))
  )
    _.eager_input_streaming = !0;
  if (n6(process.env.CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS)) {
    let z = new Set(["name", "description", "input_schema", "cache_control"]),
      w = Object.keys(_).filter((O) => !z.has(O));
    if (w.length > 0)
      return (
        b$_(w),
        {
          name: _.name,
          description: _.description,
          input_schema: _.input_schema,
          ...(_.cache_control && { cache_control: _.cache_control }),
        }
      );
  }
  return _;
}
