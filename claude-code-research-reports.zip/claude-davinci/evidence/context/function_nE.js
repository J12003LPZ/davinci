function nE(A) {
  return {
    systemPrompt: A.systemPrompt,
    userContext: A.userContext,
    systemContext: A.systemContext,
    toolUseContext: A.toolUseContext,
    forkContextMessages: A.messages,
  };
}
