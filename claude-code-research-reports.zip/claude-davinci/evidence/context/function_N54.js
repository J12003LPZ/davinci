async function N54(A, q, K, Y) {
  if (!q) return A;
  let _ = await cS9(A, q, Y);
  if (_.newlyReplaced.length > 0) K?.(_.newlyReplaced);
  return _.messages;
}
