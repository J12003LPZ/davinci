function YX(A, q = []) {
  let K = new Set(q.map((X) => X.name)),
    Y = A$_(A),
    _ = {
      [KL1()]: new Set(["document"]),
      [YL1()]: new Set(["document"]),
      [_L1()]: new Set(["document"]),
      [wf8()]: new Set(["image"]),
      [zL1()]: new Set(["document", "image"]),
    },
    z = new Map();
  for (let X = 0; X < Y.length; X++) {
    let D = Y[X];
    if (!Vs1(D)) continue;
    let P =
      Array.isArray(D.message.content) && D.message.content[0]?.type === "text"
        ? D.message.content[0].text
        : void 0;
    if (!P) continue;
    let W = _[P];
    if (!W) continue;
    for (let f = X - 1; f >= 0; f--) {
      let Z = Y[f];
      if (Z.type === "user" && Z.isMeta) {
        let G = z.get(Z.uuid);
        if (G) for (let v of W) G.add(v);
        else z.set(Z.uuid, new Set(W));
        break;
      }
      if (Vs1(Z)) continue;
      break;
    }
  }
  let w = [];
  Y.filter((X) => {
    if (X.type === "progress" || (X.type === "system" && !gg1(X)) || Vs1(X))
      return !1;
    return !0;
  }).forEach((X) => {
    switch (X.type) {
      case "system": {
        let D = g8({
            content: X.content,
            uuid: X.uuid,
            timestamp: X.timestamp,
          }),
          P = rV(w);
        if (P?.type === "user") {
          w[w.length - 1] = aI8(P, D);
          return;
        }
        w.push(D);
        return;
      }
      case "user": {
        let D = X;
        if (!TE()) D = hs1(X);
        else D = q$_(X, K);
        let P = z.get(D.uuid);
        if (P && D.isMeta) {
          let f = D.message.content;
          if (Array.isArray(f)) {
            let Z = f.filter((G) => !P.has(G.type));
            if (Z.length === 0) return;
            if (Z.length < f.length)
              D = { ...D, message: { ...D.message, content: Z } };
          }
        }
        if (!FY("tengu_toolref_defer_j8m")) {
          let f = D.message.content;
          if (
            Array.isArray(f) &&
            !f.some((Z) => Z.type === "text" && Z.text.startsWith(gVq)) &&
            Es1(f)
          )
            D = {
              ...D,
              message: {
                ...D.message,
                content: [...f, { type: "text", text: gVq }],
              },
            };
        }
        let W = rV(w);
        if (W?.type === "user") {
          w[w.length - 1] = aI8(W, D);
          return;
        }
        w.push(D);
        return;
      }
      case "assistant": {
        let D = TE(),
          P = {
            ...X,
            message: {
              ...X.message,
              content: X.message.content.map((W) => {
                if (W.type === "tool_use") {
                  let f = q.find((v) => O3(v, W.name)),
                    Z = f ? eVq(f, W.input) : W.input,
                    G = f?.name ?? W.name;
                  if (D) return { ...W, name: G, input: Z };
                  return { type: "tool_use", id: W.id, name: G, input: Z };
                }
                return W;
              }),
            },
          };
        for (let W = w.length - 1; W >= 0; W--) {
          let f = w[W];
          if (f.type !== "assistant" && !w$_(f)) break;
          if (f.type === "assistant") {
            if (f.message.id === P.message.id) {
              w[W] = z$_(f, P);
              return;
            }
            continue;
          }
        }
        w.push(P);
        return;
      }
      case "attachment": {
        let D = nc1(X.attachment),
          P = FY("tengu_chair_sermon") ? D.map(K$_) : D,
          W = rV(w);
        if (W?.type === "user") {
          w[w.length - 1] = P.reduce((f, Z) => _$_(f, Z), W);
          return;
        }
        w.push(...P);
        return;
      }
    }
  });
  let O = FY("tengu_toolref_defer_j8m") ? Y$_(w) : w,
    $ = wn6(O),
    H = y$_($),
    j = zn6(H),
    J = R$_(j),
    M = FY("tengu_chair_sermon") ? nVq(O$_(J)) : J;
  return (iX4(M), M);
}
