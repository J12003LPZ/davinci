function Xk(A) {
  let q = E$_(A);
  if (q === -1) return A;
  return A.slice(q);
}
