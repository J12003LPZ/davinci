function Is1(A, q) {
  let K =
    R56() &&
    (n6(process.env.CLAUDE_CODE_FORCE_GLOBAL_CACHE) ||
      A1("tengu_system_prompt_global_cache", !1));
  if (K && q?.skipGlobalCacheForSystemPrompt) {
    Q("tengu_sysprompt_using_tool_based_cache", { promptBlockCount: A.length });
    let $,
      H,
      j = [];
    for (let X of A) {
      if (!X) continue;
      if (X === MY6) continue;
      if (X.startsWith("x-anthropic-billing-header")) $ = X;
      else if (vH8.has(X)) H = X;
      else j.push(X);
    }
    let J = [];
    if ($) J.push({ text: $, cacheScope: null });
    if (H) J.push({ text: H, cacheScope: "org" });
    let M = j.join(`

`);
    if (M) J.push({ text: M, cacheScope: "org" });
    return J;
  }
  if (K) {
    let $ = A.findIndex((H) => H === MY6);
    if ($ !== -1) {
      let H,
        j,
        J = [],
        M = [];
      for (let W = 0; W < A.length; W++) {
        let f = A[W];
        if (!f || f === MY6) continue;
        if (f.startsWith("x-anthropic-billing-header")) H = f;
        else if (vH8.has(f)) j = f;
        else if (W < $) J.push(f);
        else M.push(f);
      }
      let X = [];
      if (H) X.push({ text: H, cacheScope: null });
      if (j) X.push({ text: j, cacheScope: null });
      let D = J.join(`

`);
      if (D) X.push({ text: D, cacheScope: "global" });
      let P = M.join(`

`);
      if (P) X.push({ text: P, cacheScope: null });
      return (
        Q("tengu_sysprompt_boundary_found", {
          blockCount: X.length,
          staticBlockLength: D.length,
          dynamicBlockLength: P.length,
        }),
        X
      );
    } else
      Q("tengu_sysprompt_missing_boundary_marker", {
        promptBlockCount: A.length,
      });
  }
  let Y,
    _,
    z = [];
  for (let $ of A) {
    if (!$) continue;
    if ($.startsWith("x-anthropic-billing-header")) Y = $;
    else if (vH8.has($)) _ = $;
    else z.push($);
  }
  let w = [];
  if (Y) w.push({ text: Y, cacheScope: null });
  if (_) w.push({ text: _, cacheScope: "org" });
  let O = z.join(`

`);
  if (O) w.push({ text: O, cacheScope: "org" });
  return w;
}
