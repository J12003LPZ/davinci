async function DZ8() {
  let A = O8(),
    q = gZ6();
  try {
    let K = await A.readFile(q, { encoding: "utf-8" });
    return (Q("tengu_session_memory_loaded", { content_length: K.length }), K);
  } catch (K) {
    let Y = K.code;
    if (Y === "ENOENT" || Y === "EACCES" || Y === "EPERM") return null;
    throw K;
  }
}
