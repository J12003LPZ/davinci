function rQ6(A, q, K, Y, _) {
  return {
    type: "system",
    subtype: "compact_boundary",
    content: "Conversation compacted",
    isMeta: !1,
    timestamp: new Date().toISOString(),
    uuid: MN(),
    level: "info",
    compactMetadata: {
      trigger: A,
      preTokens: q,
      userContext: Y,
      messagesSummarized: _,
    },
    ...(K ? { logicalParentUuid: K } : {}),
  };
}
