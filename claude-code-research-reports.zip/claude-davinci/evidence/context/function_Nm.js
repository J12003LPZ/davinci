function Nm(A) {
  let q = [],
    K = !1;
  async function Y() {
    if (K) return;
    if (q.length === 0) return;
    K = !0;
    while (q.length > 0) {
      let { args: _, resolve: z, reject: w, context: O } = q.shift();
      try {
        let $ = await A.apply(O, _);
        z($);
      } catch ($) {
        w($);
      }
    }
    if (((K = !1), q.length > 0)) Y();
  }
  return function (..._) {
    return new Promise((z, w) => {
      (q.push({ args: _, resolve: z, reject: w, context: this }), Y());
    });
  };
}
