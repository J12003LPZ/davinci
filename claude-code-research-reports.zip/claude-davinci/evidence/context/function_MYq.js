function MYq(A, q) {
  return [
    ...A,
    Object.entries(q).map(([K, Y]) => `${K}: ${Y}`).join(`
`),
  ].filter(Boolean);
}
