function R56() {
  return (
    (gA() === "firstParty" || gA() === "foundry") &&
    !n6(process.env.CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS)
  );
}
