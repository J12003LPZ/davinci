function hf(A) {
  let q = A.length - 1;
  while (q >= 0) {
    let K = A[q],
      Y = K ? uc(K) : void 0;
    if (K && Y) {
      let _ = d34(K);
      if (_) {
        let z = q - 1;
        while (z >= 0) {
          let w = A[z],
            O = w ? d34(w) : void 0;
          if (O === _) q = z;
          else if (O !== void 0) break;
          z--;
        }
      }
      return hU6(Y) + RU6(A.slice(q + 1));
    }
    q--;
  }
  return RU6(A);
}
