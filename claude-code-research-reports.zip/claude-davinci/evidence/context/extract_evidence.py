import pathlib, re, json, hashlib
root=pathlib.Path('/workspace/research/claude-davinci')
p=root/'artifacts/claude-2.1.80/cli.pretty.js'; raw=root/'artifacts/claude-2.1.80/cli.js'
s=p.read_text(); b=raw.read_bytes(); lines=s.split("\n")
names=['UM','io','N5','RU6','cc1','xdY','uc','hU6','DE','hf','Xk','YX','MYq','qR8','ig','eQ6','IY6','Lh','Ls9','sW4','lg','FZ6','GZ8','JR1','Ts9','vZ8','ks9','SW4','EW4','bZ6','KW4','AW4','$l','rQ6','y04','dQ6','Co9','Jl','YEq','rg','u$_','R56','Is1','B$_','g$_','c$_','l$_','lR8','$Eq','tx7','nE','xf','J16','YR8','sVq','N54','G54','Ak_','rT_','sT_','ugq','qk_','Kk_','jW4','XW4','DZ8','VW4','hW4','Of4','Nm','K19','Ou7','kH8','qEq','zgY','zYq']
index=[]
for name in names:
    m=re.search(r'^(?:async )?function\*? '+re.escape(name)+r'\(',s,re.M)
    if not m: continue
    start=s[:m.start()].count('\n')+1
    end=start
    while lines[end-1]!='}': end+=1
    header=re.search(rb'(?:async )?function\*?\s*'+re.escape(name.encode())+rb'\(',b)
    if not header: raise RuntimeError(name)
    needle=b[header.start():header.start()+min(170, max(60,b.find(b'\n',header.start())-header.start()))].decode('utf8',errors='replace')
    # Entire header is unique by function name; offsets are byte offsets, zero-based.
    item={'function':name,'pretty_line_start':start,'pretty_line_end':end,'raw_byte_offset':header.start(),'raw_needle':needle,'raw_needle_occurrences':b.count(needle.encode())}
    index.append(item)
    (root/'evidence/context'/('function_'+name.replace('$','DOLLAR')+'.js')).write_text('\n'.join(lines[start-1:end])+'\n')
windows=[(317480,318270),(450335,450790),(450930,450960),(476205,476290),(545225,546090),(546680,546880),(596910,597090),(304175,304215),(258020,258220),(546345,546385),(180823,180900)]
for start,end in windows:
    (root/'evidence/context'/f'lines_{start}_{end}.txt').write_text('\n'.join(f'{i+1}: {lines[i]}' for i in range(start-1,end))+'\n')
(root/'evidence/context/source_index.json').write_text(json.dumps({'raw':str(raw),'raw_sha256':hashlib.sha256(b).hexdigest(),'pretty':str(p),'pretty_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'functions':index},indent=2)+'\n')
print(json.dumps({'functions':len(index),'raw_sha256':hashlib.sha256(b).hexdigest(),'index':str(root/'evidence/context/source_index.json')}))
