function dQ6(A, q, K, Y) {
  let z = `This session is being continued from a previous conversation that ran out of context. The summary below covers the earlier portion of the conversation.

${Co9(A)}`;
  if (K)
    z += `

If you need specific details from before compaction (like exact code snippets, error messages, or content you generated), read the full transcript at: ${K}`;
  if (Y)
    z += `

Recent messages are preserved verbatim.`;
  if (q)
    return `${z}
Continue the conversation from where it left off without asking the user any further questions. Resume directly — do not acknowledge the summary, do not recap what was happening, do not preface with "I'll continue" or similar. Pick up the last task as if the break never happened.`;
  return z;
}
