function ig(A) {
  let q = Math.min(aQ6(A), Vs9),
    K = UM(A, bH()),
    Y = process.env.CLAUDE_CODE_AUTO_COMPACT_WINDOW;
  if (Y) {
    let _ = parseInt(Y, 10);
    if (!isNaN(_) && _ > 0) K = Math.min(K, _);
  }
  return K - q;
}
