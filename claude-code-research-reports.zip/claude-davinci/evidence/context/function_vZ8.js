async function vZ8(A, q, K) {
  if (!GZ8()) return null;
  (await Zs9(), await XW4());
  let Y = jW4(),
    _ = await DZ8();
  if (!_) return (Q("tengu_sm_compact_no_session_memory", {}), null);
  if (await RW4(_)) return (Q("tengu_sm_compact_empty_template", {}), null);
  try {
    let z;
    if (Y) {
      if (((z = A.findIndex((X) => X.uuid === Y)), z === -1))
        return (Q("tengu_sm_compact_summarized_id_not_found", {}), null);
    } else ((z = A.length - 1), Q("tengu_sm_compact_resumed_session", {}));
    let w = Ts9(A, z),
      O = A.slice(w).filter((X) => !mf(X)),
      $ = await dD("compact", { model: vK() }),
      H = J_(),
      j = ks9(A, _, O, $, H, q),
      J = $l(j),
      M = FZ6(J);
    if (K !== void 0 && M >= K)
      return (
        Q("tengu_sm_compact_threshold_exceeded", {
          postCompactTokenCount: M,
          autoCompactThreshold: K,
        }),
        null
      );
    return { ...j, postCompactTokenCount: M, truePostCompactTokenCount: M };
  } catch (z) {
    return (Q("tengu_sm_compact_error", {}), null);
  }
}
