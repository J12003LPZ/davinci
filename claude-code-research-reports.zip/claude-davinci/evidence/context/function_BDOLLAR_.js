function B$_(A, q = !1, K, Y) {
  if (q)
    if (typeof A.message.content === "string")
      return {
        role: "user",
        content: [
          {
            type: "text",
            text: A.message.content,
            ...(K ? { cache_control: rg({ querySource: Y }) } : {}),
          },
        ],
      };
    else
      return {
        role: "user",
        content: A.message.content.map((_, z) => ({
          ..._,
          ...(z === A.message.content.length - 1
            ? K
              ? { cache_control: rg({ querySource: Y }) }
              : {}
            : {}),
        })),
      };
  return {
    role: "user",
    content: Array.isArray(A.message.content)
      ? [...A.message.content]
      : A.message.content,
  };
}
