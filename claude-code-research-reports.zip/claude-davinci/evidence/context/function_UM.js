function UM(A, q) {
  if (oZ(A)) return 1e6;
  let K = IM1(A);
  if (K?.max_input_tokens && K.max_input_tokens >= 1e5) {
    if (K.max_input_tokens > xM1 && dQ()) return xM1;
    return K.max_input_tokens;
  }
  if (q?.includes(pa) && VY1(A)) return 1e6;
  if (uM1(A)) return 1e6;
  return xM1;
}
