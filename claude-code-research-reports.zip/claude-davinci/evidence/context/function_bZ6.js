async function bZ6(A, q, K, Y, _, z = !1, w) {
  try {
    if (A.length === 0) throw Error(IZ6);
    let O = hf(A),
      $ = d04(A),
      H = {};
    try {
      H = c04($);
    } catch (e) {
      $6(e);
    }
    let j = q.getAppState();
    (of8(j.toolPermissionContext, "summary"),
      q.onCompactProgress?.({ type: "hooks_start", hookType: "pre_compact" }),
      q.setSDKStatus?.("compacting"));
    let J = await xZ6(
      { trigger: z ? "auto" : "manual", customInstructions: _ ?? null },
      q.abortController.signal,
    );
    _ = zR1(_, J.newCustomInstructions);
    let M = J.userDisplayMessage;
    (q.setStreamMode?.("requesting"),
      q.setResponseLength?.(() => 0),
      q.onCompactProgress?.({ type: "compact_start" }));
    let X = A1("tengu_compact_cache_prefix", !1),
      D = y04(_),
      P = g8({ content: D }),
      W = await KW4({
        messages: A,
        summaryRequest: P,
        appState: j,
        context: q,
        preCompactTokenCount: O,
        cacheSafeParams: K,
      }),
      f = MZ8(W);
    if (!f)
      throw (
        V(`Compact failed: no summary text in response. Response: ${m6(W)}`, {
          level: "error",
        }),
        Q("tengu_compact_failed", {
          reason: "no_summary",
          preCompactTokenCount: O,
          promptCacheSharingEnabled: X,
        }),
        Error(
          "Failed to generate conversation summary - response did not contain valid text content",
        )
      );
    else if (sc(f))
      throw (
        Q("tengu_compact_failed", {
          reason: "api_error",
          preCompactTokenCount: O,
          promptCacheSharingEnabled: X,
        }),
        Error(f)
      );
    else if (f.startsWith(xg))
      throw (
        Q("tengu_compact_failed", {
          reason: "prompt_too_long",
          preCompactTokenCount: O,
          promptCacheSharingEnabled: X,
        }),
        Error(e04)
      );
    let Z = bV1(q.readFileState);
    (q.readFileState.clear(), jl());
    let [G, v] = await Promise.all([YW4(Z, q, t04), wW4(q)]),
      k = [...G, ...v],
      N = OZ8(q.agentId);
    if (N) k.push(N);
    let E = await zW4(q);
    if (E) k.push(E);
    let h = _W4(q.agentId);
    if (h) k.push(h);
    for (let e of $Z8(q.options.tools, q.options.mainLoopModel, []))
      k.push(V4(e));
    for (let e of HZ8(
      q.options.mcpClients,
      q.options.tools,
      q.options.mainLoopModel,
      [],
    ))
      k.push(V4(e));
    q.onCompactProgress?.({ type: "hooks_start", hookType: "session_start" });
    let R = await dD("compact", { model: q.options.mainLoopModel }),
      m = rQ6(z ? "auto" : "manual", O ?? 0, A[A.length - 1]?.uuid),
      I = cg(A);
    if (I.size > 0) m.compactMetadata.preCompactDiscoveredTools = [...I].sort();
    let g = J_(),
      u = [
        g8({
          content: dQ6(f, Y, g),
          isCompactSummary: !0,
          isVisibleInTranscriptOnly: !0,
        }),
      ],
      b = DE([W]),
      p = RU6([m, ...u, ...k, ...R]),
      U = uc(W),
      d = w?.querySource ?? q.options.querySource ?? "unknown";
    (Q("tengu_compact", {
      preCompactTokenCount: O,
      postCompactTokenCount: b,
      truePostCompactTokenCount: p,
      autoCompactThreshold: w?.autoCompactThreshold ?? -1,
      willRetriggerNextTurn: w !== void 0 && p >= w.autoCompactThreshold,
      isAutoCompact: z,
      querySource: d,
      queryChainId: q.queryTracking?.chainId ?? "",
      queryDepth: q.queryTracking?.depth ?? -1,
      isRecompactionInChain: w?.isRecompactionInChain ?? !1,
      turnsSincePreviousCompact: w?.turnsSincePreviousCompact ?? -1,
      previousCompactTurnId: w?.previousCompactTurnId ?? "",
      compactionInputTokens: U?.input_tokens,
      compactionOutputTokens: U?.output_tokens,
      compactionCacheReadTokens: U?.cache_read_input_tokens ?? 0,
      compactionCacheCreationTokens: U?.cache_creation_input_tokens ?? 0,
      compactionTotalTokens: U
        ? U.input_tokens +
          (U.cache_creation_input_tokens ?? 0) +
          (U.cache_read_input_tokens ?? 0) +
          U.output_tokens
        : 0,
      promptCacheSharingEnabled: X,
      ...H,
    }),
      JZ8(),
      q.onCompactProgress?.({ type: "hooks_start", hookType: "post_compact" }));
    let r = await jZ8(
        { trigger: z ? "auto" : "manual", compactSummary: f },
        q.abortController.signal,
      ),
      t = [M, r.userDisplayMessage].filter(Boolean).join(`
`);
    return {
      boundaryMarker: m,
      summaryMessages: u,
      attachments: k,
      hookResults: R,
      userDisplayMessage: t || void 0,
      preCompactTokenCount: O,
      postCompactTokenCount: b,
      truePostCompactTokenCount: p,
      compactionUsage: U,
    };
  } catch (O) {
    if (!z) qW4(O, q);
    throw O;
  } finally {
    (q.setStreamMode?.("requesting"),
      q.setResponseLength?.(() => 0),
      q.onCompactProgress?.({ type: "compact_end" }),
      q.setSDKStatus?.(null));
  }
}
