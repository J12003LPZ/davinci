function G54(A, q) {
  if (!A1("tengu_hawthorn_steeple", !1)) return;
  if (A) return M08(A, q ?? []);
  return OU6();
}
