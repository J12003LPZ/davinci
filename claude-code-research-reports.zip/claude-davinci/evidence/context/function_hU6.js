function hU6(A) {
  return (
    A.input_tokens +
    (A.cache_creation_input_tokens ?? 0) +
    (A.cache_read_input_tokens ?? 0) +
    A.output_tokens
  );
}
