function GZ8() {
  if (n6(process.env.ENABLE_CLAUDE_CODE_SM_COMPACT)) return !0;
  if (n6(process.env.DISABLE_CLAUDE_CODE_SM_COMPACT)) return !1;
  let A = A1("tengu_session_memory", !1),
    q = A1("tengu_sm_compact", !1);
  return A && q;
}
