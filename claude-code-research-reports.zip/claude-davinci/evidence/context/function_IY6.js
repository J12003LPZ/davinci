function IY6(A, q) {
  let K = eQ6(q),
    Y = Lh() ? K : ig(q),
    _ = Math.max(0, Math.round(((Y - A) / Y) * 100)),
    z = Y - Es9,
    w = Y - ys9,
    O = A >= z,
    $ = A >= w,
    H = Lh() && A >= K,
    J = ig(q) - ZR1,
    M = process.env.CLAUDE_CODE_BLOCKING_LIMIT_OVERRIDE,
    X = M ? parseInt(M, 10) : NaN,
    D = !isNaN(X) && X > 0 ? X : J,
    P = A >= D;
  return {
    percentLeft: _,
    isAboveWarningThreshold: O,
    isAboveErrorThreshold: $,
    isAboveAutoCompactThreshold: H,
    isAtBlockingLimit: P,
  };
}
