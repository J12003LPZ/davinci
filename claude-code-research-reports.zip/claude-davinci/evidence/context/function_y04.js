function y04(A) {
  let q = ho9.replace(lf8, V04(yo9));
  if (A && A.trim() !== "")
    q += `

Additional Instructions:
${A}`;
  return (
    (q += `

IMPORTANT: Do NOT use any tools. You MUST respond with ONLY the <summary>...</summary> block as your text output.`),
    q
  );
}
