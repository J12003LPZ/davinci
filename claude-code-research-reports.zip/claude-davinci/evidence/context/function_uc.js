function uc(A) {
  if (
    A?.type === "assistant" &&
    "usage" in A.message &&
    !(
      A.message.content[0]?.type === "text" &&
      SU6.has(A.message.content[0].text)
    ) &&
    A.message.model !== i96
  )
    return A.message.usage;
  return;
}
