function Lh() {
  if (n6(process.env.DISABLE_COMPACT)) return !1;
  if (n6(process.env.DISABLE_AUTO_COMPACT)) return !1;
  return D8().autoCompactEnabled;
}
