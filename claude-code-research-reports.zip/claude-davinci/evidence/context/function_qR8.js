function qR8(A, q) {
  if (Object.entries(q).length === 0) return A;
  return [
    g8({
      content: `<system-reminder>
As you answer the user's questions, you can use the following context:
${Object.entries(q).map(
  ([K, Y]) => `# ${K}
${Y}`,
).join(`
`)}

      IMPORTANT: this context may or may not be relevant to your tasks. You should not respond to this context unless it is highly relevant to your task.
</system-reminder>
`,
      isMeta: !0,
    }),
    ...A,
  ];
}
