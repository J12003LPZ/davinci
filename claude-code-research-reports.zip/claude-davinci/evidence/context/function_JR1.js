function JR1(A, q) {
  if (q <= 0 || q >= A.length) return q;
  let K = q,
    Y = [];
  for (let z = q; z < A.length; z++) Y.push(...Gs9(A[z]));
  if (Y.length > 0) {
    let z = new Set();
    for (let O = K; O < A.length; O++) {
      let $ = A[O];
      if ($.type === "assistant" && Array.isArray($.message.content)) {
        for (let H of $.message.content) if (H.type === "tool_use") z.add(H.id);
      }
    }
    let w = new Set(Y.filter((O) => !z.has(O)));
    for (let O = K - 1; O >= 0 && w.size > 0; O--) {
      let $ = A[O];
      if (vs9($, w)) {
        if (
          ((K = O), $.type === "assistant" && Array.isArray($.message.content))
        ) {
          for (let H of $.message.content)
            if (H.type === "tool_use" && w.has(H.id)) w.delete(H.id);
        }
      }
    }
  }
  let _ = new Set();
  for (let z = K; z < A.length; z++) {
    let w = A[z];
    if (w.type === "assistant" && w.message.id) _.add(w.message.id);
  }
  for (let z = K - 1; z >= 0; z--) {
    let w = A[z];
    if (w.type === "assistant" && w.message.id && _.has(w.message.id)) K = z;
  }
  return K;
}
