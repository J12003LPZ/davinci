function xdY(A) {
  if (typeof A === "string") return N5(A);
  if (A.type === "text") return N5(A.text);
  if (A.type === "image" || A.type === "document") return 2000;
  if (A.type === "tool_result") return cc1(A.content);
  if (A.type === "tool_use") return N5(A.name + m6(A.input ?? {}));
  if (A.type === "thinking") return N5(A.thinking);
  if (A.type === "redacted_thinking") return N5(A.data);
  return N5(m6(A));
}
