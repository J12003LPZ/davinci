function Ts9(A, q) {
  if (A.length === 0) return 0;
  let K = fs9(),
    Y = q >= 0 ? q + 1 : A.length,
    _ = 0,
    z = 0;
  for (let O = Y; O < A.length; O++) {
    let $ = A[O];
    if (((_ += FZ6([$])), UW4($))) z++;
  }
  if (_ >= K.maxTokens) return JR1(A, Y);
  if (_ >= K.minTokens && z >= K.minTextBlockMessages) return JR1(A, Y);
  let w = 0;
  for (let O = A.length - 1; O >= 0; O--)
    if (mf(A[O])) {
      w = O + 1;
      break;
    }
  for (let O = Y - 1; O >= w; O--) {
    let $ = A[O],
      H = FZ6([$]);
    if (((_ += H), UW4($))) z++;
    if (((Y = O), _ >= K.maxTokens)) break;
    if (_ >= K.minTokens && z >= K.minTextBlockMessages) break;
  }
  return JR1(A, Y);
}
