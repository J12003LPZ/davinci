function DE(A) {
  let q = A.length - 1;
  while (q >= 0) {
    let K = A[q],
      Y = K ? uc(K) : void 0;
    if (Y) return hU6(Y);
    q--;
  }
  return 0;
}
