async function sW4(A, q, K, Y, _, z) {
  if (n6(process.env.DISABLE_COMPACT)) return { wasCompacted: !1 };
  if (_?.consecutiveFailures !== void 0 && _.consecutiveFailures >= oW4)
    return { wasCompacted: !1 };
  let w = q.options.mainLoopModel;
  if (!(await Ls9(A, w, Y, z))) return { wasCompacted: !1 };
  let $ = {
      isRecompactionInChain: _?.compacted === !0,
      turnsSincePreviousCompact: _?.turnCounter ?? -1,
      previousCompactTurnId: _?.turnId,
      autoCompactThreshold: eQ6(w),
      querySource: Y,
    },
    H = await vZ8(A, q.agentId, $.autoCompactThreshold);
  if (H) return (L66(void 0), Jl(Y), { wasCompacted: !0, compactionResult: H });
  try {
    let j = await bZ6(A, q, K, !0, void 0, !0, $);
    return (
      L66(void 0),
      Jl(Y),
      { wasCompacted: !0, compactionResult: j, consecutiveFailures: 0 }
    );
  } catch (j) {
    if (!Ma(j, Ol)) $6(j);
    let M = (_?.consecutiveFailures ?? 0) + 1;
    if (M >= oW4)
      V(
        `autocompact: circuit breaker tripped after ${M} consecutive failures — skipping future attempts this session`,
        { level: "warn" },
      );
    return { wasCompacted: !1, consecutiveFailures: M };
  }
}
