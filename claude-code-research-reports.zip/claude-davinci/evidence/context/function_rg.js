function rg({ scope: A, querySource: q } = {}) {
  return {
    type: "ephemeral",
    ...(u$_(q) ? { ttl: "1h" } : {}),
    ...(A === "global" ? { scope: A } : {}),
  };
}
