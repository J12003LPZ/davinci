function N5(A, q = 4) {
  return Math.round(A.length / q);
}
