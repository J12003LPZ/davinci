function c$_(A, q, K, Y = !1, _, z, w = !1) {
  Q("tengu_api_cache_breakpoints", {
    totalMessageCount: A.length,
    cachingEnabled: q,
    skipCacheWrite: w,
  });
  let O = w ? A.length - 2 : A.length - 1,
    $ = A.map((J, M) => {
      let X = M === O;
      if (J.type === "user") return B$_(J, X, q, K);
      return g$_(J, X, q, K);
    });
  if (!Y) return $;
  let H = new Set(),
    j = (J) => {
      let M = J.edits.filter((X) => {
        if (H.has(X.cache_reference)) return !1;
        return (H.add(X.cache_reference), !0);
      });
      return { ...J, edits: M };
    };
  for (let J of z ?? []) {
    let M = $[J.userMessageIndex];
    if (M && M.role === "user") {
      if (!Array.isArray(M.content))
        M.content = [{ type: "text", text: M.content }];
      let X = j(J.block);
      if (X.edits.length > 0) xs1(M.content, X);
    }
  }
  if (_ && $.length > 0) {
    let J = j(_);
    if (J.edits.length > 0)
      for (let M = $.length - 1; M >= 0; M--) {
        let X = $[M];
        if (X && X.role === "user") {
          if (!Array.isArray(X.content))
            X.content = [{ type: "text", text: X.content }];
          (xs1(X.content, J),
            pW4(M, _),
            V(
              `Added cache_edits block with ${J.edits.length} deletion(s) to message[${M}]: ${J.edits.map((D) => D.cache_reference).join(", ")}`,
            ));
          break;
        }
      }
  }
  if (q) {
    let J = -1;
    for (let M = 0; M < $.length; M++) {
      let X = $[M];
      if (Array.isArray(X.content)) {
        for (let D of X.content)
          if (D && typeof D === "object" && "cache_control" in D) J = M;
      }
    }
    if (J >= 0)
      for (let M = 0; M < J; M++) {
        let X = $[M];
        if (X.role !== "user" || !Array.isArray(X.content)) continue;
        let D = !1;
        for (let P = 0; P < X.content.length; P++) {
          let W = X.content[P];
          if (W && d$_(W)) {
            if (!D) ((X.content = [...X.content]), (D = !0));
            X.content[P] = Object.assign({}, W, {
              cache_reference: W.tool_use_id,
            });
          }
        }
      }
  }
  return $;
}
