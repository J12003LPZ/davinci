async function* zgY(A, q) {
  let {
      systemPrompt: K,
      userContext: Y,
      systemContext: _,
      canUseTool: z,
      fallbackModel: w,
      querySource: O,
      maxTurns: $,
      skipCacheWrite: H,
    } = A,
    j = A.deps ?? zYq(),
    J = {
      messages: A.messages,
      toolUseContext: A.toolUseContext,
      maxOutputTokensOverride: A.maxOutputTokensOverride,
      autoCompactTracking: void 0,
      stopHookActive: void 0,
      maxOutputTokensRecoveryCount: 0,
      hasAttemptedReactiveCompact: !1,
      turnCount: 1,
      pendingToolUseSummary: void 0,
      transition: void 0,
    },
    M = null,
    X = YYq();
  while (!0) {
    let { toolUseContext: D } = J,
      {
        messages: P,
        autoCompactTracking: W,
        maxOutputTokensRecoveryCount: f,
        hasAttemptedReactiveCompact: Z,
        maxOutputTokensOverride: G,
        pendingToolUseSummary: v,
        stopHookActive: k,
        turnCount: N,
      } = J,
      E = HYq(P, D),
      h = Gd1?.startSkillDiscoveryPrefetch(null, P, D);
    if (
      (yield { type: "stream_request_start" }, M5("query_fn_entry"), !D.agentId)
    )
      bY6("query_started");
    let R = D.queryTracking
        ? { chainId: D.queryTracking.chainId, depth: D.queryTracking.depth + 1 }
        : { chainId: j.uuid(), depth: 0 },
      m = R.chainId;
    D = { ...D, queryTracking: R };
    let I = [...Xk(P)],
      g = W,
      u = O.startsWith("agent:") || O.startsWith("repl_main_thread");
    I = await N54(
      I,
      D.contentReplacementState,
      u ? (W6) => void Kw6(W6, D.agentId).catch($6) : void 0,
      new Set(
        D.options.tools
          .filter((W6) => !Number.isFinite(W6.maxResultSizeChars))
          .map((W6) => W6.name),
      ),
    );
    let b = 0;
    (M5("query_microcompact_start"),
      (I = (await j.microcompact(I, D, O)).messages));
    let U = void 0;
    M5("query_microcompact_end");
    let d = iq(MYq(K, _));
    M5("query_autocompact_start");
    let { compactionResult: r, consecutiveFailures: t } = await j.autocompact(
      I,
      D,
      {
        systemPrompt: K,
        userContext: Y,
        systemContext: _,
        toolUseContext: D,
        forkContextMessages: I,
      },
      O,
      g,
      b,
    );
    if ((M5("query_autocompact_end"), r)) {
      let {
        preCompactTokenCount: W6,
        postCompactTokenCount: T6,
        truePostCompactTokenCount: h6,
        compactionUsage: F6,
      } = r;
      (Q("tengu_auto_compact_succeeded", {
        originalMessageCount: P.length,
        compactedMessageCount:
          r.summaryMessages.length +
          r.attachments.length +
          r.hookResults.length,
        preCompactTokenCount: W6,
        postCompactTokenCount: T6,
        truePostCompactTokenCount: h6,
        compactionInputTokens: F6?.input_tokens,
        compactionOutputTokens: F6?.output_tokens,
        compactionCacheReadTokens: F6?.cache_read_input_tokens ?? 0,
        compactionCacheCreationTokens: F6?.cache_creation_input_tokens ?? 0,
        compactionTotalTokens: F6
          ? F6.input_tokens +
            (F6.cache_creation_input_tokens ?? 0) +
            (F6.cache_read_input_tokens ?? 0) +
            F6.output_tokens
          : 0,
        queryChainId: m,
        queryDepth: R.depth,
      }),
        (g = {
          compacted: !0,
          turnId: j.uuid(),
          turnCounter: 0,
          consecutiveFailures: 0,
        }));
      let U6 = $l(r);
      for (let k6 of U6) yield k6;
      I = U6;
    } else if (t !== void 0)
      g = {
        ...(g ?? { compacted: !1, turnId: "", turnCounter: 0 }),
        consecutiveFailures: t,
      };
    D = { ...D, messages: I };
    let e = [],
      q6 = [],
      H6 = [],
      K6 = !1;
    M5("query_setup_start");
    let j6 = X.gates.streamingToolExecution
        ? new Jr6(D.options.tools, z, D)
        : null,
      z6 = D.getAppState(),
      G6 = z6.toolPermissionContext.mode,
      X6 = tC({
        permissionMode: G6,
        mainLoopModel: D.options.mainLoopModel,
        exceeds200kTokens: G6 === "plan" && B08(I),
      });
    M5("query_setup_end");
    let c = X.gates.isAnt ? Hf4(D.agentId ?? X.sessionId) : void 0,
      n = !1,
      A6 = qw6?.isReactiveCompactEnabled() ?? !1;
    if (
      !r &&
      O !== "compact" &&
      O !== "session_memory" &&
      !(qw6?.isReactiveCompactEnabled() && Lh()) &&
      !n
    ) {
      let { isAtBlockingLimit: W6 } = IY6(hf(I) - b, D.options.mainLoopModel);
      if (W6)
        return (
          yield S9({ content: xg, error: "invalid_request" }),
          { reason: "blocking_limit" }
        );
    }
    let a = !0;
    M5("query_api_loop_start");
    try {
      while (a) {
        a = !1;
        try {
          let W6 = !1;
          M5("query_api_streaming_start");
          for await (let T6 of j.callModel({
            messages: qR8(I, Y),
            systemPrompt: d,
            thinkingConfig: D.options.thinkingConfig,
            tools: D.options.tools,
            signal: D.abortController.signal,
            options: {
              async getToolPermissionContext() {
                return D.getAppState().toolPermissionContext;
              },
              model: X6,
              ...(X.gates.fastModeEnabled ? { fastMode: z6.fastMode } : {}),
              toolChoice: void 0,
              isNonInteractiveSession: D.options.isNonInteractiveSession,
              fallbackModel: w,
              onStreamingFallback: () => {
                W6 = !0;
              },
              querySource: O,
              agents: D.options.agentDefinitions.activeAgents,
              allowedAgentTypes: D.options.agentDefinitions.allowedAgentTypes,
              hasAppendSystemPrompt: !!D.options.appendSystemPrompt,
              maxOutputTokensOverride: G,
              fetchOverride: c,
              mcpTools: z6.mcp.tools,
              hasPendingMcpServers: z6.mcp.clients.some(
                (h6) => h6.type === "pending",
              ),
              queryTracking: R,
              effortValue: z6.effortValue,
              ...{},
              skipCacheWrite: H,
              agentId: D.agentId,
              addNotification: D.addNotification,
            },
          })) {
            if (W6) {
              for (let U6 of e) yield { type: "tombstone", message: U6 };
              if (
                (Q("tengu_orphaned_messages_tombstoned", {
                  orphanedMessageCount: e.length,
                  queryChainId: m,
                  queryDepth: R.depth,
                }),
                (e.length = 0),
                (q6.length = 0),
                (H6.length = 0),
                (K6 = !1),
                j6)
              )
                (j6.discard(), (j6 = new Jr6(D.options.tools, z, D)));
            }
            let h6 = T6;
            if (T6.type === "assistant") {
              let U6;
              for (let k6 = 0; k6 < T6.message.content.length; k6++) {
                let C6 = T6.message.content[k6];
                if (
                  C6.type === "tool_use" &&
                  typeof C6.input === "object" &&
                  C6.input !== null
                ) {
                  let o6 = $5(D.options.tools, C6.name);
                  if (o6?.backfillObservableInput) {
                    let e6 = { ...C6.input };
                    (o6.backfillObservableInput(e6),
                      (U6 ??= [...T6.message.content]),
                      (U6[k6] = { ...C6, input: e6 }));
                  }
                }
              }
              if (U6) h6 = { ...T6, message: { ...T6.message, content: U6 } };
            }
            let F6 = !1;
            if (qw6?.isWithheldPromptTooLong(T6)) F6 = !0;
            if (A6 && qw6?.isWithheldMediaSizeError(T6)) F6 = !0;
            if ($Yq(T6)) F6 = !0;
            if (!F6) yield h6;
            if (T6.type === "assistant") {
              e.push(T6);
              let U6 = T6.message.content.filter(
                (k6) => k6.type === "tool_use",
              );
              if (U6.length > 0) (H6.push(...U6), (K6 = !0));
              if (j6 && !D.abortController.signal.aborted)
                for (let k6 of U6) j6.addTool(k6, T6);
            }
            if (j6 && !D.abortController.signal.aborted) {
              for (let U6 of j6.getCompletedResults())
                if (U6.message)
                  (yield U6.message,
                    q6.push(
                      ...YX([U6.message], D.options.tools).filter(
                        (k6) => k6.type === "user",
                      ),
                    ));
            }
          }
          M5("query_api_streaming_end");
        } catch (W6) {
          if (W6 instanceof yY6 && w) {
            if (
              ((X6 = w),
              (a = !0),
              yield* vd1(e, "Model fallback triggered"),
              (e.length = 0),
              (q6.length = 0),
              (H6.length = 0),
              (K6 = !1),
              j6)
            )
              (j6.discard(), (j6 = new Jr6(D.options.tools, z, D)));
            ((D.options.mainLoopModel = w),
              Q("tengu_model_fallback_triggered", {
                original_model: W6.originalModel,
                fallback_model: w,
                entrypoint: "cli",
                queryChainId: m,
                queryDepth: R.depth,
              }),
              yield L$(
                `Switched to ${bj(W6.fallbackModel)} due to high demand for ${bj(W6.originalModel)}`,
                "warning",
              ));
            continue;
          }
          throw W6;
        }
      }
    } catch (W6) {
      $6(W6);
      let T6 = W6 instanceof Error ? W6.message : String(W6);
      if (
        (Q("tengu_query_error", {
          assistantMessages: e.length,
          toolUses: e.flatMap((h6) =>
            h6.message.content.filter((F6) => F6.type === "tool_use"),
          ).length,
          queryChainId: m,
          queryDepth: R.depth,
        }),
        W6 instanceof DZ6 || W6 instanceof $g)
      )
        return (yield S9({ content: W6.message }), { reason: "image_error" });
      return (
        yield* vd1(e, T6),
        yield pp({ toolUse: !1 }),
        gN("Query error", W6),
        { reason: "model_error", error: W6 }
      );
    }
    if (e.length > 0) Of4([...I, ...e], K, Y, _, D, O);
    if (D.abortController.signal.aborted) {
      if (j6) {
        for await (let W6 of j6.getRemainingResults())
          if (W6.message) yield W6.message;
      } else yield* vd1(e, "Interrupted by user");
      if (D.abortController.signal.reason !== "interrupt")
        yield pp({ toolUse: !1 });
      return { reason: "aborted_streaming" };
    }
    if (v) {
      let W6 = await v;
      if (W6) yield W6;
    }
    if (!K6) {
      let W6 = e[e.length - 1],
        T6 = W6?.type === "assistant" && W6.isApiErrorMessage && rX4(W6),
        h6 = A6 && qw6?.isWithheldMediaSizeError(W6);
      if ((T6 || h6) && qw6) {
        let U6 = await qw6.tryReactiveCompact({
          hasAttempted: Z,
          querySource: O,
          aborted: D.abortController.signal.aborted,
          messages: I,
          cacheSafeParams: {
            systemPrompt: K,
            userContext: Y,
            systemContext: _,
            toolUseContext: D,
            forkContextMessages: I,
          },
        });
        if (U6) {
          let k6 = $l(U6);
          for (let o6 of k6) yield o6;
          J = {
            messages: k6,
            toolUseContext: D,
            autoCompactTracking: void 0,
            maxOutputTokensRecoveryCount: f,
            hasAttemptedReactiveCompact: !0,
            maxOutputTokensOverride: void 0,
            pendingToolUseSummary: void 0,
            stopHookActive: void 0,
            turnCount: N,
            transition: { reason: "reactive_compact_retry" },
          };
          continue;
        }
        return (
          yield W6,
          AR8(W6, D),
          { reason: h6 ? "image_error" : "prompt_too_long" }
        );
      }
      if ($Yq(W6)) {
        if (f < _gY) {
          let U6 = g8({
            content:
              "Output token limit hit. Resume directly — no apology, no recap of what you were doing. " +
              "Pick up mid-thought if that is where the cut happened. Break remaining work into smaller pieces.",
            isMeta: !0,
          });
          J = {
            messages: [...I, ...e, U6],
            toolUseContext: D,
            autoCompactTracking: g,
            maxOutputTokensRecoveryCount: f + 1,
            hasAttemptedReactiveCompact: Z,
            maxOutputTokensOverride: void 0,
            pendingToolUseSummary: void 0,
            stopHookActive: void 0,
            turnCount: N,
            transition: {
              reason: "max_output_tokens_recovery",
              attempt: f + 1,
            },
          };
          continue;
        }
        yield W6;
      }
      if (W6?.isApiErrorMessage) return (AR8(W6, D), { reason: "completed" });
      let F6 = yield* t9q(I, e, K, Y, _, D, O, k);
      if (F6.preventContinuation) return { reason: "stop_hook_prevented" };
      if (F6.blockingErrors.length > 0) {
        J = {
          messages: [...I, ...e, ...F6.blockingErrors],
          toolUseContext: D,
          autoCompactTracking: g,
          maxOutputTokensRecoveryCount: 0,
          hasAttemptedReactiveCompact: Z,
          maxOutputTokensOverride: void 0,
          pendingToolUseSummary: void 0,
          stopHookActive: !0,
          turnCount: N,
          transition: { reason: "stop_hook_blocking" },
        };
        continue;
      }
      return { reason: "completed" };
    }
    let s = !1,
      O6 = D;
    if ((M5("query_tool_execution_start"), j6))
      Q("tengu_streaming_tool_execution_used", {
        tool_count: H6.length,
        queryChainId: m,
        queryDepth: R.depth,
      });
    else
      Q("tengu_streaming_tool_execution_not_used", {
        tool_count: H6.length,
        queryChainId: m,
        queryDepth: R.depth,
      });
    let J6 = j6 ? j6.getRemainingResults() : rL8(H6, e, z, D);
    for await (let W6 of J6) {
      if (W6.message) {
        if (
          (yield W6.message,
          W6.message.type === "attachment" &&
            W6.message.attachment.type === "hook_stopped_continuation")
        )
          s = !0;
        q6.push(
          ...YX([W6.message], D.options.tools).filter(
            (T6) => T6.type === "user",
          ),
        );
      }
      if (W6.newContext) O6 = { ...W6.newContext, queryTracking: R };
    }
    M5("query_tool_execution_end");
    let Z6;
    if (
      X.gates.emitToolUseSummaries &&
      H6.length > 0 &&
      !D.abortController.signal.aborted
    ) {
      let W6 = e[e.length - 1],
        T6;
      if (W6) {
        let U6 = W6.message.content.filter((k6) => k6.type === "text");
        if (U6.length > 0) {
          let k6 = U6[U6.length - 1];
          if (k6 && "text" in k6) T6 = k6.text;
        }
      }
      let h6 = H6.map((U6) => U6.id),
        F6 = H6.map((U6) => {
          let k6 = q6.find(
              (o6) =>
                o6.type === "user" &&
                Array.isArray(o6.message.content) &&
                o6.message.content.some(
                  (e6) => e6.type === "tool_result" && e6.tool_use_id === U6.id,
                ),
            ),
            C6 =
              k6?.type === "user" && Array.isArray(k6.message.content)
                ? k6.message.content.find(
                    (o6) =>
                      o6.type === "tool_result" && o6.tool_use_id === U6.id,
                  )
                : void 0;
          return {
            name: U6.name,
            input: U6.input,
            output: C6 && "content" in C6 ? C6.content : null,
          };
        });
      Z6 = Af4({
        tools: F6,
        signal: D.abortController.signal,
        isNonInteractiveSession: D.options.isNonInteractiveSession,
        lastAssistantText: T6,
      })
        .then((U6) => {
          if (U6) return JYq(U6, h6);
          return null;
        })
        .catch(() => null);
    }
    if (D.abortController.signal.aborted) {
      if (D.abortController.signal.reason !== "interrupt")
        yield pp({ toolUse: !0 });
      let W6 = N + 1;
      if ($ && W6 > $)
        yield V4({ type: "max_turns_reached", maxTurns: $, turnCount: W6 });
      return { reason: "aborted_tools" };
    }
    if (s) return { reason: "hook_stopped" };
    if (g?.compacted)
      (g.turnCounter++,
        Q("tengu_post_autocompact_turn", {
          turnId: g.turnId,
          turnCounter: g.turnCounter,
          queryChainId: m,
          queryDepth: R.depth,
        }));
    Q("tengu_query_before_attachments", {
      messagesForQueryCount: I.length,
      assistantMessagesCount: e.length,
      toolResultsCount: q6.length,
      queryChainId: m,
      queryDepth: R.depth,
    });
    let f6 = H6.some((W6) => W6.name === o96),
      y6 =
        O.startsWith("repl_main_thread") || O === "sdk"
          ? IP8(f6 ? "later" : "next")
          : [];
    for await (let W6 of MT6(null, O6, null, y6, [...I, ...e, ...q6], O))
      (yield W6, q6.push(W6));
    if (E) {
      let W6 = jYq(await E, H6);
      for (let T6 of W6) {
        let h6 = V4(T6);
        (yield h6, q6.push(h6));
      }
    }
    if (Gd1 && h) {
      let W6 = await Gd1.collectSkillDiscoveryPrefetch(h);
      for (let T6 of W6) {
        let h6 = V4(T6);
        (yield h6, q6.push(h6));
      }
    }
    let v6 = y6.filter(
      (W6) => W6.mode === "prompt" || W6.mode === "task-notification",
    );
    if (v6.length > 0) {
      for (let W6 of v6) if (W6.uuid) (q.push(W6.uuid), ng(W6.uuid, "started"));
      e74(v6);
    }
    let V6 = q6.filter(
      (W6) =>
        W6.type === "attachment" && W6.attachment.type === "edited_text_file",
    ).length;
    if (
      (Q("tengu_query_after_attachments", {
        totalToolResultsCount: q6.length,
        fileChangeAttachmentCount: V6,
        queryChainId: m,
        queryDepth: R.depth,
      }),
      O6.options.refreshTools)
    ) {
      let W6 = O6.options.refreshTools();
      if (W6 !== O6.options.tools)
        O6 = { ...O6, options: { ...O6.options, tools: W6 } };
    }
    let P6 = { ...O6, queryTracking: R },
      R6 = N + 1;
    if ($ && R6 > $)
      return (
        yield V4({ type: "max_turns_reached", maxTurns: $, turnCount: R6 }),
        { reason: "max_turns", turnCount: R6 }
      );
    (M5("query_recursive_call"),
      (J = {
        messages: [...I, ...e, ...q6],
        toolUseContext: P6,
        autoCompactTracking: g,
        turnCount: R6,
        maxOutputTokensRecoveryCount: 0,
        hasAttemptedReactiveCompact: !1,
        pendingToolUseSummary: Z6,
        maxOutputTokensOverride: void 0,
        stopHookActive: k,
        transition: { reason: "next_turn" },
      }));
  }
}
