function sT_(A) {
  let q = hf(A);
  if (!fW4()) {
    if (!GW4(q)) return !1;
    ZW4();
  }
  let K = vW4(q),
    _ = oT_(A, xgq) >= TW4(),
    z = $a6(A);
  if ((K && _) || (K && !z)) {
    let O = A[A.length - 1];
    if (O?.uuid) xgq = O.uuid;
    return !0;
  }
  return !1;
}
