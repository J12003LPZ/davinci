async function lg(A, q, K) {
  return (IW4(), { messages: A });
}
