async function KW4({
  messages: A,
  summaryRequest: q,
  appState: K,
  context: Y,
  preCompactTokenCount: _,
  cacheSafeParams: z,
}) {
  let w = A1("tengu_compact_cache_prefix", !1),
    O = a04()
      ? setInterval(() => {
          r04();
        }, 50000)
      : void 0;
  try {
    if (w)
      try {
        let j = await xf({
            promptMessages: [q],
            cacheSafeParams: z,
            canUseTool: ws9(),
            querySource: "compact",
            forkLabel: "compact",
            maxTurns: 1,
            skipCacheWrite: !0,
          }),
          J = uf(j.messages);
        if (J && MZ8(J))
          return (
            Q("tengu_compact_cache_sharing_success", {
              preCompactTokenCount: _,
              outputTokens: j.totalUsage.output_tokens,
              cacheReadInputTokens: j.totalUsage.cache_read_input_tokens,
              cacheCreationInputTokens:
                j.totalUsage.cache_creation_input_tokens,
              cacheHitRate:
                j.totalUsage.cache_read_input_tokens > 0
                  ? j.totalUsage.cache_read_input_tokens /
                    (j.totalUsage.cache_read_input_tokens +
                      j.totalUsage.cache_creation_input_tokens +
                      j.totalUsage.input_tokens)
                  : 0,
            }),
            J
          );
        (V(
          `Compact cache sharing: no text in response, falling back. Response: ${m6(J)}`,
          { level: "warn" },
        ),
          Q("tengu_compact_cache_sharing_fallback", {
            reason: "no_text_response",
            preCompactTokenCount: _,
          }));
      } catch (j) {
        ($6(j),
          Q("tengu_compact_cache_sharing_fallback", {
            reason: "error",
            preCompactTokenCount: _,
          }));
      }
    let $ = A1("tengu_compact_streaming_retry", !1),
      H = $ ? _s9 : 1;
    for (let j = 1; j <= H; j++) {
      let J = !1,
        M;
      Y.setResponseLength?.(() => 0);
      let D = (await nQ6(
          Y.options.mainLoopModel,
          Y.options.tools,
          async () => K.toolPermissionContext,
          Y.options.agentDefinitions.activeAgents,
          "compact",
        ))
          ? ij([I9, cQ6, ...Y.options.tools.filter((Z) => Z.isMcp)], "name")
          : [I9],
        W = uZ6({
          messages: YX(zs9([...Xk(A), q]), Y.options.tools),
          systemPrompt: iq([
            "You are a helpful AI assistant tasked with summarizing conversations.",
          ]),
          thinkingConfig: { type: "disabled" },
          tools: D,
          signal: Y.abortController.signal,
          options: {
            async getToolPermissionContext() {
              return Y.getAppState().toolPermissionContext;
            },
            model: Y.options.mainLoopModel,
            toolChoice: void 0,
            isNonInteractiveSession: Y.options.isNonInteractiveSession,
            hasAppendSystemPrompt: !!Y.options.appendSystemPrompt,
            maxOutputTokensOverride: Math.min(
              rS7,
              aQ6(Y.options.mainLoopModel),
            ),
            querySource: "compact",
            agents: Y.options.agentDefinitions.activeAgents,
            mcpTools: [],
            effortValue: K.effortValue,
          },
        })[Symbol.asyncIterator](),
        f = await W.next();
      while (!f.done) {
        let Z = f.value;
        if (
          !J &&
          Z.type === "stream_event" &&
          Z.event.type === "content_block_start" &&
          Z.event.content_block.type === "text"
        )
          ((J = !0), Y.setStreamMode?.("responding"));
        if (
          Z.type === "stream_event" &&
          Z.event.type === "content_block_delta" &&
          Z.event.delta.type === "text_delta"
        ) {
          let G = Z.event.delta.text.length;
          Y.setResponseLength?.((v) => v + G);
        }
        if (Z.type === "assistant") M = Z;
        f = await W.next();
      }
      if (M) return M;
      if (j < H) {
        (Q("tengu_compact_streaming_retry", {
          attempt: j,
          preCompactTokenCount: _,
          hasStartedStreaming: J,
        }),
          await ZE(Vh(j), Y.abortController.signal));
        continue;
      }
      throw (
        V(
          `Compact streaming failed after ${j} attempts. hasStartedStreaming=${J}`,
          { level: "error" },
        ),
        Q("tengu_compact_failed", {
          reason: "no_streaming_response",
          preCompactTokenCount: _,
          hasStartedStreaming: J,
          retryEnabled: $,
          attempts: j,
          promptCacheSharingEnabled: !1,
        }),
        Error(CZ6)
      );
    }
    throw Error(CZ6);
  } finally {
    clearInterval(O);
  }
}
