function SW4(A) {
  let q = A.split(`
`),
    K = PZ8 * 4,
    Y = [],
    _ = [],
    z = "",
    w = !1;
  for (let $ of q)
    if ($.startsWith("# ")) {
      let H = EW4(z, _, K);
      (Y.push(...H.lines), (w = w || H.wasTruncated), (z = $), (_ = []));
    } else _.push($);
  let O = EW4(z, _, K);
  return (
    Y.push(...O.lines),
    (w = w || O.wasTruncated),
    {
      truncatedContent: Y.join(`
`),
      wasTruncated: w,
    }
  );
}
