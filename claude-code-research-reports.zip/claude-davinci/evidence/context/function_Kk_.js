function Kk_(A) {
  if (!$a6(A)) {
    let q = A[A.length - 1];
    if (q?.uuid) L66(q.uuid);
  }
}
