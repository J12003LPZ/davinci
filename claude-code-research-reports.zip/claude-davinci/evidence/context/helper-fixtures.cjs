// Executes only verbatim extracted helper declarations, with explicit local stubs.
// No CLI import, credential access, network request, or provider observation.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const dir=__dirname;
function source(n){return fs.readFileSync(`${dir}/function_${n.replaceAll('$','DOLLAR')}.js`,'utf8')}
const ctx=vm.createContext({process:{env:{}},n6:x=>x==='1'||x==='true',bH:()=>[],io:()=>({default:64000,upperLimit:128000}),rt:(_k,v,d,u)=>({effective:v?Math.min(Number(v),u):d}),UM:()=>200000,D8:()=>({autoCompactEnabled:true}),hf:()=>0,V:()=>{},gA:()=> 'firstParty',nA:()=>false,lG:{isUsingOverage:false},aB8:()=>null,A1:()=>({}),oB8:()=>{},Q:()=>{},pW4:()=>{},xs1:()=>{throw Error('Cache edit branch should not execute')},d$_:()=>false,Vs9:20000,fR1:13000,Es9:20000,ys9:20000,ZR1:3000});
for(const n of ['ig','eQ6','IY6','Lh','Ls9','YEq','rg','u$_','B$_','g$_','c$_','Is1']) vm.runInContext(source(n),ctx);
// aQ6 is a controlled dependency; actual helper read separately in source report.
ctx.aQ6=()=>64000;
const rows=[];
function check(name,fn,want){const got=fn();assert.deepEqual(JSON.parse(JSON.stringify(got)),want);rows.push({name,observed:got});}
check('default 200k window effective and auto threshold',()=>[ctx.ig('x'),ctx.eQ6('x')],[180000,167000]);
check('threshold edge',()=>[ctx.IY6(166999,'x').isAboveAutoCompactThreshold,ctx.IY6(167000,'x').isAboveAutoCompactThreshold],[false,true]);
check('blocking edge',()=>[ctx.IY6(176999,'x').isAtBlockingLimit,ctx.IY6(177000,'x').isAtBlockingLimit],[false,true]);
ctx.process.env.CLAUDE_AUTOCOMPACT_PCT_OVERRIDE='99';check('99 percent cannot exceed reserved threshold',()=>ctx.eQ6('x'),167000);
ctx.process.env.CLAUDE_AUTOCOMPACT_PCT_OVERRIDE='50';check('50 percent threshold',()=>ctx.eQ6('x'),90000);
ctx.process.env={};ctx.process.env.CLAUDE_CODE_AUTO_COMPACT_WINDOW='100000';check('100k override',()=>[ctx.ig('x'),ctx.eQ6('x')],[80000,67000]);
ctx.process.env={};ctx.UM=()=>1000000;check('1M dependency window',()=>[ctx.ig('x'),ctx.eQ6('x')],[980000,967000]);ctx.UM=()=>200000;
check('base cache control omits ttl',()=>ctx.rg(),{type:'ephemeral'});
ctx.process.env.ENABLE_PROMPT_CACHING_1H_BEDROCK='1';ctx.gA=()=> 'bedrock';check('bedrock env bypasses subscription allowlist',()=>ctx.rg(),{type:'ephemeral',ttl:'1h'});
ctx.process.env={};ctx.gA=()=> 'firstParty';ctx.nA=()=>true;ctx.A1=()=>({allowlist:['agent:*','compact']});check('allowlisted source one hour',()=>ctx.rg({querySource:'agent:foo'}),{type:'ephemeral',ttl:'1h'});check('unallowlisted source omits ttl',()=>ctx.rg({querySource:'sdk'}),{type:'ephemeral'});ctx.lG.isUsingOverage=true;check('overage disables subscription TTL extension',()=>ctx.rg({querySource:'compact'}),{type:'ephemeral'});
ctx.nA=()=>false;ctx.lG.isUsingOverage=false;
const msg=(type,content)=>({type,message:{content}});
let messages=[msg('user','old'),msg('assistant',[{type:'text',text:'reply'}]),msg('user',[{type:'text',text:'new'}])];
check('normal marks last message last content',()=>ctx.c$_(messages,true,'sdk'),[{role:'user',content:'old'},{role:'assistant',content:[{type:'text',text:'reply'}]},{role:'user',content:[{type:'text',text:'new',cache_control:{type:'ephemeral'}}]}]);
check('skip write moves breakpoint to penultimate message',()=>ctx.c$_(messages,true,'sdk',false,undefined,undefined,true),[{role:'user',content:'old'},{role:'assistant',content:[{type:'text',text:'reply',cache_control:{type:'ephemeral'}}]},{role:'user',content:[{type:'text',text:'new'}]}]);
check('thinking last block gets no breakpoint, no backward search',()=>ctx.c$_([msg('assistant',[{type:'text',text:'reply'},{type:'thinking',thinking:'thought'}])],true,'sdk'),[{role:'assistant',content:[{type:'text',text:'reply'},{type:'thinking',thinking:'thought'}]}]);
check('disabled helper cache flag',()=>ctx.c$_([msg('user','new')],false,'sdk'),[{role:'user',content:[{type:'text',text:'new'}]}]);
ctx.R56=()=>true;ctx.MY6='__SYSTEM_PROMPT_DYNAMIC_BOUNDARY__';ctx.vH8=new Set(['identity']);ctx.A1=()=>true;
check('global static boundary excludes dynamic block from annotation',()=>ctx.Is1(['x-anthropic-billing-header: x','identity','static',ctx.MY6,'dynamic']),[{text:'x-anthropic-billing-header: x',cacheScope:null},{text:'identity',cacheScope:null},{text:'static',cacheScope:'global'},{text:'dynamic',cacheScope:null}]);
check('global skipped for tool context uses org group',()=>ctx.Is1(['identity','static',ctx.MY6,'dynamic'],{skipGlobalCacheForSystemPrompt:true}),[{text:'identity',cacheScope:'org'},{text:'static\n\ndynamic',cacheScope:'org'}]);
console.log(JSON.stringify({kind:'extracted local helper fixture',provider:'none',cases:rows.length,results:rows},null,2));
