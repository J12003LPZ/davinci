async function XW4() {
  let A = Date.now();
  while (XZ8) {
    if (Date.now() - XZ8 > Hs9) return;
    if (Date.now() - A > $s9) return;
    await new Promise((K) => setTimeout(K, 1000));
  }
}
