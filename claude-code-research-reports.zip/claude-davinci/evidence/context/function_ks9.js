function ks9(A, q, K, Y, _, z) {
  let w = DE(A),
    O = rQ6("auto", w ?? 0, A[A.length - 1]?.uuid),
    $ = cg(A);
  if ($.size > 0) O.compactMetadata.preCompactDiscoveredTools = [...$].sort();
  let { truncatedContent: H, wasTruncated: j } = SW4(q),
    J = dQ6(H, !0, _, !0);
  if (j) {
    let P = gZ6();
    J += `

Some session memory sections were truncated for length. The full session memory can be viewed at: ${P}`;
  }
  let M = [
      g8({ content: J, isCompactSummary: !0, isVisibleInTranscriptOnly: !0 }),
    ],
    X = OZ8(z),
    D = X ? [X] : [];
  return {
    boundaryMarker: _R1(O, M[M.length - 1].uuid, K),
    summaryMessages: M,
    attachments: D,
    hookResults: Y,
    messagesToKeep: K,
    preCompactTokenCount: w,
    postCompactTokenCount: FZ6(M),
    truePostCompactTokenCount: FZ6(M),
  };
}
