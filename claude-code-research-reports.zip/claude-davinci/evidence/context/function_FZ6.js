function FZ6(A) {
  let q = 0;
  for (let K of A) {
    if (K.type !== "user" && K.type !== "assistant") continue;
    if (!Array.isArray(K.message.content)) continue;
    for (let Y of K.message.content)
      if (Y.type === "text") q += N5(Y.text);
      else if (Y.type === "tool_result") q += Ps9(Y);
      else if (Y.type === "image" || Y.type === "document") q += mW4;
      else if (Y.type === "thinking") q += N5(Y.thinking);
      else if (Y.type === "redacted_thinking") q += N5(Y.data);
      else if (Y.type === "tool_use") q += N5(Y.name + m6(Y.input ?? {}));
      else q += N5(m6(Y));
  }
  return Math.ceil(q * 1.3333333333333333);
}
