function ugq() {
  if (i4()) return;
  if (!Lh()) return;
  wf4(Ak_);
}
