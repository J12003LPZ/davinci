function Jl(A) {
  let q = A === void 0 || A.startsWith("repl_main_thread") || A === "sdk";
  if ((R66(), q)) (kz.cache.clear?.(), EU6("compact"));
  (mf6(), aW4(), If8(), jl(), _74(), PR1());
}
