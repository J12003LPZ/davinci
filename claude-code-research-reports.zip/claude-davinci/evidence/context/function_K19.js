function K19(A) {
  let q = A.find((Y) => Y.type === "user");
  if (!q) return "";
  let K = q.message.content;
  if (typeof K === "string") return K;
  if (Array.isArray(K)) {
    let Y = K.find((_) => _.type === "text");
    if (Y && Y.type === "text") return Y.text;
  }
  return "";
}
