function g$_(A, q = !1, K, Y) {
  if (q)
    if (typeof A.message.content === "string")
      return {
        role: "assistant",
        content: [
          {
            type: "text",
            text: A.message.content,
            ...(K ? { cache_control: rg({ querySource: Y }) } : {}),
          },
        ],
      };
    else
      return {
        role: "assistant",
        content: A.message.content.map((_, z) => ({
          ..._,
          ...(z === A.message.content.length - 1 &&
          _.type !== "thinking" &&
          _.type !== "redacted_thinking"
            ? K
              ? { cache_control: rg({ querySource: Y }) }
              : {}
            : {}),
        })),
      };
  return { role: "assistant", content: A.message.content };
}
