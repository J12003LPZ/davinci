function qEq(A) {
  let [q] = Is1(A),
    K = q?.text;
  Q("tengu_sysprompt_block", {
    snippet: K?.slice(0, 20),
    length: K?.length ?? 0,
    hash: K ? h$_("sha256").update(K).digest("hex") : "",
  });
}
