function cc1(A) {
  if (!A) return 0;
  if (typeof A === "string") return N5(A);
  let q = 0;
  for (let K of A) q += xdY(K);
  return q;
}
