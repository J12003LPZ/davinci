function YEq(A) {
  if (n6(process.env.DISABLE_PROMPT_CACHING)) return !1;
  if (n6(process.env.DISABLE_PROMPT_CACHING_HAIKU)) {
    let q = iH();
    if (A === q) return !1;
  }
  if (n6(process.env.DISABLE_PROMPT_CACHING_SONNET)) {
    let q = aZ();
    if (A === q) return !1;
  }
  if (n6(process.env.DISABLE_PROMPT_CACHING_OPUS)) {
    let q = ZT();
    if (A === q) return !1;
  }
  return !0;
}
