async function xf({
  promptMessages: A,
  cacheSafeParams: q,
  canUseTool: K,
  querySource: Y,
  forkLabel: _,
  overrides: z,
  maxOutputTokens: w,
  maxTurns: O,
  onMessage: $,
  skipTranscript: H,
  skipCacheWrite: j,
}) {
  let J = Date.now(),
    M = [],
    X = { ...HW },
    {
      systemPrompt: D,
      userContext: P,
      systemContext: W,
      toolUseContext: f,
      forkContextMessages: Z,
    } = q,
    G = ri6(f, z),
    v = [...Z, ...A],
    k = H ? void 0 : mI(_),
    N = null;
  if (k)
    (await Fp(v, k).catch((h) =>
      V(`Forked agent [${_}] failed to record initial transcript: ${h}`),
    ),
      (N = v.length > 0 ? v[v.length - 1].uuid : null));
  try {
    for await (let h of th({
      messages: v,
      systemPrompt: D,
      userContext: P,
      systemContext: W,
      canUseTool: K,
      toolUseContext: G,
      querySource: Y,
      maxOutputTokensOverride: w,
      maxTurns: O,
      skipCacheWrite: j,
    })) {
      if (h.type === "stream_event") {
        if (
          "event" in h &&
          h.event?.type === "message_delta" &&
          h.event.usage
        ) {
          let m = J16({ ...HW }, h.event.usage);
          X = YR8(X, m);
        }
        continue;
      }
      if (h.type === "stream_request_start") continue;
      (V(`Forked agent [${_}] received message: type=${h.type}`),
        M.push(h),
        $?.(h));
      let R = h;
      if (
        k &&
        (R.type === "assistant" || R.type === "user" || R.type === "progress")
      )
        (await Fp([R], k, N).catch((m) =>
          V(`Forked agent [${_}] failed to record transcript: ${m}`),
        ),
          (N = R.uuid));
    }
  } finally {
    (G.readFileState.clear(), (v.length = 0));
  }
  V(
    `Forked agent [${_}] finished: ${M.length} messages, types=[${M.map((h) => h.type).join(", ")}], totalUsage: input=${X.input_tokens} output=${X.output_tokens} cacheRead=${X.cache_read_input_tokens} cacheCreate=${X.cache_creation_input_tokens}`,
  );
  let E = Date.now() - J;
  return (
    MgY({
      forkLabel: _,
      querySource: Y,
      durationMs: E,
      messageCount: M.length,
      totalUsage: X,
      queryTracking: f.queryTracking,
    }),
    { messages: M, totalUsage: X }
  );
}
