function io(A) {
  let q,
    K,
    Y = gY(A);
  if (Y.includes("opus-4-6")) ((q = 64000), (K = 128000));
  else if (Y.includes("sonnet-4-6")) ((q = 32000), (K = 128000));
  else if (
    Y.includes("opus-4-5") ||
    Y.includes("sonnet-4") ||
    Y.includes("haiku-4")
  )
    ((q = 32000), (K = 64000));
  else if (Y.includes("opus-4-1") || Y.includes("opus-4"))
    ((q = 32000), (K = 32000));
  else if (Y.includes("claude-3-opus")) ((q = 4096), (K = 4096));
  else if (Y.includes("claude-3-sonnet")) ((q = 8192), (K = 8192));
  else if (Y.includes("claude-3-haiku")) ((q = 4096), (K = 4096));
  else if (Y.includes("3-5-sonnet") || Y.includes("3-5-haiku"))
    ((q = 8192), (K = 8192));
  else if (Y.includes("3-7-sonnet")) ((q = 32000), (K = 64000));
  else ((q = fr3), (K = Zr3));
  let _ = IM1(A);
  if (_?.max_tokens && _.max_tokens >= 4096)
    ((K = _.max_tokens), (q = Math.min(q, K)));
  return { default: q, upperLimit: K };
}
