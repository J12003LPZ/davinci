function zYq() {
  return { callModel: uZ6, microcompact: lg, autocompact: sW4, uuid: YgY };
}
