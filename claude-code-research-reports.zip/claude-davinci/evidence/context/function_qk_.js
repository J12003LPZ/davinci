function qk_(A) {
  return async (q, K) => {
    if (
      q.name === k4 &&
      typeof K === "object" &&
      K !== null &&
      "file_path" in K
    ) {
      let Y = K.file_path;
      if (typeof Y === "string" && Y === A)
        return { behavior: "allow", updatedInput: K };
    }
    return {
      behavior: "deny",
      message: `only ${k4} on ${A} is allowed`,
      decisionReason: {
        type: "other",
        reason: `only ${k4} on ${A} is allowed`,
      },
    };
  };
}
