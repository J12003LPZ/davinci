function YR8(A, q) {
  return {
    input_tokens: A.input_tokens + q.input_tokens,
    cache_creation_input_tokens:
      A.cache_creation_input_tokens + q.cache_creation_input_tokens,
    cache_read_input_tokens:
      A.cache_read_input_tokens + q.cache_read_input_tokens,
    output_tokens: A.output_tokens + q.output_tokens,
    server_tool_use: {
      web_search_requests:
        A.server_tool_use.web_search_requests +
        q.server_tool_use.web_search_requests,
      web_fetch_requests:
        A.server_tool_use.web_fetch_requests +
        q.server_tool_use.web_fetch_requests,
    },
    service_tier: q.service_tier,
    cache_creation: {
      ephemeral_1h_input_tokens:
        A.cache_creation.ephemeral_1h_input_tokens +
        q.cache_creation.ephemeral_1h_input_tokens,
      ephemeral_5m_input_tokens:
        A.cache_creation.ephemeral_5m_input_tokens +
        q.cache_creation.ephemeral_5m_input_tokens,
    },
    ...{},
    inference_geo: q.inference_geo,
    iterations: q.iterations,
    speed: q.speed,
  };
}
