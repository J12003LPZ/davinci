async function* $Eq(A, q, K, Y, _, z) {
  if (
    !nA() &&
    (await PR("tengu-off-switch", { activated: !1 })).activated &&
    sq6(z.model)
  ) {
    (Q("tengu_off_switch_query", {}), yield Mf8(Error(TY6), z.model));
    return;
  }
  let w = F$_(A),
    O =
      gA() === "bedrock" && z.model.includes("application-inference-profile")
        ? ((await FY8(z.model)) ?? z.model)
        : z.model;
  M5("query_tool_schema_build_start");
  let $ =
      z.querySource.startsWith("repl_main_thread") ||
      z.querySource.startsWith("agent:") ||
      z.querySource === "sdk" ||
      z.querySource === "hook_agent" ||
      z.querySource === "verification_agent",
    H = Z$8(z.model, { isAgenticQuery: $ }),
    j,
    J = await nQ6(z.model, Y, z.getToolPermissionContext, z.agents, "query");
  if (J && !Y.some(uD) && !z.hasPendingMcpServers)
    (V("Tool search disabled: no deferred tools available to search"),
      (J = !1));
  let M;
  if (J) {
    let W6 = cg(A);
    M = Y.filter((T6) => {
      if (!uD(T6)) return !0;
      if (O3(T6, Sf)) return !0;
      return W6.has(T6.name);
    });
  } else M = Y.filter((W6) => !O3(W6, Sf));
  let X = J ? eS7() : null;
  if (X && gA() !== "bedrock") {
    if (!H.includes(X)) H.push(X);
  }
  let D = !1,
    P = "",
    W =
      R56() &&
      (n6(process.env.CLAUDE_CODE_FORCE_GLOBAL_CACHE) ||
        A1("tengu_system_prompt_global_cache", !1)),
    f = Y.some((W6) => W6.isMcp === !0),
    Z = M.some((W6) => O3(W6, Sf)),
    G = W && (f || Z);
  if (W && !H.includes(JS6)) H.push(JS6);
  let v = W ? (G ? "none" : "system_prompt") : "none",
    k = await Promise.all(
      M.map((W6) =>
        lR8(W6, {
          getToolPermissionContext: z.getToolPermissionContext,
          tools: Y,
          agents: z.agents,
          allowedAgentTypes: z.allowedAgentTypes,
          model: z.model,
          betas: H,
          deferLoading: J && (uD(W6) || p$_(W6)),
        }),
      ),
    );
  if (J) {
    let W6 = Y.filter(uD).length,
      T6 = M.filter(uD).length;
    V(`Dynamic tool loading: ${T6}/${W6} deferred tools included`);
  }
  (M5("query_tool_schema_build_end"),
    Q("tengu_api_before_normalize", { preNormalizedMessageCount: A.length }),
    M5("query_message_normalization_start"));
  let N = YX(A, M);
  if ((M5("query_message_normalization_end"), !J))
    N = N.map((W6) => {
      switch (W6.type) {
        case "user":
          return hs1(W6);
        case "assistant":
          return iVq(W6);
        default:
          return W6;
      }
    });
  ((N = sVq(N)),
    (N = U$_(N, yK4)),
    Q("tengu_api_after_normalize", { postNormalizedMessageCount: N.length }));
  let E = Ou7(N);
  if (J && !ir6()) {
    let W6 = Y.filter(uD).map(BU6).sort().join(`
`);
    if (W6)
      N = [
        g8({
          content: `<available-deferred-tools>
${W6}
</available-deferred-tools>`,
          isMeta: !0,
        }),
        ...N,
      ];
  }
  let h = M.some((W6) => uG4(W6.name, fk)),
    R = J && h && !gf6();
  ((q = iq(
    [
      kH8(E),
      TH8({
        isNonInteractive: z.isNonInteractiveSession,
        hasAppendSystemPrompt: z.hasAppendSystemPrompt,
      }),
      ...q,
      ...(R ? [oR8] : []),
    ].filter(Boolean),
  )),
    qEq(q));
  let m = z.enablePromptCaching ?? YEq(z.model),
    I = l$_(q, m, {
      skipGlobalCacheForSystemPrompt: G,
      querySource: z.querySource,
    }),
    g = H.length > 0,
    u = [...(z.extraToolSchemas ?? [])],
    b = [...k, ...u],
    p = Eq() && Ij() && !Vm() && cH(z.model) && !!z.fastMode,
    U = LP6(z.model, z.effortValue),
    d = zH()
      ? {
          systemPrompt: q.join(`

`),
          querySource: z.querySource,
          tools: m6(b),
        }
      : void 0,
    r = y74(z.model, d, N, p),
    t = Date.now(),
    e = Date.now(),
    q6 = 0,
    H6 = [],
    K6 = void 0,
    o = void 0,
    j6 = void 0;
  function z6() {
    if ((Q$_(K6), (K6 = void 0), j6))
      (j6.body?.cancel().catch(() => {}), (j6 = void 0));
  }
  let G6 = D ? BW4() : null,
    X6 = D ? gW4() : [],
    c,
    n = (W6) => {
      let T6 = [...H];
      if (!T6.includes(pa) && uM1(W6.model)) T6.push(pa);
      let h6 = gA() === "bedrock" ? [...BM1(W6.model), ...(X ? [X] : [])] : [],
        F6 = iR8(h6),
        U6 = { ...(F6.output_config ?? {}) };
      if ((m$_(U, U6, F6, T6, z.model), z.outputFormat && !("format" in U6))) {
        if (((U6.format = z.outputFormat), h56(z.model) && !T6.includes(Fa)))
          T6.push(Fa);
      }
      let k6 =
          W6?.maxTokensOverride || z.maxOutputTokensOverride || aQ6(z.model),
        C6 =
          K.type !== "disabled" &&
          !n6(process.env.CLAUDE_CODE_DISABLE_THINKING),
        o6 = void 0;
      if (C6 && qu7(z.model))
        if (
          !n6(process.env.CLAUDE_CODE_DISABLE_ADAPTIVE_THINKING) &&
          fH8(z.model)
        )
          o6 = { type: "adaptive" };
        else {
          let g6 = aS7(z.model);
          if (K.type === "enabled" && K.budgetTokens !== void 0)
            g6 = K.budgetTokens;
          ((g6 = Math.min(k6 - 1, g6)),
            (o6 = { budget_tokens: g6, type: "enabled" }));
        }
      let e6 = tx7({ hasThinking: C6 }),
        $8 = z.enablePromptCaching ?? YEq(W6.model),
        j8;
      if (Eq() && Ij() && !Vm() && cH(z.model) && !!W6.fastMode)
        (T6.push(cCA), (j8 = "fast"));
      if ((x$_?.isAutoModeActive() ?? !1) && R56() && $) {
        if (!T6.includes(rj6)) T6.push(rj6);
      }
      let w6 =
        D && gA() === "firstParty" && z.querySource === "repl_main_thread";
      if (w6) {
        if (!T6.includes(P))
          (T6.push(P),
            V("Cache editing beta header enabled for cached microcompact"));
      }
      let x6 = !C6 ? (z.temperatureOverride ?? 1) : void 0;
      return (
        (c = T6),
        {
          model: ym(z.model),
          messages: c$_(N, $8, z.querySource, w6, G6, X6, z.skipCacheWrite),
          system: I,
          tools: b,
          tool_choice: z.toolChoice,
          ...(g ? { betas: T6 } : {}),
          metadata: P66(),
          max_tokens: k6,
          thinking: o6,
          ...(x6 !== void 0 && { temperature: x6 }),
          ...(e6 && g && T6.includes(Dq8) ? { context_management: e6 } : {}),
          ...F6,
          ...(Object.keys(U6).length > 0 && { output_config: U6 }),
          ...(j8 !== void 0 && { speed: j8 }),
        }
      );
    };
  z.getToolPermissionContext().then((W6) => {
    let T6 = n({ model: z.model, thinkingConfig: K });
    DYq({
      model: z.model,
      messagesLength: T6.messages.length,
      temperature: z.temperatureOverride ?? 1,
      betas: g ? (T6.betas ?? []) : [],
      permissionMode: W6.mode,
      querySource: z.querySource,
      queryTracking: z.queryTracking,
      thinkingType: T6.thinking?.type ?? "disabled",
      effortValue: T6.output_config?.effort,
      fastMode: p,
      previousRequestId: w,
    });
  });
  let A6 = [],
    a = 0,
    s = void 0,
    O6 = [],
    J6 = HW,
    Z6 = 0,
    f6 = null,
    y6 = !1,
    v6,
    V6 = 0,
    P6 = void 0,
    R6 = void 0,
    I6 = p;
  try {
    let $8 = function () {
        if (o6 !== null) (clearTimeout(o6), (o6 = null));
        if (e6 !== null) (clearTimeout(e6), (e6 = null));
      },
      j8 = function () {
        if (($8(), !h6)) return;
        ((o6 = setTimeout(
          (i) => {
            (V(`Streaming idle warning: no chunks received for ${i / 1000}s`, {
              level: "warn",
            }),
              n8("warn", "cli_streaming_idle_warning"));
          },
          F6,
          F6,
        )),
          (e6 = setTimeout(() => {
            ((k6 = !0),
              (C6 = performance.now()),
              V(
                `Streaming idle timeout: no chunks received for ${U6 / 1000}s, aborting stream`,
                { level: "error" },
              ),
              n8("error", "cli_streaming_idle_timeout"),
              Q("tengu_streaming_idle_timeout", {
                model: z.model,
                request_id: o ?? "unknown",
                timeout_ms: U6,
              }),
              z6());
          }, U6)));
      };
    M5("query_client_creation_start");
    let W6 = Uf8(
        () =>
          mV({
            maxRetries: 0,
            model: z.model,
            fetchOverride: z.fetchOverride,
            source: z.querySource,
          }),
        async (i, w6, x6) => {
          ((q6 = w6),
            (I6 = x6.fastMode ?? !1),
            (e = Date.now()),
            H6.push(e),
            M5("query_client_creation_end"));
          let g6 = n(x6);
          if (
            (j78(g6, z.querySource),
            (V6 = g6.max_tokens),
            M5("query_api_request_sent"),
            !z.agentId)
          )
            bY6("api_request_sent");
          let b6 = await i.beta.messages
            .create({ ...g6, stream: !0 }, { signal: _ })
            .withResponse();
          return (
            M5("query_response_headers_received"),
            (o = b6.request_id),
            (j6 = b6.response),
            b6.data
          );
        },
        {
          model: z.model,
          fallbackModel: z.fallbackModel,
          thinkingConfig: K,
          ...(Eq() ? { fastMode: p } : !1),
          signal: _,
        },
      ),
      T6;
    do
      if (((T6 = await W6.next()), !("controller" in T6.value))) yield T6.value;
    while (!T6.done);
    ((K6 = T6.value),
      (A6.length = 0),
      (a = 0),
      (s = void 0),
      (O6.length = 0),
      (J6 = HW),
      (f6 = null));
    let h6 = n6(process.env.CLAUDE_ENABLE_STREAM_WATCHDOG),
      F6 = 45000,
      U6 = 90000,
      k6 = !1,
      C6 = null,
      o6 = null,
      e6 = null;
    (j8(), KZ8());
    try {
      let i = !0,
        w6 = null,
        x6 = 30000,
        g6 = 0,
        b6 = 0;
      for await (let J8 of K6) {
        j8();
        let f8 = Date.now();
        if (w6 !== null) {
          let w8 = f8 - w6;
          if (w8 > x6)
            (b6++,
              (g6 += w8),
              V(
                `Streaming stall detected: ${(w8 / 1000).toFixed(1)}s gap between events (stall #${b6})`,
                { level: "warn" },
              ),
              Q("tengu_streaming_stall", {
                stall_duration_ms: w8,
                stall_count: b6,
                total_stall_time_ms: g6,
                event_type: J8.type,
                model: z.model,
                request_id: o ?? "unknown",
              }));
        }
        if (((w6 = f8), i)) {
          if (
            (V("Stream started - received first chunk"),
            M5("query_first_chunk_received"),
            !z.agentId)
          )
            bY6("first_chunk");
          (x9q(), (i = !1));
        }
        switch (J8.type) {
          case "message_start": {
            ((s = J8.message),
              (a = Date.now() - e),
              (J6 = J16(J6, J8.message?.usage)));
            break;
          }
          case "content_block_start":
            switch (J8.content_block.type) {
              case "tool_use":
                O6[J8.index] = { ...J8.content_block, input: "" };
                break;
              case "server_tool_use":
                O6[J8.index] = { ...J8.content_block, input: "" };
                break;
              case "text":
                O6[J8.index] = { ...J8.content_block, text: "" };
                break;
              case "thinking":
                O6[J8.index] = {
                  ...J8.content_block,
                  thinking: "",
                  signature: "",
                };
                break;
              default:
                O6[J8.index] = { ...J8.content_block };
                break;
            }
            break;
          case "content_block_delta": {
            let w8 = O6[J8.index],
              l8 = J8.delta;
            if (!w8)
              throw (
                Q("tengu_streaming_error", {
                  error_type: "content_block_not_found_delta",
                  part_type: J8.type,
                  part_index: J8.index,
                }),
                RangeError("Content block not found")
              );
            switch (l8.type) {
              case "citations_delta":
                break;
              case "input_json_delta":
                if (w8.type !== "tool_use" && w8.type !== "server_tool_use")
                  throw (
                    Q("tengu_streaming_error", {
                      error_type: "content_block_type_mismatch_input_json",
                      expected_type: "tool_use",
                      actual_type: w8.type,
                    }),
                    Error("Content block is not a input_json block")
                  );
                if (typeof w8.input !== "string")
                  throw (
                    Q("tengu_streaming_error", {
                      error_type: "content_block_input_not_string",
                      input_type: typeof w8.input,
                    }),
                    Error("Content block input is not a string")
                  );
                w8.input += l8.partial_json;
                break;
              case "text_delta":
                if (w8.type !== "text")
                  throw (
                    Q("tengu_streaming_error", {
                      error_type: "content_block_type_mismatch_text",
                      expected_type: "text",
                      actual_type: w8.type,
                    }),
                    Error("Content block is not a text block")
                  );
                w8.text += l8.text;
                break;
              case "signature_delta":
                if (w8.type !== "thinking")
                  throw (
                    Q("tengu_streaming_error", {
                      error_type:
                        "content_block_type_mismatch_thinking_signature",
                      expected_type: "thinking",
                      actual_type: w8.type,
                    }),
                    Error("Content block is not a thinking block")
                  );
                w8.signature = l8.signature;
                break;
              case "thinking_delta":
                if (w8.type !== "thinking")
                  throw (
                    Q("tengu_streaming_error", {
                      error_type: "content_block_type_mismatch_thinking_delta",
                      expected_type: "thinking",
                      actual_type: w8.type,
                    }),
                    Error("Content block is not a thinking block")
                  );
                w8.thinking += l8.thinking;
                break;
            }
            break;
          }
          case "content_block_stop": {
            let w8 = O6[J8.index];
            if (!w8)
              throw (
                Q("tengu_streaming_error", {
                  error_type: "content_block_not_found_stop",
                  part_type: J8.type,
                  part_index: J8.index,
                }),
                RangeError("Content block not found")
              );
            if (!s)
              throw (
                Q("tengu_streaming_error", {
                  error_type: "partial_message_not_found",
                  part_type: J8.type,
                }),
                Error("Message not found")
              );
            let l8 = {
              message: { ...s, content: sI8([w8], Y, z.agentId) },
              requestId: o ?? void 0,
              type: "assistant",
              uuid: us1(),
              timestamp: new Date().toISOString(),
              ...{},
            };
            (A6.push(l8), yield l8);
            break;
          }
          case "message_delta": {
            ((J6 = J16(J6, J8.usage)), (f6 = J8.delta.stop_reason));
            let w8 = A6[A6.length - 1];
            if (w8) ((w8.message.usage = J6), (w8.message.stop_reason = f6));
            let l8 = _X6(O, J6);
            (Wb6(l8, J6, z.model), (Z6 += l8));
            let P1 = sX4(J8.delta.stop_reason, z.model);
            if (P1) yield P1;
            if (f6 === "max_tokens")
              (Q("tengu_max_tokens_reached", { max_tokens: V6 }),
                yield S9({
                  content: `${QD}: Claude's response exceeded the ${V6} output token maximum. To configure this behavior, set the CLAUDE_CODE_MAX_OUTPUT_TOKENS environment variable.`,
                  apiError: "max_output_tokens",
                  error: "max_output_tokens",
                }));
            if (f6 === "model_context_window_exceeded")
              (Q("tengu_context_window_exceeded", {
                max_tokens: V6,
                output_tokens: J6.output_tokens,
              }),
                yield S9({
                  content: `${QD}: The model has reached its context window limit.`,
                  apiError: "max_output_tokens",
                  error: "max_output_tokens",
                }));
            break;
          }
          case "message_stop":
            break;
        }
        yield {
          type: "stream_event",
          event: J8,
          ...(J8.type === "message_start" ? { ttftMs: a } : void 0),
        };
      }
      if (($8(), k6)) {
        let J8 = C6 !== null ? Math.round(performance.now() - C6) : -1;
        throw (
          n8("info", "cli_stream_loop_exited_after_watchdog_clean"),
          Q("tengu_stream_loop_exited_after_watchdog", {
            request_id: o ?? "unknown",
            exit_delay_ms: J8,
            exit_path: "clean",
            model: z.model,
          }),
          (C6 = null),
          Error("Stream idle timeout - no chunks received")
        );
      }
      if (!s || (A6.length === 0 && !f6))
        throw (
          V(
            !s
              ? "Stream completed without receiving message_start event - triggering non-streaming fallback"
              : "Stream completed with message_start but no content blocks completed - triggering non-streaming fallback",
            { level: "error" },
          ),
          Q("tengu_stream_no_events", {
            model: z.model,
            request_id: o ?? "unknown",
          }),
          Error("Stream ended without receiving any events")
        );
      if (b6 > 0)
        (V(
          `Streaming completed with ${b6} stall(s), total stall time: ${(g6 / 1000).toFixed(1)}s`,
          { level: "warn" },
        ),
          Q("tengu_streaming_stall_summary", {
            stall_count: b6,
            total_stall_time_ms: g6,
            model: z.model,
            request_id: o ?? "unknown",
          }));
      let a6 = j6;
      if (a6) (sy1(a6.headers), (P6 = a6.headers));
    } catch (i) {
      if (($8(), k6 && C6 !== null)) {
        let b6 = Math.round(performance.now() - C6);
        (n8("info", "cli_stream_loop_exited_after_watchdog_error"),
          Q("tengu_stream_loop_exited_after_watchdog", {
            request_id: o ?? "unknown",
            exit_delay_ms: b6,
            exit_path: "error",
            error_name: i instanceof Error ? i.name : "unknown",
            model: z.model,
          }));
      }
      if (i instanceof l9)
        if (_.aborted) throw (V(`Streaming aborted by user: ${r6(i)}`), i);
        else
          throw (
            V(`Streaming timeout (SDK abort): ${i.message}`, {
              level: "error",
            }),
            new Lm({ message: "Request timed out" })
          );
      if (A1("tengu_disable_streaming_to_non_streaming_fallback", !1))
        throw (
          V(`Error streaming (non-streaming fallback disabled): ${r6(i)}`, {
            level: "error",
          }),
          Q("tengu_streaming_fallback_to_non_streaming", {
            model: z.model,
            error: i instanceof Error ? i.name : String(i),
            attemptNumber: q6,
            maxOutputTokens: V6,
            thinkingType: K.type,
            fallback_disabled: !0,
            request_id: o ?? "unknown",
            fallback_cause: k6 ? "watchdog" : "other",
          }),
          i
        );
      if (
        (V(`Error streaming, falling back to non-streaming mode: ${r6(i)}`, {
          level: "error",
        }),
        (y6 = !0),
        z.onStreamingFallback)
      )
        z.onStreamingFallback();
      (Q("tengu_streaming_fallback_to_non_streaming", {
        model: z.model,
        error: i instanceof Error ? i.name : String(i),
        attemptNumber: q6,
        maxOutputTokens: V6,
        thinkingType: K.type,
        fallback_disabled: !1,
        request_id: o ?? "unknown",
        fallback_cause: k6 ? "watchdog" : "other",
      }),
        n8("info", "cli_nonstreaming_fallback_started"),
        Q("tengu_nonstreaming_fallback_started", {
          request_id: o ?? "unknown",
          model: z.model,
          fallback_cause: k6 ? "watchdog" : "other",
        }));
      let x6 = yield* zEq(
          { model: z.model, source: z.querySource },
          {
            model: z.model,
            fallbackModel: z.fallbackModel,
            thinkingConfig: K,
            ...(Eq() ? { fastMode: p } : {}),
            signal: _,
            initialConsecutive529Errors: EZ6(i) ? 1 : 0,
          },
          n,
          (b6, a6, J8) => {
            ((q6 = b6), (V6 = J8));
          },
          (b6) => j78(b6, z.querySource),
          o,
        ),
        g6 = {
          message: { ...x6, content: sI8(x6.content, Y, z.agentId) },
          requestId: o ?? void 0,
          type: "assistant",
          uuid: us1(),
          timestamp: new Date().toISOString(),
          ...{},
        };
      (A6.push(g6), (v6 = g6), yield g6);
    } finally {
      $8();
    }
  } catch (W6) {
    if (W6 instanceof yY6) throw W6;
    if (
      !y6 &&
      W6 instanceof Ug &&
      W6.originalError instanceof U7 &&
      W6.originalError.status === 404
    ) {
      let h6 = W6.originalError.requestID ?? "unknown";
      if (
        (V(
          "Streaming endpoint returned 404, falling back to non-streaming mode",
          { level: "warn" },
        ),
        (y6 = !0),
        z.onStreamingFallback)
      )
        z.onStreamingFallback();
      Q("tengu_streaming_fallback_to_non_streaming", {
        model: z.model,
        error: "404_stream_creation",
        attemptNumber: q6,
        maxOutputTokens: V6,
        thinkingType: K.type,
        request_id: h6,
        fallback_cause: "404_stream_creation",
      });
      try {
        let F6 = yield* zEq(
            { model: z.model, source: z.querySource },
            {
              model: z.model,
              fallbackModel: z.fallbackModel,
              thinkingConfig: K,
              ...(Eq() ? { fastMode: p } : {}),
              signal: _,
            },
            n,
            (k6, C6, o6) => {
              ((q6 = k6), (V6 = o6));
            },
            (k6) => j78(k6, z.querySource),
            h6,
          ),
          U6 = {
            message: { ...F6, content: sI8(F6.content, Y, z.agentId) },
            requestId: o ?? void 0,
            type: "assistant",
            uuid: us1(),
            timestamp: new Date().toISOString(),
            ...{},
          };
        (A6.push(U6), (v6 = U6), yield U6);
      } catch (F6) {
        if (F6 instanceof yY6) throw F6;
        V(`Non-streaming fallback also failed: ${r6(F6)}`, { level: "error" });
        let U6 = F6,
          k6 = z.model;
        if (F6 instanceof Ug)
          ((U6 = F6.originalError), (k6 = F6.retryContext.model));
        if (U6 instanceof U7) _f8(U6);
        let C6 =
          o ||
          (U6 instanceof U7 ? U6.requestID : void 0) ||
          (U6 instanceof U7 ? U6.error?.request_id : void 0);
        if (
          (Vd1({
            error: U6,
            model: k6,
            messageCount: N.length,
            messageTokens: DE(N),
            durationMs: Date.now() - e,
            durationMsIncludingRetries: Date.now() - t,
            attempt: q6,
            requestId: C6,
            didFallBackToNonStreaming: y6,
            queryTracking: z.queryTracking,
            querySource: z.querySource,
            llmSpan: r,
            fastMode: I6,
            previousRequestId: w,
          }),
          U6 instanceof l9)
        ) {
          z6();
          return;
        }
        (yield Mf8(U6, k6, { messages: A, messagesForAPI: N }), z6());
        return;
      }
    } else {
      V(`Error in API request: ${r6(W6)}`, { level: "error" });
      let h6 = W6,
        F6 = z.model;
      if (W6 instanceof Ug)
        ((h6 = W6.originalError), (F6 = W6.retryContext.model));
      if (h6 instanceof U7) _f8(h6);
      let U6 =
        o ||
        (h6 instanceof U7 ? h6.requestID : void 0) ||
        (h6 instanceof U7 ? h6.error?.request_id : void 0);
      if (
        (Vd1({
          error: h6,
          model: F6,
          messageCount: N.length,
          messageTokens: DE(N),
          durationMs: Date.now() - e,
          durationMsIncludingRetries: Date.now() - t,
          attempt: q6,
          requestId: U6,
          didFallBackToNonStreaming: y6,
          queryTracking: z.queryTracking,
          querySource: z.querySource,
          llmSpan: r,
          fastMode: I6,
          previousRequestId: w,
        }),
        h6 instanceof l9)
      ) {
        z6();
        return;
      }
      (yield Mf8(h6, F6, { messages: A, messagesForAPI: N }), z6());
      return;
    }
  } finally {
    if ((YZ8(), z6(), v6)) {
      let W6 = v6.message.usage;
      ((J6 = J16(HW, W6)), (f6 = v6.message.stop_reason));
      let T6 = _X6(O, W6);
      (Wb6(T6, W6, z.model), (Z6 += T6));
    }
  }
  if (
    o &&
    !Yt() &&
    (z.querySource.startsWith("repl_main_thread") || z.querySource === "sdk")
  )
    YB8(o);
  (z.getToolPermissionContext().then((W6) => {
    PYq({
      model: A6[0]?.message.model ?? s?.model ?? z.model,
      preNormalizedModel: z.model,
      usage: J6,
      start: e,
      startIncludingRetries: t,
      attempt: q6,
      messageCount: N.length,
      messageTokens: DE(N),
      requestId: o ?? null,
      stopReason: f6,
      ttftMs: a,
      didFallBackToNonStreaming: y6,
      querySource: z.querySource,
      headers: P6,
      costUSD: Z6,
      queryTracking: z.queryTracking,
      permissionMode: W6.mode,
      newMessages: A6,
      llmSpan: r,
      globalCacheStrategy: v,
      requestSetupMs: e - t,
      attemptStartTimes: H6,
      fastMode: I6,
      previousRequestId: w,
      betas: c,
    });
  }),
    z6());
}
