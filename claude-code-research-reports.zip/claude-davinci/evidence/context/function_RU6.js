function RU6(A) {
  let q = 0;
  for (let K of A) q += ic1(K);
  return q;
}
