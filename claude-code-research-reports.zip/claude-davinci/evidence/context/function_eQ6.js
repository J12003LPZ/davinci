function eQ6(A) {
  let q = ig(A),
    K = q - fR1,
    Y = process.env.CLAUDE_AUTOCOMPACT_PCT_OVERRIDE;
  if (Y) {
    let _ = parseFloat(Y);
    if (!isNaN(_) && _ > 0 && _ <= 100) {
      let z = Math.floor(q * (_ / 100));
      return Math.min(z, K);
    }
  }
  return K;
}
