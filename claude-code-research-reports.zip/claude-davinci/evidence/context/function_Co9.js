function Co9(A) {
  let q = A;
  q = q.replace(/<analysis>[\s\S]*?<\/analysis>/, "");
  let K = q.match(/<summary>([\s\S]*?)<\/summary>/);
  if (K) {
    let Y = K[1] || "";
    q = q.replace(
      /<summary>[\s\S]*?<\/summary>/,
      `Summary:
${Y.trim()}`,
    );
  }
  return (
    (q = q.replace(
      /\n\n+/g,
      `

`,
    )),
    q.trim()
  );
}
