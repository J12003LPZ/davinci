async function Of4(A, q, K, Y, _, z) {
  let w = {
    messages: A,
    systemPrompt: q,
    userContext: K,
    systemContext: Y,
    toolUseContext: _,
    querySource: z,
  };
  for (let O of zf4)
    try {
      await O(w);
    } catch ($) {
      $6($ instanceof Error ? $ : Error(`Post-sampling hook failed: ${$}`));
    }
}
