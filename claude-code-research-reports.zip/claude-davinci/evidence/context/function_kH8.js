function kH8(A) {
  if (!e89()) return "";
  let q = `${{ ISSUES_EXPLAINER: "report the issue at https://github.com/anthropics/claude-code/issues", PACKAGE_URL: "@anthropic-ai/claude-code", README_URL: "https://code.claude.com/docs/en/overview", VERSION: "2.1.80", FEEDBACK_CHANNEL: "https://github.com/anthropics/claude-code/issues", BUILD_TIME: "2026-03-19T21:00:01Z" }.VERSION}.${A}`,
    K = process.env.CLAUDE_CODE_ENTRYPOINT ?? "unknown",
    Y = " cch=00000;",
    _ = fq8(),
    z = _ ? ` cc_workload=${_};` : "",
    w = `x-anthropic-billing-header: cc_version=${q}; cc_entrypoint=${K};${Y}${z}`;
  return (V(`attribution header ${w}`), w);
}
