function rT_() {
  return A1("tengu_session_memory", !1);
}
