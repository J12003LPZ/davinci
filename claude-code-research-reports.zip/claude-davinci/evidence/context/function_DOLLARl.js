function $l(A) {
  return [
    A.boundaryMarker,
    ...A.summaryMessages,
    ...(A.messagesToKeep ?? []),
    ...A.attachments,
    ...A.hookResults,
  ];
}
