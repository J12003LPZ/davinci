function EW4(A, q, K) {
  if (!A) return { lines: q, wasTruncated: !1 };
  if (
    q.join(`
`).length <= K
  )
    return { lines: [A, ...q], wasTruncated: !1 };
  let _ = 0,
    z = [A];
  for (let w of q) {
    if (_ + w.length + 1 > K) break;
    (z.push(w), (_ += w.length + 1));
  }
  return (
    z.push(`
[... section truncated for length ...]`),
    { lines: z, wasTruncated: !0 }
  );
}
