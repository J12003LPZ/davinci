function u$_(A) {
  if (gA() === "bedrock" && n6(process.env.ENABLE_PROMPT_CACHING_1H_BEDROCK))
    return !0;
  if (!(nA() && !lG.isUsingOverage)) return !1;
  let K = aB8();
  if (K === null)
    ((K = A1("tengu_prompt_cache_1h_config", {}).allowlist ?? []), oB8(K));
  return (
    A !== void 0 &&
    K.some((Y) => (Y.endsWith("*") ? A.startsWith(Y.slice(0, -1)) : A === Y))
  );
}
