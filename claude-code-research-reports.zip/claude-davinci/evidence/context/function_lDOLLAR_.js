function l$_(A, q, K) {
  return Is1(A, {
    skipGlobalCacheForSystemPrompt: K?.skipGlobalCacheForSystemPrompt,
  }).map((Y) => {
    return {
      type: "text",
      text: Y.text,
      ...(q && Y.cacheScope !== null
        ? {
            cache_control: rg({
              scope: Y.cacheScope,
              querySource: K?.querySource,
            }),
          }
        : {}),
    };
  });
}
