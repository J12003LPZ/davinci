async function Ls9(A, q, K, Y = 0) {
  if (K === "session_memory" || K === "compact") return !1;
  if (!Lh()) return !1;
  let _ = hf(A) - Y,
    z = eQ6(q),
    w = ig(q);
  V(
    `autocompact: tokens=${_} threshold=${z} effectiveWindow=${w}${Y > 0 ? ` snipFreed=${Y}` : ""}`,
  );
  let { isAboveAutoCompactThreshold: O } = IY6(_, q);
  return O;
}
