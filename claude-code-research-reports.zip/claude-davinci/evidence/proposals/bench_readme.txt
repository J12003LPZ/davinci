### scripts/bench/README.md:1-61
1: # DaVinci versus Codex CLI benchmark
2: 
3: This harness produces **diagnostic screening evidence**. The eight legacy Python
4: tasks and four larger tasks have public generators containing their graders and
5: reference solutions. Calling those files `hidden` only describes when the local
6: grader is copied. It does not make an independent holdout.
7: 
8: Each run gets a fresh Git repository. Grading starts only after the native
9: process tree has been reaped or the named container has been removed.
10: A failed cleanup stops the campaign, retains an ungraded failed row, and never
11: copies the hidden grader into a workspace that may still have a live writer.
12: 
13: ## Boundary and credential scope
14: 
15: `BENCH_DAVINCI_GRADING_ISOLATION=container` limits host filesystem mounts to the
16: public workspace, copied campaign agent directory, and executable. The root is
17: read-only, capabilities are dropped, and no-new-privileges is set. Docker
18: containers have unique names and a CID file outside the public workspace; the
19: runner removes the actual named container on timeout and on normal exit, then
20: checks that it is absent. Daemon errors do not establish successful cleanup.
21: Every measured container and container preflight has a CID file. Missing,
22: empty, or malformed creation acknowledgment blocks grading even if an abrupt
23: client exit is followed by a transient `no such container` response: the
24: daemon could still be processing the create request.
25: 
26: Native runs use a dedicated Linux child subreaper, which kills and reaps all
27: remaining descendants after the launcher exits, including detached or
28: double-forked writers. It confirms that it has no children before reporting
29: cleanup. `/proc` must expose the supervisor's own PID namespace so the owned
30: child IDs can be used safely. If that proof is unavailable, the native arm is
31: rejected before the benchmark command starts.
32: 
33: Native Windows runs use `windows_job.py`: the command starts suspended, is
34: assigned to a new Job Object with `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`, and only
35: then resumes, so every descendant belongs to the job. After exit or timeout the
36: runner terminates the whole job and reports cleanup only when the kernel shows
37: zero active processes in it. If the orchestrator dies, the job handle closes
38: and the kernel kills the tree. Output goes to temporary files rather than pipes,
39: so a descendant holding an inherited handle cannot stall the measured exit.
40: This makes a native Windows DaVinci-versus-Codex campaign possible again.
41: macOS native arms remain unsupported. This process supervision does not add a
42: security sandbox.
43: 
44: **This is not a credential or independent hidden-grader boundary.** DaVinci and
45: its tools can read the mounted `auth.json`. Bridge networking permits outbound
46: requests, including retrieval of public fixture generators. Read-only auth
47: mounts prevent modification, not reading or exfiltration. Native Codex also has
48: host and account access. Use a dedicated benchmark account and keep campaign
49: directories and transcripts private. The copied auth file uses mode 0600 and
50: its parent uses 0700 on systems that enforce POSIX modes; these permissions do
51: not separate an agent from its tools. Credentials are excluded from structured
52: identities, but an agent can put sensitive content in a transcript.
53: 
54: Every new manifest records `promotion_eligible: false`; every arm records
55: `grading_assurance: diagnostic-only`, credential exposure, and public fixture
56: secrecy. A promotion comparison fails the independent-boundary and untouched-
57: holdout rules. An independently protected evaluation needs new private fixtures,
58: a provider credential broker outside the tool process, and an enforced network
59: policy. Those facilities are not supplied by this harness. `host` networking
60: is rejected. Codex container mode is rejected until its authentication, workspace
61: paths, and telemetry transport have a supported container configuration.
### scripts/bench/README.md:179-206
179:    executable. `BENCH_DAVINCI` is not used for that arm.
180: 2. Set `BENCH_RUNS` to a new, nonexistent output directory outside Git. Reuse is
181:    rejected. Optionally set `BENCH_CODEX`, `BENCH_MODEL` (default `gpt-6-luna`),
182:    `BENCH_EFFORT` (default `medium`), `BENCH_TIMEOUT`, and `BENCH_SERVICE_TIER`.
183: 3. Use `run --harness davinci codex --task-set legacy --reps 3 --order
184:    counterbalanced --order-seed 0 --variant B0`. This requests 48 rows. The full
185:    frozen set uses `--task-set all --large-manifest scripts/bench/large_manifest.json`
186:    and requests 72 rows at three repetitions. Each campaign saves the full
187:    schedule, fixtures, identities, effective settings, tooling preflight, lock
188:    scope, and boundary limitations before execution.
189: 4. Run `report` and `gate` with the same `BENCH_RUNS`. `report` saves separate
190:    arm, stratum, and per-task summaries. `gate` checks only completeness and
191:    pinned row consistency, retaining failures. Its successful exit is explicitly
192:    **not checkpoint acceptance**.
193: 5. Compare fresh parent and candidate campaigns offline:
194: 
195: ```sh
196: python scripts/bench/bench.py compare --baseline /absolute/parent-campaign --candidate /absolute/candidate-campaign --base-ref origin/main
197: ```
198: 
199: `compare` prints per-rule pass/fail/unavailable states and exits nonzero unless
200: all promotion rules pass. With the supplied diagnostic boundary and public
201: fixtures it cannot certify promotion. One invocation evaluates one paired window;
202: it marks two independent windows, deterministic code validation, and any missing
203: telemetry as unestablished. A parent-only DaVinci campaign is valid: its absent
204: Codex control is unavailable rather than an error or a fabricated comparison.
205: 
206: A Codemode arm sets `"codemode": {"mode": "read-only", "nodePath": ...,
### scripts/bench/README.md:264-347
264: ### Codex subscription acceptance
265: 
266: Use `--subscription-policy` with an external JSON policy containing exactly
267: `schema_version: 1`, `billing: "subscription-only"`, `model: "gpt-6-luna"`,
268: `effort: "high"`, and positive integer `max_requests`, `max_tasks`, and
269: `max_wall_seconds`. Select only the DaVinci arm, set `BENCH_EFFORT=high`, and
270: provide settings with `transport: "sse"`, `effortPolicy: "fixed"`,
271: `retry.enabled: false`, and `retry.provider.maxRetries: 0`. Policy admission
272: rejects other models, efforts, billing routes, extra fields, or excessive task
273: schedules before launching a model process.
274: 
275: `--grading-timeout` freezes a per-grader and regression-process bound between
276: 1 and 3600 seconds (default 120); select a sufficient bound for cold Rust builds
277: during `validate` and `run`. Subscription campaigns also clamp each grading
278: process to the remaining campaign wall-clock allowance.
279: 
280: No API spend authorized. Subscription-only campaign. Budget by subscription usage allowance, request count, task count, and wall-clock time; API-equivalent dollars are reporting-only.
281: 
282: This path uses existing Codex OAuth credentials and the ChatGPT-backed
283: `openai-codex-responses` route. It creates a shared durable request ledger and
284: absolute deadline, requires fresh committed receipts for every task, and stops
285: on quota exhaustion, failed transport, unknown response identity or accounting,
286: or exhausted caps. It cannot silently switch billing routes. Token usage remains
287: unknown where the provider omits it. Authorized API spending is zero; actual
288: billing is unmeasured, not a manufactured zero. Public Responses cache/output
289: limits are not assumed for the OAuth route.
290: 
291: The current adapter cannot enforce a reliable subscription allowance percentage.
292: Freeze conservative request/task/time caps instead and retain any available
293: before/after subscription-window snapshots. Those snapshots cover the account,
294: including other sessions. The current native supervisor owns and reaps the
295: process tree; it does not provide OS filesystem/network isolation or certify
296: hidden-grader secrecy. Independent acceptance remains a separate gate.
297: 
298: - **Wall time:** monotonic launch through process reaping and container cleanup.
299:   Grading/parsing are excluded. All failures/timeouts stay in distributions;
300:   paired both-successful rows are reported separately so an early failure is
301:   visible rather than silently rewarded as a speedup.
302: - **Startup state:** readiness reports retain all rows and separately summarize
303:   an optional workload-recorded `startup_state` of `cold` or `warm`. Missing or
304:   unrecognized values are `unknown`; provider cache hits and repetition order
305:   never establish process warmth. `attempt_outcomes` counts process completion,
306:   failure, timeout, abort, and unknown exit status separately from composite
307:   task success. Missing token usage stays unavailable in each group.
308: - **Task success:** integer exit zero, grader success, confirmed cleanup, no
309:   unrelated changes, no transaction leak, and no detected forbidden artifact.
310:   Missing evidence cannot pass. Cleanup and inspection failures are written as
311:   failed rows before the campaign stops.
312: - **Artifact versus transaction:** the transaction flag inspects actual
313:   `.davinci-transactions` paths. The independent artifact scan checks reserved
314:   hidden-grader names, credential files, harness artifact directories, and
315:   symlinks before grading, including Git-ignored paths. It records paths and its
316:   scan scope. False means no match in this bounded scan; it cannot establish no
317:   network retrieval, memory contamination, or concealed content leak.
318: - **Requests:** coding logical requests and actual provider attempts remain
319:   distinct; retries share logical identity. Codex user turns are not request
320:   counts. Prewarm attempts are reported separately. Unknown purpose values keep
321:   totals unavailable. Reports show available and complete row
322:   denominators; incomplete request telemetry cannot pass request-reduction rules.
323: - **Tokens:** input is normalized total input including cached input. Uncached
324:   input is computed per row as `input_tokens - cached_tokens`; missing or invalid
325:   operands remain unavailable. Cache ratio is summed cached divided by summed
326:   total input. Output includes Responses reasoning; reasoning is separately
327:   available only when reported. First/later cache ratios use deduplicated
328:   terminal usage where available.
329: - **Tools and reminders:** top-level calls, reported batch children, and actual
330:   leaf dispatches remain separate. Reminder reasons, harness verification runs,
331:   requests after the first reminder, and completion-ledger mutation generations
332:   are reported; generations are not a census of filesystem writes.
333: - **Pairs and uncertainty:** candidate divided by parent uses exact unique
334:   task/repetition pairs. Bootstrap resamples whole task clusters, retaining all
335:   repetitions together, with 2,000 deterministic resamples and a 95% percentile
336:   interval. Reports distinguish ratio of medians, median paired ratio/delta,
337:   and p90 ratio. A single task cannot establish cluster uncertainty. Twelve
338:   public task families still support a narrow diagnostic conclusion.
339: 
340: The per-window promotion report checks clean source/actual merge-base,
341: sequential execution, usable comparable tools, boundary and holdout evidence,
342: frozen legacy/large coverage, ten repetitions per task, independent windows,
343: deterministic tests, aggregate correctness, every unreviewed parent-pass/candidate-
344: fail pair, at least 10% lower median, at most 10% p90 regression, latency
345: uncertainty, logical-request and reminder-continuation reductions, and per-task
346: uncached/output token regressions. A missing rule is unavailable and blocks
347: acceptance. Aggregate gains do not erase individual correctness regressions.
