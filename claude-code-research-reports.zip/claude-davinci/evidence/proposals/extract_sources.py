"""Retain proposal-specific pinned source evidence; never execute product code."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/workspace/davinci')
OUT = Path(__file__).resolve().parent
PIN = '53e999a7fc24c721c484a710093eeeff611641bf'
SLICES = {
    'terminal_loop': ('crates/davinci-agent/src/turn.rs', [(15, 16), (272, 430), (640, 662), (714, 881), (967, 1054), (1194, 1218), (1254, 1327), (5304, 5377)]),
    'terminal_events': ('crates/davinci-agent/src/events.rs', [(5, 69), (123, 145)]),
    'terminal_host': ('crates/davinci-coding-agent/src/main.rs', [(2376, 2398), (2516, 2526), (2693, 2776), (3124, 3187), (3375, 3399), (3526, 3571), (3794, 3837), (4139, 4153), (4204, 4214), (4294, 4306), (4476, 4537)]),
    'cleanup_manager': ('crates/davinci-agent/src/runtime/worktree.rs', [(32, 60), (69, 87), (283, 399), (594, 625), (640, 708)]),
    'cleanup_callers': ('crates/davinci-agent/src/subagent.rs', [(442, 514), (1058, 1090), (1095, 1116), (1161, 1214), (1237, 1278), (1361, 1400)]),
    'teammate': ('crates/davinci-agent/src/runtime/team.rs', [(403, 478)]),
    'decoder': ('crates/davinci-ai/src/stream_decoder.rs', [(779, 887), (955, 983)]),
    'route': ('crates/davinci-ai/src/stream.rs', [(970, 1014), (1049, 1077), (1140, 1172), (1692, 1735), (2179, 2245)]),
    'subscription_policy': ('crates/davinci-ai/src/subscription_policy.rs', [(12, 77)]),
    'bench_campaign': ('scripts/bench/subscription_campaign.py', [(7, 41), (44, 93)]),
    'bench_runner': ('scripts/bench/bench.py', [(45, 53), (245, 270), (499, 550), (733, 787), (943, 969)]),
    'bench_readme': ('scripts/bench/README.md', [(1, 61), (179, 206), (264, 347)]),
}


def main():
    head = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    assert head == PIN, (head, PIN)
    status = subprocess.check_output(['git', '-C', str(ROOT), 'status', '--short'], text=True)
    index = {'pin': head, 'method': 'UTF-8 split on LF only; inclusive one-based spans', 'sources': []}
    for name, (relative, spans) in SLICES.items():
        raw = (ROOT / relative).read_bytes()
        pinned = subprocess.check_output(['git', '-C', str(ROOT), 'show', f'{PIN}:{relative}'])
        assert raw == pinned, f'working source differs from pin: {relative}'
        lines = raw.decode('utf-8').split('\n')
        for start, end in spans:
            assert 1 <= start <= end <= len(lines), (relative, start, end)
        excerpt = ''.join(f'### {relative}:{start}-{end}\n' + ''.join(f'{i+1}: {lines[i]}\n' for i in range(start-1, end)) for start, end in spans)
        (OUT / f'{name}.txt').write_text(excerpt)
        index['sources'].append({'path': relative, 'sha256': hashlib.sha256(raw).hexdigest(), 'pinned_bytes_match': True, 'spans': spans, 'excerpt': f'{name}.txt', 'excerpt_sha256': hashlib.sha256(excerpt.encode()).hexdigest()})
    (OUT / 'source_index.json').write_text(json.dumps(index, indent=2) + '\n')
    (OUT / 'inspection.json').write_text(json.dumps({'head': head, 'git_status_short': status, 'rtk': 'unavailable in PATH; raw shell used', 'tests_run': [], 'provider_calls': [], 'product_mutations': [], 'source_files_checked_against_git_objects': len(SLICES)}, indent=2) + '\n')
    print(f'{len(SLICES)} source files matched pinned Git objects; {len(status.splitlines())} source status entries; no product execution.')


if __name__ == '__main__':
    main()
