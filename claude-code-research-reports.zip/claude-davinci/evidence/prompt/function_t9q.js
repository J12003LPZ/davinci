async function* t9q(A, q, K, Y, _, z, w, O) {
  let $ = Date.now(),
    H = {
      messages: [...A, ...q],
      systemPrompt: K,
      userContext: Y,
      systemContext: _,
      toolUseContext: z,
      querySource: w,
    };
  if (w === "repl_main_thread" || w === "sdk") AYq(nE(H));
  if (process.env.CLAUDE_CODE_ENABLE_PROMPT_SUGGESTION !== "false") qYq(H);
  if (!z.agentId) {
    let j = KgY.executeExtractMemories(H, z.appendSystemMessage);
    if (z.options.isNonInteractiveSession)
      await Promise.race([j, new Promise((J) => setTimeout(J, 60000).unref())]);
  }
  if (!z.agentId) o9q(H, z.appendSystemMessage);
  try {
    let j = [],
      M = z.getAppState().toolPermissionContext.mode,
      X = fd1(
        M,
        z.abortController.signal,
        void 0,
        O ?? !1,
        z.agentId,
        z,
        [...A, ...q],
        z.agentType,
      ),
      D = "",
      P = 0,
      W = !1,
      f = "",
      Z = !1,
      G = [],
      v = [];
    for await (let k of X) {
      if (k.message) {
        if (
          (yield k.message,
          k.message.type === "progress" && k.message.toolUseID)
        ) {
          ((D = k.message.toolUseID), P++);
          let N = k.message.data;
          if (N.command)
            v.push({ command: N.command, promptText: N.promptText });
        }
        if (k.message.type === "attachment") {
          let N = k.message.attachment;
          if (
            "hookEvent" in N &&
            (N.hookEvent === "Stop" || N.hookEvent === "SubagentStop")
          ) {
            if (N.type === "hook_non_blocking_error")
              (G.push(N.stderr || `Exit code ${N.exitCode}`), (Z = !0));
            else if (N.type === "hook_error_during_execution")
              (G.push(N.content), (Z = !0));
            else if (N.type === "hook_success") {
              if (
                (N.stdout && N.stdout.trim()) ||
                (N.stderr && N.stderr.trim())
              )
                Z = !0;
            }
            if ("durationMs" in N && "command" in N) {
              let E = v.find(
                (h) => h.command === N.command && h.durationMs === void 0,
              );
              if (E) E.durationMs = N.durationMs;
            }
          }
        }
      }
      if (k.blockingError) {
        let N = g8({ content: Pd1(k.blockingError), isMeta: !0 });
        (j.push(N), yield N, (Z = !0), G.push(k.blockingError.blockingError));
      }
      if (k.preventContinuation)
        ((W = !0),
          (f = k.stopReason || "Stop hook prevented continuation"),
          yield V4({
            type: "hook_stopped_continuation",
            message: f,
            hookName: "Stop",
            toolUseID: D,
            hookEvent: "Stop",
          }));
      if (z.abortController.signal.aborted)
        return (
          Q("tengu_pre_stop_hooks_cancelled", {
            queryChainId: z.queryTracking?.chainId,
            queryDepth: z.queryTracking?.depth,
          }),
          yield pp({ toolUse: !1 }),
          { blockingErrors: [], preventContinuation: !0 }
        );
    }
    if (P > 0) {
      if ((yield KYq(P, v, G, W, f, Z, "suggestion", D), G.length > 0)) {
        let k = mD("app:toggleTranscript", "Global", "ctrl+o");
        z.addNotification?.({
          key: "stop-hook-error",
          text: `Stop hook error occurred · ${k} to see`,
          priority: "immediate",
        });
      }
    }
    if (W) return { blockingErrors: [], preventContinuation: !0 };
    if (j.length > 0) return { blockingErrors: j, preventContinuation: !1 };
    if (jY()) {
      let k = n3() ?? "",
        N = a5() ?? "",
        E = [],
        h = !1,
        R,
        m = "",
        I = FG(),
        u = (await bD(I)).filter(
          (p) => p.status === "in_progress" && p.owner === k,
        );
      for (let p of u) {
        let U = wr6(
          p.id,
          p.subject,
          p.description,
          k,
          N,
          M,
          z.abortController.signal,
          void 0,
          z,
        );
        for await (let d of U) {
          if (d.message) {
            if (d.message.type === "progress" && d.message.toolUseID)
              m = d.message.toolUseID;
            yield d.message;
          }
          if (d.blockingError) {
            let r = g8({ content: zr6(d.blockingError), isMeta: !0 });
            (E.push(r), yield r);
          }
          if (d.preventContinuation)
            ((h = !0),
              (R = d.stopReason || "TaskCompleted hook prevented continuation"),
              yield V4({
                type: "hook_stopped_continuation",
                message: R,
                hookName: "TaskCompleted",
                toolUseID: m,
                hookEvent: "TaskCompleted",
              }));
          if (z.abortController.signal.aborted)
            return { blockingErrors: [], preventContinuation: !0 };
        }
      }
      let b = Zd1(k, N, M, z.abortController.signal);
      for await (let p of b) {
        if (p.message) {
          if (p.message.type === "progress" && p.message.toolUseID)
            m = p.message.toolUseID;
          yield p.message;
        }
        if (p.blockingError) {
          let U = g8({ content: Wd1(p.blockingError), isMeta: !0 });
          (E.push(U), yield U);
        }
        if (p.preventContinuation)
          ((h = !0),
            (R = p.stopReason || "TeammateIdle hook prevented continuation"),
            yield V4({
              type: "hook_stopped_continuation",
              message: R,
              hookName: "TeammateIdle",
              toolUseID: m,
              hookEvent: "TeammateIdle",
            }));
        if (z.abortController.signal.aborted)
          return { blockingErrors: [], preventContinuation: !0 };
      }
      if (h) return { blockingErrors: [], preventContinuation: !0 };
      if (E.length > 0) return { blockingErrors: E, preventContinuation: !1 };
    }
    return { blockingErrors: [], preventContinuation: !1 };
  } catch (j) {
    let J = Date.now() - $;
    return (
      Q("tengu_stop_hook_error", {
        duration: J,
        queryChainId: z.queryTracking?.chainId,
        queryDepth: z.queryTracking?.depth,
      }),
      yield L$(`Stop hook failed: ${r6(j)}`, "warning"),
      { blockingErrors: [], preventContinuation: !1 }
    );
  }
}
