async function WQ6(A, q, K, Y) {
  let w = `Notes:
- Agent threads always have their cwd reset between bash calls, as a result please only use absolute file paths.
${A1("tengu_tight_weave", !0) ? "- In your final response, share file paths (always absolute, never relative) that are relevant to the task. Include code snippets only when the exact text is load-bearing (e.g., a bug you found, a function signature the caller asked for) — do not recap code you merely read." : "- In your final response always share relevant file names and code snippets. Any file paths you return in your response MUST be absolute. Do NOT use relative paths."}
- For clear communication with the user the assistant MUST avoid using emojis.
- Do not use a colon before tool calls. Text like "Let me read the file:" followed by a read tool call should just be "Let me read the file." with a period.`,
    O = null,
    $ = await Qi9(q, K);
  return [...A, w, ...[], $];
}
