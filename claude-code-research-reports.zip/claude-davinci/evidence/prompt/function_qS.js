function qS({
  mainThreadAgentDefinition: A,
  toolUseContext: q,
  customSystemPrompt: K,
  defaultSystemPrompt: Y,
  appendSystemPrompt: _,
  overrideSystemPrompt: z,
}) {
  if (z) return iq([z]);
  let w = A
    ? xO(A)
      ? A.getSystemPrompt({ toolUseContext: { options: q.options } })
      : A.getSystemPrompt()
    : void 0;
  if (A?.memory)
    Q("tengu_agent_memory_loaded", {
      ...{},
      scope: A.memory,
      source: "main-thread",
    });
  return iq([...(w ? [w] : K ? [K] : Y), ...(_ ? [_] : [])]);
}
