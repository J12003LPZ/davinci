async function VU6(A, q, K, Y, _) {
  return (
    await de({
      rulesDir: q,
      type: K,
      processedPaths: Y,
      includeExternal: _,
      conditionalRule: !0,
    })
  ).filter((w) => {
    if (!w.globs || w.globs.length === 0) return !1;
    let O = K === "Project" ? NU6(NU6(q)) : n1(),
      $ = VI9(A) ? NI9(O, A) : A;
    return b34.default().add(w.globs).ignores($);
  });
}
