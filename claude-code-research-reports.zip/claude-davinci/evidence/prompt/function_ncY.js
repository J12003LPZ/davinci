async function ncY(A) {
  if (!A.options.tools.some((O) => O3(O, qj))) return [];
  let q = G9(),
    K = await vh(q);
  if (Ah8) {
    Ah8 = !1;
    for (let O of K) Fk6.add(O.name);
    return [];
  }
  let Y = K.filter((O) => !Fk6.has(O.name));
  if (Y.length === 0) return [];
  let _ = Fk6.size === 0;
  for (let O of Y) Fk6.add(O.name);
  V(
    `Sending ${Y.length} skills via attachment (${_ ? "initial" : "dynamic"}, ${Fk6.size} total sent)`,
  );
  let z = UM(A.options.mainLoopModel, bH());
  return [
    {
      type: "skill_listing",
      content: Vp1(Y, z),
      skillCount: Y.length,
      isInitial: _,
    },
  ];
}
