async function WX4() {
  let A = await wN6(Z8()),
    q = Object.values(A).filter(
      (z) => z !== null && z.source === "plugin" && z.forceForPlugin === !0,
    ),
    K = q[0];
  if (K) {
    if (q.length > 1)
      V(
        `Multiple plugins have forced output styles: ${q.map((z) => z.name).join(", ")}. Using: ${K.name}`,
        { level: "warn" },
      );
    return (V(`Using forced plugin output style: ${K.name}`), K);
  }
  let _ = XA()?.outputStyle || Yv;
  return A[_] ?? null;
}
