function Zg(A, q) {
  return { name: A, compute: q, cacheBreak: !1 };
}
