async function XE(A, q, K, Y, _ = 0, z) {
  let w = aO(A);
  if (K.has(w) || _ >= II9) return [];
  if (bI9(A, q)) return [];
  let { resolvedPath: O, isSymlink: $ } = L2(O8(), A);
  if ((K.add(w), $)) K.add(aO(O));
  let H = await BV1(A, q);
  if (!H || !H.content.trim()) return [];
  if (z) H.parent = z;
  let j = [];
  j.push(H);
  let J = CI9(H.content, O);
  for (let M of J) {
    if (!u34(M) && !Y) continue;
    let D = await XE(M, q, K, Y, _ + 1, A);
    j.push(...D);
  }
  return j;
}
