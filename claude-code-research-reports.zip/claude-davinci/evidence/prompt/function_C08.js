async function C08() {
  let A = c5(),
    q = A1("tengu_swinburne_dune", !1),
    K = process.env.CLAUDE_COWORK_MEMORY_EXTRA_GUIDELINES,
    Y = K && K.trim().length > 0 ? [K] : void 0;
  if (y34.isTeamMemoryEnabled()) {
    let _ = nw(),
      z = y34.getTeamMemPath();
    if (
      (await S08(z),
      TU6(_, { memory_type: "auto" }),
      TU6(z, { memory_type: "team" }),
      A1("tengu_passport_quail", !1))
    )
      return uV1.buildExtractModeTypedCombinedPrompt(Y);
    if (q) return uV1.buildTypedCombinedMemoryPrompt(Y);
    return uV1.buildCombinedMemoryPrompt(Y);
  }
  if (A) {
    let _ = nw();
    if (
      (await S08(_),
      TU6(_, { memory_type: "auto" }),
      A1("tengu_passport_quail", !1))
    )
      return vI9("auto memory", _, Y).join(`
`);
    if (q)
      return h34("auto memory", _, Y).join(`
`);
    return TI9(Y);
  }
  if (
    (Q("tengu_memdir_disabled", {
      disabled_by_env_var: n6(process.env.CLAUDE_CODE_DISABLE_AUTO_MEMORY),
      disabled_by_setting:
        !n6(process.env.CLAUDE_CODE_DISABLE_AUTO_MEMORY) &&
        hA().autoMemoryEnabled === !1,
    }),
    A1("tengu_herring_clock", !1))
  )
    Q("tengu_team_memdir_disabled", {});
  return null;
}
