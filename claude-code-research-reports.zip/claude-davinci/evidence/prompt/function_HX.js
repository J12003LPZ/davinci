async function HX(A, q, K, Y) {
  if (n6(process.env.CLAUDE_CODE_SIMPLE))
    return [
      `You are Claude Code, Anthropic's official CLI for Claude.

CWD: ${Z8()}
Date: ${EP6()}`,
    ];
  let _ = Z8(),
    [z, w, O] = await Promise.all([vh(_), WX4(), JX4(q, K)]),
    $ = hA(),
    H = new Set(A.map((M) => M.name)),
    j = [
      Zg("memory", () => C08()),
      Zg("ant_model_override", () => Ri9()),
      Zg("env_info_simple", () => JX4(q, K)),
      Zg("language", () => hi9($.language)),
      Zg("output_style", () => Si9(w)),
      b94(
        "mcp_instructions",
        () => (gf6() ? null : Ci9(Y)),
        "MCP servers connect/disconnect between turns",
      ),
      Zg("scratchpad", () => di9()),
      Zg("frc", () => ci9(q)),
      Zg("summarize_tool_results", () => li9),
      Zg("brief", () => ii9()),
    ],
    J = await x94(j);
  return [
    Ii9(w),
    bi9(H),
    w === null || w.keepCodingInstructions === !0 ? xi9() : null,
    ui9(),
    mi9(H, z),
    Fi9(),
    pi9(),
    ...(n6(process.env.CLAUDE_CODE_FORCE_GLOBAL_CACHE) ||
    A1("tengu_system_prompt_global_cache", !1)
      ? [MY6]
      : []),
    ...J,
  ].filter((M) => M !== null);
}
