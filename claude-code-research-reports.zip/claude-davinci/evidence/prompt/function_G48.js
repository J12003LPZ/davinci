function G48() {
  return oPA() !== void 0;
}
