function VY6(A, q) {
  let K;
  switch (q) {
    case "user":
      K =
        "- Since this memory is user-scope, keep learnings general since they apply across all projects";
      break;
    case "project":
      K =
        "- Since this memory is project-scope and shared with your team via version control, tailor your memories to this project";
      break;
    case "local":
      K =
        "- Since this memory is local-scope (not checked into version control), tailor your memories to this project and machine";
      break;
  }
  let Y = kZ6(A, q);
  S08(Y);
  let _ = A1("tengu_swinburne_dune", !1) ? S34 : R34,
    z = process.env.CLAUDE_COWORK_MEMORY_EXTRA_GUIDELINES;
  return _({
    displayName: "Persistent Agent Memory",
    memoryDir: Y,
    extraGuidelines: z && z.trim().length > 0 ? [K, z] : [K],
  });
}
