function oPA() {
  return aPA(process.env.CLAUDE_COWORK_MEMORY_PATH_OVERRIDE, !1);
}
