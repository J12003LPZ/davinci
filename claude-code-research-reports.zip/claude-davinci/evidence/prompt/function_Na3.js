function Na3() {
  if (J$6()) return !0;
  let A = D8(),
    q = Q$8();
  if (A.projects?.[q]?.hasTrustDialogAccepted) return !0;
  let Y = K46(Z8());
  while (!0) {
    if (A.projects?.[Y]?.hasTrustDialogAccepted) return !0;
    let z = K46(g$8(Y, ".."));
    if (z === Y) break;
    Y = z;
  }
  return !1;
}
