async function lN_(A, q, K, Y, _, z, w, O) {
  if (
    (AX.subscribe((R) => {
      if ((Jh8(R, K), Eq()))
        K((m) => {
          let I = m.settings,
            g = I.fastMode === !0 && !I.fastModePerSessionOptIn;
          return { ...m, fastMode: g };
        });
    }),
    typeof Bun < "u")
  )
    setInterval(Bun.gc, 1000).unref();
  if ((TR1(), await _v6())) await Sh4();
  if ((pd(), O.resumeSessionAt && !O.resume)) {
    (process.stderr.write(`Error: --resume-session-at requires --resume
`),
      $K(1));
    return;
  }
  if (O.rewindFiles && !O.resume) {
    (process.stderr.write(`Error: --rewind-files requires --resume
`),
      $K(1));
    return;
  }
  if (O.rewindFiles && A) {
    (process.stderr
      .write(`Error: --rewind-files is a standalone operation and cannot be used with a prompt
`),
      $K(1));
    return;
  }
  let $ = oN_(A, O),
    H = jA.getSandboxUnavailableReason();
  if (H)
    process.stderr.write(`
⚠ Sandbox disabled: ${H}
  Commands will run WITHOUT sandboxing. Network and filesystem restrictions will NOT be enforced.

`);
  else if (jA.isSandboxingEnabled())
    try {
      await jA.initialize($.createSandboxAskCallback());
    } catch (R) {
      (process.stderr.write(`
❌ Sandbox Error: ${r6(R)}
`),
        $K(1, "other"));
      return;
    }
  if (O.outputFormat === "stream-json" && O.verbose)
    c74((R) => {
      let m = (() => {
        switch (R.type) {
          case "started":
            return {
              type: "system",
              subtype: "hook_started",
              hook_id: R.hookId,
              hook_name: R.hookName,
              hook_event: R.hookEvent,
              uuid: mX(),
              session_id: y8(),
            };
          case "progress":
            return {
              type: "system",
              subtype: "hook_progress",
              hook_id: R.hookId,
              hook_name: R.hookName,
              hook_event: R.hookEvent,
              stdout: R.stdout,
              stderr: R.stderr,
              output: R.output,
              uuid: mX(),
              session_id: y8(),
            };
          case "response":
            return {
              type: "system",
              subtype: "hook_response",
              hook_id: R.hookId,
              hook_name: R.hookName,
              hook_event: R.hookEvent,
              output: R.output,
              stdout: R.stdout,
              stderr: R.stderr,
              exit_code: R.exitCode,
              outcome: R.outcome,
              uuid: mX(),
              session_id: y8(),
            };
        }
      })();
      $.write(m);
    });
  if (O.setupTrigger) await wZ8(O.setupTrigger);
  let j = q(),
    {
      messages: J,
      turnInterruptionState: M,
      agentSetting: X,
    } = await aN_(K, {
      continue: O.continue,
      teleport: O.teleport,
      resume: O.resume,
      resumeSessionAt: O.resumeSessionAt,
      forkSession: O.forkSession,
      outputFormat: O.outputFormat,
      sessionStartHooksPromise: O.sessionStartHooksPromise,
    });
  if (!O.agent && !YU() && X) {
    let { agentDefinition: R } = x26(X, void 0, {
      activeAgents: w,
      allAgents: w,
    });
    if (R) {
      if (
        (K((m) => ({ ...m, agent: R.agentType })), !O.systemPrompt && !xO(R))
      ) {
        let m = R.getSystemPrompt();
        if (m) O.systemPrompt = m;
      }
      Uo6(R.agentType);
    }
  }
  if (J.length === 0 && process.exitCode !== void 0) return;
  if (O.rewindFiles) {
    let R = J.find((g) => g.uuid === O.rewindFiles);
    if (!R || R.type !== "user") {
      (process.stderr
        .write(`Error: --rewind-files requires a user message UUID, but ${O.rewindFiles} is not a user message in this session
`),
        $K(1));
      return;
    }
    let m = q(),
      I = await KUq(O.rewindFiles, m, K, !1);
    if (!I.canRewind) {
      (process.stderr.write(`Error: ${I.error || "Unexpected error"}
`),
        $K(1));
      return;
    }
    (process.stdout.write(`Files rewound to state at message ${O.rewindFiles}
`),
      $K(0));
    return;
  }
  let D =
      typeof O.resume === "string" &&
      (Boolean(aV(O.resume)) || O.resume.endsWith(".jsonl")),
    P = Boolean(O.sdkUrl);
  if (!A && !D && !P) {
    (process.stderr
      .write(`Error: Input must be provided either through stdin or as a prompt argument when using --print
`),
      $K(1));
    return;
  }
  if (O.outputFormat === "stream-json" && !O.verbose) {
    (process.stderr
      .write(`Error: When using --print, --output-format=stream-json requires --verbose
`),
      $K(1));
    return;
  }
  let W = $r6(j.mcp.tools, j.toolPermissionContext),
    f = [..._, ...W],
    Z = O.sdkUrl ? "stdio" : O.permissionPromptToolName,
    v = qUq(
      Z,
      $,
      () => q().mcp.tools,
      () => {
        vV6("requires_action");
      },
    );
  if (O.permissionPromptToolName)
    f = f.filter((R) => !O3(R, O.permissionPromptToolName));
  (e4A(), await zz7());
  let k = O.outputFormat === "json" && O.verbose,
    N = [],
    E,
    h = null;
  for await (let R of iN_(
    $,
    j.mcp.clients,
    [...Y, ...j.mcp.commands],
    f,
    J,
    v,
    z,
    q,
    K,
    w,
    O,
    M,
  )) {
    if (h) {
      let m = h(R);
      if (m) await $.write(m);
    } else if (O.outputFormat === "stream-json" && O.verbose) await $.write(R);
    if (
      R.type !== "control_response" &&
      R.type !== "control_request" &&
      R.type !== "control_cancel_request" &&
      R.type !== "stream_event" &&
      R.type !== "keep_alive" &&
      R.type !== "streamlined_text" &&
      R.type !== "streamlined_tool_use_summary" &&
      R.type !== "prompt_suggestion"
    ) {
      if (k) N.push(R);
      E = R;
    }
  }
  switch (O.outputFormat) {
    case "json":
      if (!E || E.type !== "result") throw Error("No messages returned");
      if (O.verbose) {
        v4(
          m6(N) +
            `
`,
        );
        break;
      }
      v4(
        m6(E) +
          `
`,
      );
      break;
    case "stream-json":
      break;
    default:
      if (!E || E.type !== "result") throw Error("No messages returned");
      switch (E.subtype) {
        case "success":
          v4(
            E.result.endsWith(`
`)
              ? E.result
              : E.result +
                  `
`,
          );
          break;
        case "error_during_execution":
          v4("Execution error");
          break;
        case "error_max_turns":
          v4(`Error: Reached max turns (${O.maxTurns})`);
          break;
        case "error_max_budget_usd":
          v4(`Error: Exceeded USD budget (${O.maxBudgetUsd})`);
          break;
        case "error_max_structured_output_retries":
          v4(
            "Error: Failed to provide valid structured output after maximum retries",
          );
      }
  }
  (kR1(), $K(E?.type === "result" && E?.is_error ? 1 : 0));
}
