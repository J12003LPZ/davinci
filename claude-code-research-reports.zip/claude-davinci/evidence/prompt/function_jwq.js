async function jwq(A, q, K) {
  let Y = [];
  try {
    if (!Kb(A, K.toolPermissionContext)) return Y;
    let _ = new Set(),
      z = n1(),
      w = await UV1(A, _);
    Y.push(...Al1(w, q, A));
    let { nestedDirs: O, cwdLevelDirs: $ } = bcY(A, z),
      H = A1("tengu_paper_halyard", !1);
    for (let j of O) {
      let J = (await QV1(j, A, _)).filter(
        (M) => !H || (M.type !== "Project" && M.type !== "Local"),
      );
      Y.push(...Al1(J, q, A));
    }
    for (let j of $) {
      let J = (await dV1(j, A, _)).filter(
        (M) => !H || (M.type !== "Project" && M.type !== "Local"),
      );
      Y.push(...Al1(J, q, A));
    }
  } catch (_) {
    $6(_);
  }
  return Y;
}
