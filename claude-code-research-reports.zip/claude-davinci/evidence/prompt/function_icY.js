async function icY(A) {
  let q = [];
  if (A.dynamicSkillDirTriggers && A.dynamicSkillDirTriggers.size > 0) {
    let K = await Promise.all(
      Array.from(A.dynamicSkillDirTriggers).map(async (Y) => {
        try {
          let z = (await Owq(Y, { withFileTypes: !0 }))
              .filter((O) => O.isDirectory() || O.isSymbolicLink())
              .map((O) => O.name),
            w = await Promise.all(
              z.map(async (O) => {
                try {
                  return (await $wq(Hwq(Y, O, "SKILL.md")), O);
                } catch {
                  return null;
                }
              }),
            );
          return { skillDir: Y, skillNames: w.filter((O) => O !== null) };
        } catch {
          return { skillDir: Y, skillNames: [] };
        }
      }),
    );
    for (let { skillDir: Y, skillNames: _ } of K)
      if (_.length > 0)
        q.push({
          type: "dynamic_skill",
          skillDir: Y,
          skillNames: _,
          displayPath: pi(Z8(), Y),
        });
    A.dynamicSkillDirTriggers.clear();
  }
  return q;
}
