function pR1({ tools: A, isBuiltIn: q, isAsync: K = !1, permissionMode: Y }) {
  return A.filter((_) => {
    if (_.name.startsWith("mcp__")) return !0;
    if (O3(_, xD) && Y === "plan") return !0;
    if (xf6.has(_.name)) return !1;
    if (!q && ME1.has(_.name)) return !1;
    if (K && !a08.has(_.name)) {
      if (S7() && vD()) {
        if (O3(_, Aq)) return !0;
        if (L94.has(_.name)) return !0;
      }
      return !1;
    }
    return !0;
  });
}
