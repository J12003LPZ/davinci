async function QV1(A, q, K) {
  let Y = [];
  if (gH("projectSettings")) {
    let w = ME(A, "CLAUDE.md");
    Y.push(...(await XE(w, "Project", K, !1)));
    let O = ME(A, ".claude", "CLAUDE.md");
    Y.push(...(await XE(O, "Project", K, !1)));
  }
  if (gH("localSettings")) {
    let w = ME(A, "CLAUDE.local.md");
    Y.push(...(await XE(w, "Local", K, !1)));
  }
  let _ = ME(A, ".claude", "rules"),
    z = new Set(K);
  (Y.push(
    ...(await de({
      rulesDir: _,
      type: "Project",
      processedPaths: z,
      includeExternal: !1,
      conditionalRule: !1,
    })),
  ),
    Y.push(...(await VU6(q, _, "Project", K, !1))));
  for (let w of z) K.add(w);
  return Y;
}
