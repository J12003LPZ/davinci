function Szq(A, q, K, Y, _) {
  try {
    let { name: z, description: w } = K;
    if (!z || typeof z !== "string") return null;
    if (!w || typeof w !== "string")
      return (
        V(`Agent file ${A} is missing required 'description' in frontmatter`),
        null
      );
    w = w.replace(
      /\\n/g,
      `
`,
    );
    let { color: O, model: $ } = K,
      H;
    if (typeof $ === "string" && $.trim().length > 0) {
      let r = $.trim();
      H = r.toLowerCase() === "inherit" ? "inherit" : r;
    }
    let j = K.background;
    if (j !== void 0 && j !== "true" && j !== "false" && j !== !0 && j !== !1)
      V(
        `Agent file ${A} has invalid background value '${j}'. Must be 'true', 'false', or omitted.`,
      );
    let J = j === "true" || j === !0 ? !0 : void 0,
      M = ["user", "project", "local"],
      X = K.memory,
      D;
    if (X !== void 0)
      if (M.includes(X)) D = X;
      else
        V(
          `Agent file ${A} has invalid memory value '${X}'. Valid options: ${M.join(", ")}`,
        );
    let P = ["worktree"],
      W = K.isolation,
      f;
    if (W !== void 0)
      if (P.includes(W)) f = W;
      else
        V(
          `Agent file ${A} has invalid isolation value '${W}'. Valid options: ${P.join(", ")}`,
        );
    let Z = K.effort,
      G = Z !== void 0 ? nV(Z) : void 0;
    if (Z !== void 0 && G === void 0)
      V(
        `Agent file ${A} has invalid effort '${Z}'. Valid options: ${gT.join(", ")} or an integer`,
      );
    let v = K.permissionMode,
      k = v && mW.includes(v);
    if (v && !k) {
      let r = `Agent file ${A} has invalid permissionMode '${v}'. Valid options: ${mW.join(", ")}`;
      V(r);
    }
    let N = K.maxTurns,
      E = fj8(N);
    if (N !== void 0 && E === void 0)
      V(
        `Agent file ${A} has invalid maxTurns '${N}'. Must be a positive integer.`,
      );
    let h = OdY(A, ".md"),
      R = v16(K.tools);
    if (c5() && D && R !== void 0) {
      let r = new Set(R);
      for (let t of [YK, k4, e7]) if (!r.has(t)) R = [...R, t];
    }
    let m = K.disallowedTools,
      I = m !== void 0 ? v16(m) : void 0,
      g = Dx(K.skills),
      u = K.mcpServers,
      b;
    if (Array.isArray(u))
      b = u
        .map((r) => {
          let t = Lzq().safeParse(r);
          if (t.success) return t.data;
          return (
            V(
              `Agent file ${A} has invalid mcpServers item: ${m6(r)}. Error: ${t.error.message}`,
            ),
            null
          );
        })
        .filter((r) => r !== null);
    let p = jdY(K, z),
      U = Y.trim();
    return {
      baseDir: q,
      agentType: z,
      whenToUse: w,
      ...(R !== void 0 ? { tools: R } : {}),
      ...(I !== void 0 ? { disallowedTools: I } : {}),
      ...(g !== void 0 ? { skills: g } : {}),
      ...(b !== void 0 && b.length > 0 ? { mcpServers: b } : {}),
      ...(p !== void 0 ? { hooks: p } : {}),
      getSystemPrompt: () => {
        if (c5() && D) {
          let r = VY6(z, D);
          return (
            U +
            `

` +
            r
          );
        }
        return U;
      },
      source: _,
      filename: h,
      ...(O && typeof O === "string" && JH.includes(O) ? { color: O } : {}),
      ...(H !== void 0 ? { model: H } : {}),
      ...(G !== void 0 ? { effort: G } : {}),
      ...(k ? { permissionMode: v } : {}),
      ...(E !== void 0 ? { maxTurns: E } : {}),
      ...(J ? { background: J } : {}),
      ...(D ? { memory: D } : {}),
      ...(f ? { isolation: f } : {}),
    };
  } catch (z) {
    let w = z instanceof Error ? z.message : String(z);
    return (V(`Error parsing agent from ${A}: ${w}`), $6(z), null);
  }
}
