function Al1(A, q, K) {
  let Y = [],
    _ = yU6();
  for (let z of A)
    if (!q.readFileState.has(z.path)) {
      if (
        (Y.push({
          type: "nested_memory",
          path: z.path,
          content: z,
          displayPath: pi(Z8(), z.path),
        }),
        q.readFileState.set(z.path, {
          content: z.contentDiffersFromDisk
            ? (z.rawContent ?? z.content)
            : z.content,
          timestamp: Date.now(),
          offset: void 0,
          limit: void 0,
          isPartialView: z.contentDiffersFromDisk,
        }),
        _ && xcY(z.type))
      ) {
        let w = z.globs
          ? "path_glob_match"
          : z.parent
            ? "include"
            : "nested_traversal";
        LU6(z.path, z.type, w, {
          globs: z.globs,
          triggerFilePath: K,
          parentFilePath: z.parent,
        });
      }
    }
  return Y;
}
