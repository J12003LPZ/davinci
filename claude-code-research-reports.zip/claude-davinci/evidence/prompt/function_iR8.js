function iR8(A) {
  let q = process.env.CLAUDE_CODE_EXTRA_BODY,
    K = {};
  if (q)
    try {
      let Y = ZK(q);
      if (Y && typeof Y === "object" && !Array.isArray(Y)) K = { ...Y };
      else
        V(
          `CLAUDE_CODE_EXTRA_BODY env var must be a JSON object, but was given ${q}`,
          { level: "error" },
        );
    } catch (Y) {
      V(`Error parsing CLAUDE_CODE_EXTRA_BODY: ${r6(Y)}`, { level: "error" });
    }
  if (A && A.length > 0)
    if (K.anthropic_beta && Array.isArray(K.anthropic_beta)) {
      let Y = K.anthropic_beta,
        _ = A.filter((z) => !Y.includes(z));
      K.anthropic_beta = [...Y, ..._];
    } else K.anthropic_beta = A;
  return K;
}
