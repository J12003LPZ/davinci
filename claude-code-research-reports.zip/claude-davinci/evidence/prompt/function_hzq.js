function hzq(A, q, K = "flagSettings") {
  try {
    let Y = Rzq().parse(q),
      _ = v16(Y.tools);
    if (c5() && Y.memory && _ !== void 0) {
      let $ = new Set(_);
      for (let H of [YK, k4, e7]) if (!$.has(H)) _ = [..._, H];
    }
    let z = Y.disallowedTools !== void 0 ? v16(Y.disallowedTools) : void 0,
      w = Y.prompt;
    return {
      agentType: A,
      whenToUse: Y.description,
      ...(_ !== void 0 ? { tools: _ } : {}),
      ...(z !== void 0 ? { disallowedTools: z } : {}),
      getSystemPrompt: () => {
        if (c5() && Y.memory)
          return (
            w +
            `

` +
            VY6(A, Y.memory)
          );
        return w;
      },
      source: K,
      ...(Y.model ? { model: Y.model } : {}),
      ...(Y.effort !== void 0 ? { effort: Y.effort } : {}),
      ...(Y.permissionMode ? { permissionMode: Y.permissionMode } : {}),
      ...(Y.mcpServers && Y.mcpServers.length > 0
        ? { mcpServers: Y.mcpServers }
        : {}),
      ...(Y.hooks ? { hooks: Y.hooks } : {}),
      ...(Y.maxTurns !== void 0 ? { maxTurns: Y.maxTurns } : {}),
      ...(Y.skills && Y.skills.length > 0 ? { skills: Y.skills } : {}),
      ...(Y.background ? { background: Y.background } : {}),
      ...(Y.memory ? { memory: Y.memory } : {}),
      ...(Y.isolation ? { isolation: Y.isolation } : {}),
    };
  } catch (Y) {
    let _ = Y instanceof Error ? Y.message : String(Y);
    return (V(`Error parsing agent '${A}' from JSON: ${_}`), $6(Y), null);
  }
}
