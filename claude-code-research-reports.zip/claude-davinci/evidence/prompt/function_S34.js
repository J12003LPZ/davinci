function S34(A) {
  let { displayName: q, memoryDir: K, extraGuidelines: Y } = A,
    _ = O8(),
    z = K + I_,
    w = "";
  try {
    w = _.readFileSync(z, { encoding: "utf-8" });
  } catch {}
  let O = h34(q, K, Y);
  if (w.trim()) {
    let $ = w.trim().split(`
`),
      H = $.length > HH,
      j = q === L34 ? "auto" : "agent";
    TU6(K, {
      content_length: w.length,
      line_count: $.length,
      was_truncated: H,
      memory_type: j,
    });
    let J = w.trim();
    if (H)
      J =
        $.slice(0, HH).join(`
`) +
        `

> WARNING: ${I_} is ${$.length} lines (limit: ${HH}). Only the first ${HH} lines were loaded. Move detailed content into separate topic files and keep ${I_} as a concise index.`;
    O.push(`## ${I_}`, "", J);
  } else
    O.push(
      `## ${I_}`,
      "",
      `Your ${I_} is currently empty. When you save new memories, they will appear here.`,
    );
  return O.join(`
`);
}
