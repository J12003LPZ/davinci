function MX4(A) {
  let q = gY(A);
  if (q.includes("claude-sonnet-4-6")) return "August 2025";
  else if (q.includes("claude-opus-4-6")) return "May 2025";
  else if (q.includes("claude-opus-4-5")) return "May 2025";
  else if (q.includes("claude-haiku-4")) return "February 2025";
  else if (q.includes("claude-opus-4") || q.includes("claude-sonnet-4"))
    return "January 2025";
  return null;
}
