async function FcY(A) {
  if (
    !A.nestedMemoryAttachmentTriggers ||
    A.nestedMemoryAttachmentTriggers.size === 0
  )
    return [];
  let q = A.getAppState(),
    K = [];
  for (let Y of A.nestedMemoryAttachmentTriggers) {
    let _ = await jwq(Y, A, q);
    K.push(..._);
  }
  return (A.nestedMemoryAttachmentTriggers.clear(), K);
}
