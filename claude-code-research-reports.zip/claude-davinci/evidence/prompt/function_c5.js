function c5() {
  let A = process.env.CLAUDE_CODE_DISABLE_AUTO_MEMORY;
  if (n6(A)) return !1;
  if (B_(A)) return !0;
  if (
    n6(process.env.CLAUDE_CODE_REMOTE) &&
    !process.env.CLAUDE_CODE_REMOTE_MEMORY_DIR
  )
    return !1;
  let q = hA();
  if (q.autoMemoryEnabled !== void 0) return q.autoMemoryEnabled;
  return !0;
}
