function Vp1(A, q) {
  if (A.length === 0) return "";
  let K = aE8(q),
    Y = A.map((X) => ({ cmd: X, full: lyY(X) }));
  if (Y.reduce((X, D) => X + D.full.length, 0) + (Y.length - 1) <= K)
    return Y.map((X) => X.full).join(`
`);
  let z = new Set(),
    w = [];
  for (let X = 0; X < A.length; X++) {
    let D = A[X];
    if (D.type === "prompt" && D.source === "bundled") z.add(X);
    else w.push(D);
  }
  let O = Y.reduce((X, D, P) => (z.has(P) ? X + D.full.length + 1 : X), 0),
    $ = K - O;
  if (w.length === 0)
    return Y.map((X) => X.full).join(`
`);
  let H = w.reduce((X, D) => X + D.name.length + 4, 0) + (w.length - 1),
    j = $ - H,
    J = Math.floor(j / w.length);
  if (J < iyY)
    return A.map((X, D) => (z.has(D) ? Y[D].full : `- ${X.name}`)).join(`
`);
  let M = w.filter((X) => Np1(X).length > J).length;
  return A.map((X, D) => {
    if (z.has(D)) return Y[D].full;
    let P = Np1(X),
      W = P.length > J ? P.slice(0, J - 1) + "…" : P;
    return `- ${X.name}: ${W}`;
  }).join(`
`);
}
