import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path('/workspace/research/claude-davinci')
OUT = ROOT / 'evidence/prompt'
SRC = ROOT / 'artifacts/claude-2.1.80'
pretty = (SRC / 'cli.pretty.js').read_text()
raw = (SRC / 'cli.js').read_bytes()
lines = pretty.split('\n')  # Deliberately LF-only: literals contain Unicode separators.
names = ['HX','qS','Zg','b94','x94','iq','MYq','qR8','TH8','kH8','R56','Is1','l$_','YEq','rg','u$_','lR8','iR8','c$_','B$_','g$_','Ii9','bi9','xi9','ui9','mi9','Bi9','Fi9','pi9','JX4','Qi9','MX4','WQ6','WX4','C08','c5','MB','gH','XE','B34','CI9','bI9','de','QV1','VU6','UV1','cV1','Ef6','jwq','Al1','LcY','Q5','Ov','Vp1','aE8','oyY','DE8','fEY','t9q','d_','Na3','xBq','XT_','ai9','hcY','HZ8','$Eq','zgY','kk','m4Y','XcY','ncY','FcY','icY','XEY','Ds4','G48','oPA','ak','hzq','Szq','VY6','Z$8','trY','erY','sV_','yr6','Dl','pR1','R34','S34','Xf4','szq','lN_','iN_','mFq']
items = []
for name in names:
    m = re.search(r'^(?:async )?function\*? '+re.escape(name)+r'\(', pretty, re.M)
    if not m:
        continue
    start = pretty[:m.start()].count('\n') + 1
    end = start
    while lines[end-1] != '}':
        end += 1
    candidates = [('function'+('*' if 'function*' in m.group() else '')+sep+name+'(').encode() for sep in [' ', '']]
    needle = next(n for n in candidates if raw.count(n) == 1)
    assert raw.count(needle) == 1, (name, needle)
    items.append({'identifier':name,'pretty_line_start':start,'pretty_line_end':end,'raw_byte_offset':raw.find(needle),'raw_needle':needle.decode(),'raw_needle_occurrences':1})
    (OUT / ('function_'+name.replace('$','DOLLAR')+'.js')).write_text('\n'.join(lines[start-1:end])+'\n')

windows = [
 ('context_callbacks',263527,263637,b'nV1=_1(async()=>'),
 ('memory_loader',263204,263517,b'hO=_1(async(A=!1)=>'),
 ('skill_prompt',413798,413830,b'oE8=_1(async(A)=>'),
 ('skill_tool',414100,414340,b'n86={name:qj,'),
 ('sdk_prompt',606648,606785,b'class uFq{'),
 ('cli_prompt_flags',612845,612882,b'--system-prompt-file <file>'),
 ('cli_prompt_read',613175,613242,b'let y6=O.systemPrompt;'),
 ('main_prompt',590749,590790,b'let HO=qS('),
 ('fork_prompt',413055,413165,b'if(k){if(j.renderedSystemPrompt)'),
 ('attachment_expansion',544126,544255,b'case"nested_memory":return Q5('),
 ('trust_prefetch',612475,612489,b'prefetch_system_context_has_trust'),
 ('trust_cli_help',612711,612727,b'The workspace trust dialog is skipped'),
 ('external_include_accept',477680,477710,b'hasClaudeMdExternalIncludesApproved:!0'),
 ('stop_transition',450680,450775,b'reason:"stop_hook_prevented"'),
 ('model_call',450413,450423,b'let d=iq(MYq(K,_))'),
 ('skill_discovery',537305,537350,b'vh=_1(async(A)=>'),
 ('headless_agent',613487,613525,b'if(f6&&D4&&!y6&&!xO(D4))'),
 ('headless_dispatch',613853,613887,b'let{runHeadless:S4}='),
 ('headless_submit',608260,608300,b'for await(let o6 of mFq('),
 ('sdk_factory',607245,607308,b'async function*mFq('),
 ('read_skill_triggers',465049,465082,b'let P=await QT6([X],D);'),
]
for label,start,end,needle in windows:
    count = raw.count(needle)
    if count != 1:
        # Retain an auditable error rather than silently invent an anchor.
        raise ValueError((label,needle,count))
    items.append({'identifier':label+' (descriptive excerpt label)','pretty_line_start':start,'pretty_line_end':end,'raw_byte_offset':raw.find(needle),'raw_needle':needle.decode(),'raw_needle_occurrences':count})
    (OUT / ('lines_'+label+'.txt')).write_text('\n'.join(f'{i+1}: {lines[i]}' for i in range(start-1,end))+'\n')

(OUT/'source_index.json').write_text(json.dumps({'raw':str(SRC/'cli.js'),'raw_sha256':hashlib.sha256(raw).hexdigest(),'pretty':str(SRC/'cli.pretty.js'),'pretty_sha256':hashlib.sha256((SRC/'cli.pretty.js').read_bytes()).hexdigest(),'line_basis':'LF only; split(\\n)','locations':items},indent=2)+'\n')
print(json.dumps({'locations':len(items),'index':str(OUT/'source_index.json')}))
