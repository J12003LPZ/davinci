function B34(A, q, K) {
  let Y = yI9(q).toLowerCase();
  if (Y && !RI9.has(Y))
    return (V(`Skipping non-text file in @include: ${q}`), null);
  let { content: _, paths: z } = hI9(A),
    { content: w } = m34(_),
    O = w;
  if (K === "AutoMem" || K === "TeamMem") {
    let H = w.trimEnd().split(`
`);
    if (H.length > HH)
      O =
        H.slice(0, HH).join(`
`) +
        `

> WARNING: MEMORY.md is ${H.length} lines (limit: ${HH}). Only the first ${HH} lines were loaded. Move detailed content into separate topic files and keep MEMORY.md as a concise index.`;
  }
  let $ = O !== A;
  return {
    path: q,
    type: K,
    content: O,
    globs: z,
    contentDiffersFromDisk: $,
    rawContent: $ ? A : void 0,
  };
}
