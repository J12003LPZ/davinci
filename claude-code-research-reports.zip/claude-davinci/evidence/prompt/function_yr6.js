function yr6(A, q, K, Y, _, z, w = { isSkillMode: !1 }) {
  try {
    let { frontmatter: O, content: $ } = q,
      H = yR(O.description, A),
      j = H ?? Li($, z ? "Plugin skill" : "Plugin command"),
      J = O["allowed-tools"],
      M =
        typeof J === "string"
          ? Kh(J, { path: _, source: K })
          : Array.isArray(J)
            ? J.map((R) =>
                typeof R === "string" ? Kh(R, { path: _, source: K }) : R,
              )
            : J,
      X = Dx(M),
      D = O["argument-hint"],
      P = Nn6(O.arguments),
      W = O.when_to_use,
      f = O.version,
      Z = O.name,
      G = O.model === "inherit" ? void 0 : O.model ? v5(O.model) : void 0,
      v = O.effort,
      k = v !== void 0 ? nV(v) : void 0;
    if (v !== void 0 && k === void 0)
      V(
        `Plugin command ${A} has invalid effort '${v}'. Valid options: ${gT.join(", ")} or an integer`,
      );
    let N = Rt(O["disable-model-invocation"]),
      E = O["user-invocable"],
      h = E === void 0 ? !0 : Rt(E);
    return {
      type: "prompt",
      name: A,
      description: j,
      hasUserSpecifiedDescription: H !== null,
      allowedTools: X,
      argumentHint: D,
      argNames: P.length > 0 ? P : void 0,
      whenToUse: W,
      version: f,
      model: G,
      effort: k,
      disableModelInvocation: N,
      userInvocable: h,
      contentLength: $.length,
      source: "plugin",
      loadedFrom: z || w.isSkillMode ? "plugin" : void 0,
      pluginInfo: { pluginManifest: Y, repository: K },
      isEnabled: () => !0,
      isHidden: !h,
      progressMessage: z || w.isSkillMode ? "loading" : "running",
      userFacingName() {
        return Z || A;
      },
      async getPromptForCommand(R, m) {
        let I = w.isSkillMode
          ? `Base directory for this skill: ${ui(q.filePath)}

${$}`
          : $;
        if (
          ((I = gT6(I, R, !0, P)),
          (I = Kh(I, { path: _, source: K })),
          w.isSkillMode)
        ) {
          let g = ui(q.filePath),
            u = process.platform === "win32" ? g.replace(/\\/g, "/") : g;
          I = I.replace(/\$\{CLAUDE_SKILL_DIR\}/g, u);
        }
        return (
          (I = I.replace(/\$\{CLAUDE_SESSION_ID\}/g, y8())),
          (I = await Qp(
            I,
            {
              ...m,
              getAppState() {
                let g = m.getAppState();
                return {
                  ...g,
                  toolPermissionContext: {
                    ...g.toolPermissionContext,
                    alwaysAllowRules: {
                      ...g.toolPermissionContext.alwaysAllowRules,
                      command: X,
                    },
                  },
                };
              },
            },
            `/${A}`,
          )),
          [{ type: "text", text: I }]
        );
      },
    };
  } catch (O) {
    return (
      V(`Failed to create command from ${q.filePath}: ${O}`, {
        level: "error",
      }),
      null
    );
  }
}
