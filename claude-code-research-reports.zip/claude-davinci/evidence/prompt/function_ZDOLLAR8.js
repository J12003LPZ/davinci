function Z$8(A, q) {
  let K = [...BV(A)];
  if (q?.isAgenticQuery) {
    if (!K.includes(Xq8)) K.push(Xq8);
  }
  let Y = bH();
  if (!Y || Y.length === 0) return K;
  return [...K, ...Y.filter((_) => !K.includes(_))];
}
