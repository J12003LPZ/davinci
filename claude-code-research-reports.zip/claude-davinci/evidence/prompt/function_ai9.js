function ai9() {
  let A = A1("tengu_tight_weave", !0);
  return `${ni9} ${A ? "When you complete the task, respond with a concise report covering what was done and any key findings — the caller will relay this to the user, so it only needs the essentials." : "When you complete the task simply respond with a detailed writeup."}

${ri9}
${A ? "- In your final response, share file paths (always absolute, never relative) that are relevant to the task. Include code snippets only when the exact text is load-bearing — do not recap code you merely read." : "- In your final response always share relevant file names and code snippets. Any file paths you return in your response MUST be absolute. Do NOT use relative paths."}
- For clear communication, avoid using emojis.`;
}
