async function m4Y(A) {
  let {
      identity: q,
      taskId: K,
      prompt: Y,
      description: _,
      agentDefinition: z,
      teammateContext: w,
      toolUseContext: O,
      abortController: $,
      model: H,
      systemPrompt: j,
      systemPromptMode: J,
      allowedTools: M,
      allowPermissionPrompts: X,
    } = A,
    { setAppState: D } = O;
  V(`[inProcessRunner] Starting agent loop for ${q.agentId}`);
  let P = {
      agentId: q.agentId,
      parentSessionId: q.parentSessionId,
      agentName: q.agentName,
      teamName: q.teamName,
      agentColor: q.color,
      planModeRequired: q.planModeRequired,
      isTeamLead: !1,
      agentType: "teammate",
    },
    W;
  if (J === "replace" && j) W = j;
  else {
    let E = [
      ...(await HX(
        O.options.tools,
        O.options.mainLoopModel,
        void 0,
        O.options.mcpClients,
      )),
      xS1,
    ];
    if (z) {
      let h = z.getSystemPrompt();
      if (h)
        E.push(`
# Custom Agent Instructions
${h}`);
      if (z.memory)
        Q("tengu_agent_memory_loaded", {
          ...{},
          scope: z.memory,
          source: "in-process-teammate",
        });
    }
    if (J === "append" && j) E.push(j);
    W = E.join(`
`);
  }
  let f = {
      agentType: q.agentName,
      whenToUse: `In-process teammate: ${q.agentName}`,
      getSystemPrompt: () => W,
      tools: z?.tools
        ? [...new Set([...z.tools, UG, Mb, a96, Mh, ae, oe, WE])]
        : ["*"],
      source: "projectSettings",
      permissionMode: "default",
      ...(z?.model ? { model: z.model } : {}),
    },
    Z = [],
    G = sS1("team-lead", Y, void 0, _),
    v = G,
    k = !1;
  await $N4(q.parentSessionId, q.agentName);
  try {
    xb(
      K,
      (E) => ({ ...E, messages: [...(E.messages ?? []), g8({ content: G })] }),
      D,
    );
    let N = O.contentReplacementState ? OU6() : void 0;
    while (!$.signal.aborted && !k) {
      V(
        `[inProcessRunner] ${q.agentId} processing prompt: ${v.substring(0, 50)}...`,
      );
      let E = k5();
      xb(K, (j6) => ({ ...j6, currentWorkAbortController: E }), D);
      let h = g8({ content: v }),
        R = [h],
        m = Z,
        I = hf(Z);
      if (I > eQ6(O.options.mainLoopModel)) {
        V(`[inProcessRunner] ${q.agentId} compacting history (${I} tokens)`);
        let j6 = {
            ...O,
            readFileState: $b(O.readFileState),
            onCompactProgress: void 0,
            setStreamMode: void 0,
          },
          z6 = await bZ6(
            Z,
            j6,
            {
              systemPrompt: iq([]),
              userContext: {},
              systemContext: {},
              toolUseContext: j6,
              forkContextMessages: [],
            },
            !0,
            void 0,
            !0,
          );
        if (((m = $l(z6)), R66(), N)) N = OU6();
        ((Z.length = 0),
          Z.push(...m),
          xb(K, (G6) => ({ ...G6, messages: [...m, h] }), D));
      }
      let g = m.length > 0 ? [...m] : void 0;
      Z.push(h);
      let u = uY6(),
        b = mY6(O.options.tools),
        p = [],
        d = O.getAppState().tasks[K],
        r =
          d && d.type === "in_process_teammate" ? d.permissionMode : "default",
        t = { ...f, permissionMode: r },
        e = !1;
      if (
        (await v$8(w, async () => {
          return zB(P, async () => {
            xb(K, (j6) => ({ ...j6, status: "running", isIdle: !1 }), D);
            for await (let j6 of kk({
              agentDefinition: t,
              promptMessages: R,
              toolUseContext: O,
              canUseTool: S4Y(q, E, (z6) => {
                xb(
                  K,
                  (G6) => ({
                    ...G6,
                    totalPausedMs: (G6.totalPausedMs ?? 0) + z6,
                  }),
                  D,
                );
              }),
              isAsync: !0,
              canShowPermissionPrompts: X ?? !0,
              forkContextMessages: g,
              querySource: "agent:custom",
              override: { abortController: E },
              model: H,
              preserveToolUseResults: !0,
              availableTools: O.options.tools,
              allowedTools: M,
              contentReplacementState: N,
            })) {
              if ($.signal.aborted) {
                V(`[inProcessRunner] ${q.agentId} lifecycle aborted`);
                break;
              }
              if (E.signal.aborted) {
                (V(
                  `[inProcessRunner] ${q.agentId} current work aborted (Escape pressed)`,
                ),
                  (e = !0));
                break;
              }
              (p.push(j6), Z.push(j6), x66(u, j6, b, O.options.tools));
              let z6 = Pl(u);
              xb(
                K,
                (G6) => {
                  let X6 = G6.inProgressToolUseIDs;
                  if (j6.type === "assistant") {
                    for (let c of j6.message.content)
                      if (c.type === "tool_use")
                        X6 = new Set([...(X6 ?? []), c.id]);
                  } else if (j6.type === "user") {
                    let c = j6.message.content;
                    if (Array.isArray(c)) {
                      for (let n of c)
                        if (
                          typeof n === "object" &&
                          "type" in n &&
                          n.type === "tool_result"
                        ) {
                          if (X6)
                            ((X6 = new Set(X6)), X6.delete(n.tool_use_id));
                        }
                    }
                  }
                  return {
                    ...G6,
                    progress: z6,
                    messages: [...(G6.messages ?? []), j6],
                    inProgressToolUseIDs: X6,
                  };
                },
                D,
              );
            }
            return { success: !0, messages: p };
          });
        }),
        xb(K, (j6) => ({ ...j6, currentWorkAbortController: void 0 }), D),
        $.signal.aborted)
      )
        break;
      if (e) {
        V(`[inProcessRunner] ${q.agentId} work interrupted, returning to idle`);
        let j6 = S9({ content: Ol });
        xb(K, (z6) => ({ ...z6, messages: [...(z6.messages ?? []), j6] }), D);
      }
      let H6 = O.getAppState().tasks[K],
        K6 = H6?.type === "in_process_teammate" && H6.isIdle;
      if (
        (xb(
          K,
          (j6) => {
            return (
              j6.onIdleCallbacks?.forEach((z6) => z6()),
              { ...j6, isIdle: !0, onIdleCallbacks: [] }
            );
          },
          D,
        ),
        !K6)
      )
        await ON4(q.agentName, q.color, q.teamName, {
          idleReason: e ? "interrupted" : "available",
          summary: Dc6(Z),
        });
      else
        V(
          `[inProcessRunner] Skipping duplicate idle notification for ${q.agentName}`,
        );
      V(`[inProcessRunner] ${q.agentId} finished prompt, waiting for next`);
      let o = await u4Y(q, $, K, O.getAppState, D, q.parentSessionId);
      switch (o.type) {
        case "shutdown_request":
          (V(
            `[inProcessRunner] ${q.agentId} received shutdown request - passing to model`,
          ),
            (v = sS1(o.request?.from || "team-lead", o.originalMessage)),
            Uv8(K, g8({ content: v }), D));
          break;
        case "new_message":
          if (
            (V(
              `[inProcessRunner] ${q.agentId} received new message from ${o.from}`,
            ),
            o.from === "user")
          )
            v = o.message;
          else
            ((v = sS1(o.from, o.message, o.color, o.summary)),
              Uv8(K, g8({ content: v }), D));
          break;
        case "aborted":
          (V(`[inProcessRunner] ${q.agentId} aborted while waiting`), (k = !0));
          break;
      }
    }
    return (
      xb(
        K,
        (E) => {
          return (
            E.onIdleCallbacks?.forEach((h) => h()),
            E.unregisterCleanup?.(),
            {
              ...E,
              status: "completed",
              notified: !0,
              endTime: Date.now(),
              messages: E.messages?.length
                ? [E.messages[E.messages.length - 1]]
                : void 0,
              pendingUserMessages: [],
              inProgressToolUseIDs: void 0,
              abortController: void 0,
              unregisterCleanup: void 0,
              currentWorkAbortController: void 0,
              onIdleCallbacks: [],
            }
          );
        },
        D,
      ),
      Fj(K),
      vE(K, D),
      y96(q.agentId),
      { success: !0, messages: Z }
    );
  } catch (N) {
    let E = N instanceof Error ? N.message : "Unknown error";
    return (
      V(`[inProcessRunner] Agent ${q.agentId} failed: ${E}`),
      xb(
        K,
        (h) => {
          return (
            h.onIdleCallbacks?.forEach((R) => R()),
            h.unregisterCleanup?.(),
            {
              ...h,
              status: "failed",
              notified: !0,
              error: E,
              isIdle: !0,
              endTime: Date.now(),
              onIdleCallbacks: [],
              messages: h.messages?.length
                ? [h.messages[h.messages.length - 1]]
                : void 0,
              pendingUserMessages: [],
              inProgressToolUseIDs: void 0,
              abortController: void 0,
              unregisterCleanup: void 0,
              currentWorkAbortController: void 0,
            }
          );
        },
        D,
      ),
      Fj(K),
      vE(K, D),
      await ON4(q.agentName, q.color, q.teamName, {
        idleReason: "failed",
        completedStatus: "failed",
        failureReason: E,
      }),
      y96(q.agentId),
      { success: !1, error: E, messages: Z }
    );
  }
}
