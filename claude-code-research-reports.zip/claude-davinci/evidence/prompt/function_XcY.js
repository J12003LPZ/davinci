async function XcY(A, q, K, Y, _, z) {
  if (
    n6(process.env.CLAUDE_CODE_DISABLE_ATTACHMENTS) ||
    n6(process.env.CLAUDE_CODE_SIMPLE)
  )
    return [];
  let w = k5(),
    O = setTimeout((W) => W.abort(), 1000, w),
    $ = { ...q, abortController: w },
    H = !q.agentId,
    j = A
      ? [
          D_("at_mentioned_files", () => mcY(A, $)),
          D_("mcp_resources", () => gcY(A, $)),
          D_("agent_mentions", () =>
            Promise.resolve(BcY(A, q.options.agentDefinitions.activeAgents)),
          ),
          ...[],
        ]
      : [],
    J = await Promise.all(j),
    M = [
      D_("date_change", () => Promise.resolve(LcY(_))),
      D_("ultrathink_effort", () => Promise.resolve(RcY(A))),
      D_("deferred_tools_delta", () =>
        Promise.resolve($Z8(q.options.tools, q.options.mainLoopModel, _)),
      ),
      D_("mcp_instructions_delta", () =>
        Promise.resolve(
          HZ8(
            q.options.mcpClients,
            q.options.tools,
            q.options.mainLoopModel,
            _,
          ),
        ),
      ),
      D_("changed_files", () => pcY($)),
      D_("nested_memory", () => FcY($)),
      D_("dynamic_skill", () => icY($)),
      D_("skill_listing", () => ncY($)),
      D_("ultra_claude_md", async () => CcY(_)),
      D_("plan_mode", () => TcY(_, q)),
      D_("plan_mode_exit", () => kcY(q)),
      D_("auto_mode", () => EcY(_, q)),
      D_("auto_mode_exit", () => ycY(q)),
      D_("todo_reminders", () => (jH() ? zlY(_, q) : YlY(_, q))),
      ...(S7()
        ? [
            ...(z === "session_memory"
              ? []
              : [D_("teammate_mailbox", async () => $lY(q))]),
            D_("team_context", async () => HlY(_ ?? [])),
          ]
        : []),
      D_("agent_pending_messages", async () => WcY(q)),
      D_("critical_system_reminder", () => Promise.resolve(hcY(q))),
    ],
    X = H
      ? [
          D_("ide_selection", async () => IcY(K, q)),
          D_("ide_opened_file", async () => ucY(K, q)),
          D_("output_style", async () => Promise.resolve(ScY())),
          D_("diagnostics", async () => ecY(q)),
          D_("lsp_diagnostics", async () => AlY(q)),
          D_("unified_tasks", async () => wlY(q)),
          D_("async_hook_responses", async () => OlY()),
          D_("token_usage", async () =>
            Promise.resolve(jlY(_ ?? [], q.options.mainLoopModel)),
          ),
          D_("budget_usd", async () =>
            Promise.resolve(MlY(q.options.maxBudgetUsd)),
          ),
          D_("output_token_usage", async () => Promise.resolve(JlY())),
          D_("verify_plan_reminder", async () => DlY(_, q)),
          D_("queued_commands", () => PcY(Y)),
        ]
      : [],
    [D, P] = await Promise.all([Promise.all(M), Promise.all(X)]);
  return (
    clearTimeout(O),
    [...J.flat(), ...D.flat(), ...P.flat()].filter(
      (W) => W !== void 0 && W !== null,
    )
  );
}
