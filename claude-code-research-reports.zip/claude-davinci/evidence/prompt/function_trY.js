function trY(A) {
  return {
    ...A,
    hasClaudeMdExternalIncludesApproved: !0,
    hasClaudeMdExternalIncludesWarningShown: !0,
  };
}
