function mi9(A, q) {
  let K = A.has(Jb.name),
    Y = A.has(Aq),
    _ = q.length > 0 && A.has(qj),
    z = $H(),
    w = z ? `\`find\` or \`grep\` via the ${E7} tool` : `the ${w_} or ${N9}`,
    O = [
      `To read files use ${e7} instead of cat, head, tail, or sed`,
      `To edit files use ${k4} instead of sed or awk`,
      `To create files use ${YK} instead of cat with heredoc or echo redirection`,
      ...(z
        ? []
        : [
            `To search for files use ${w_} instead of find or ls`,
            `To search the content of files, use ${N9} instead of grep or rg`,
          ]),
      `Reserve using the ${E7} exclusively for system commands and terminal operations that require shell execution. If you are unsure and there is a relevant dedicated tool, default to using the dedicated tool and only fallback on using the ${E7} tool for these if it is absolutely necessary.`,
    ],
    $ = [
      `Do NOT use the ${E7} to run commands when a relevant dedicated tool is provided. Using dedicated tools allows the user to better understand and review your work. This is CRITICAL to assisting the user:`,
      O,
      K
        ? `Break down and manage your work with the ${Jb.name} tool. These tools are helpful for planning your work and helping the user track your progress. Mark each task as completed as soon as you are done with the task. Do not batch up multiple tasks before marking them as completed.`
        : null,
      Y ? Bi9() : null,
      ...(T$()
        ? []
        : [
            `For simple, directed codebase searches (e.g. for a specific file/class/function) use ${w} directly.`,
            `For broader codebase exploration and deep research, use the ${Aq} tool with subagent_type=${Dg.agentType}. This is slower than using ${w} directly, so use this only when a simple, directed search proves to be insufficient or when your task will clearly require more than ${M94} queries.`,
          ]),
      null,
      _
        ? `/<skill-name> (e.g., /commit) is shorthand for users to invoke a user-invocable skill. When executed, the skill gets expanded to a full prompt. Use the ${qj} tool to execute them. IMPORTANT: Only use ${qj} for skills listed in its user-invocable skills section - do not guess or use built-in CLI commands.`
        : null,
      jX4 !== null && _ && A.has(jX4) ? gi9() : null,
      "You can call multiple tools in a single response. If you intend to call multiple tools and there are no dependencies between them, make all independent tool calls in parallel. Maximize use of parallel tool calls where possible to increase efficiency. However, if some tool calls depend on previous calls to inform dependent values, do NOT call these tools in parallel and instead call them sequentially. For instance, if one operation must complete before another starts, run these operations sequentially instead.",
    ].filter((H) => H !== null);
  return ["# Using your tools", ...oc($)].join(`
`);
}
