async function de({
  rulesDir: A,
  type: q,
  processedPaths: K,
  includeExternal: Y,
  conditionalRule: _,
  visitedDirs: z = new Set(),
}) {
  if (z.has(A)) return [];
  try {
    let w = O8(),
      { resolvedPath: O, isSymlink: $ } = L2(w, A);
    if ((z.add(A), $)) z.add(O);
    let H = [],
      j;
    try {
      j = await w.readdir(O);
    } catch (J) {
      let M = J.code;
      if (M === "ENOENT" || M === "EACCES" || M === "ENOTDIR") return [];
      throw J;
    }
    for (let J of j) {
      let M = ME(A, J.name),
        { resolvedPath: X, isSymlink: D } = L2(w, M),
        P = D ? await w.stat(X) : null,
        W = P ? P.isDirectory() : J.isDirectory(),
        f = P ? P.isFile() : J.isFile();
      if (W)
        H.push(
          ...(await de({
            rulesDir: X,
            type: q,
            processedPaths: K,
            includeExternal: Y,
            conditionalRule: _,
            visitedDirs: z,
          })),
        );
      else if (f && J.name.endsWith(".md")) {
        let Z = await XE(X, q, K, Y);
        H.push(...Z.filter((G) => (_ ? G.globs : !G.globs)));
      }
    }
    return H;
  } catch (w) {
    if (w instanceof Error && w.message.includes("EACCES"))
      Q("tengu_claude_rules_md_permission_error", {
        is_access_error: 1,
        has_home_dir: A.includes(d1()) ? 1 : 0,
      });
    return [];
  }
}
