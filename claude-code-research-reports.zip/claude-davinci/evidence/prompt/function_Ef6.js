function Ef6(A) {
  let q = [];
  for (let K of A)
    if (K.type !== "User" && K.parent && !u34(K.path))
      q.push({ path: K.path, parent: K.parent });
  return q;
}
