async function Qi9(A, q) {
  let [K, Y] = await Promise.all([BH(), DX4()]),
    _ = "";
  {
    let $ = QQ(A);
    _ = $
      ? `You are powered by the model named ${$}. The exact model ID is ${A}.`
      : `You are powered by the model ${A}.`;
  }
  let z =
      q && q.length > 0
        ? `Additional working directories: ${q.join(", ")}
`
        : "",
    w = MX4(A),
    O = w
      ? `

Assistant knowledge cutoff is ${w}.`
      : "";
  return `Here is useful information about the environment you are running in:
<env>
Working directory: ${Z8()}
Is directory a git repo: ${K ? "Yes" : "No"}
${z}Platform: ${i1.platform}
${XX4()}
OS Version: ${Y}
</env>
${_}${O}`;
}
