import hashlib
import json
import pathlib

ROOT = pathlib.Path('/workspace/research/claude-davinci')
results = []
for i in [9, 10, 11, 12, 13, 15]:
    run = 'rerun-memory' if i == 15 else 'rerun-final'
    path = ROOT / 'evidence/experiments/runs' / run / f'EXP-{i:02d}' / 'result.json'
    capture = json.loads(path.read_text())
    body = capture['requests'][0]['body']
    texts = '\n'.join(block['text'] for message in body['messages']
                      for block in message.get('content', []) if block.get('type') == 'text')
    results.append({
        'id': capture['id'], 'path': str(path),
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'request_count': capture['requestCount'], 'command': capture['command'],
        'system_blocks': [{'prefix': block['text'][:100], 'text_length': len(block['text']),
                           'cache_control': block.get('cache_control')} for block in body['system']],
        'system_last_suffix': body['system'][-1]['text'][-100:],
        'system_fixture_marker': 'CLAUDE.MD FIXTURE SYSTEM BLOCK' in json.dumps(body['system']),
        'system_appended_marker': 'APPENDED FIXTURE SYSTEM BLOCK' in json.dumps(body['system']),
        'message_roles': [message['role'] for message in body['messages']],
        'message_currentDate': "Today's date is" in texts,
        'message_claudeMd_section': '# claudeMd' in texts,
        'message_fixture_marker': 'CLAUDE.MD FIXTURE' in texts,
        'message_last_text_suffix': texts[-650:], 'tool_count': len(body['tools']),
        'tool_schema_keys': sorted(set(key for tool in body['tools'] for key in tool)),
    })
(ROOT / 'evidence/prompt/capture_summary.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps({'captures': len(results), 'all_have_date': all(r['message_currentDate'] for r in results),
                  'claudeMd_present': [r['id'] for r in results if r['message_claudeMd_section']]}))
