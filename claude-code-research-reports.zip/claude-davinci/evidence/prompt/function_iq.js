function iq(A) {
  return A;
}
