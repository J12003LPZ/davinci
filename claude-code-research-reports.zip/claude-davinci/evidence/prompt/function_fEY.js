async function fEY(A, q, K, Y, _) {
  let z = new Set(_.map((w) => w.name));
  try {
    let O = [A.getSystemPrompt({ toolUseContext: q })];
    return await WQ6(O, K, Y, z);
  } catch (w) {
    return await WQ6([PX4], K, Y, z);
  }
}
