async function xBq(A, q, K, Y, _, z) {
  if (n6(!1) || process.env.IS_DEMO) return !1;
  let w = D8(),
    O = !1;
  if (!w.theme || !w.hasCompletedOnboarding) {
    O = !0;
    let [, { Onboarding: $ }] = await Promise.all([
      mz6(),
      Promise.resolve().then(() => ($Bq(), OBq)),
    ]);
    await vy(
      A,
      (H) =>
        vN.default.createElement($, {
          onDone: () => {
            (hT_(), H());
          },
        }),
      { onChangeAppState: hn },
    );
  }
  if (!n6(process.env.CLAUBBIT)) {
    if (!d_()) {
      let { TrustDialog: H } = await Promise.resolve().then(() => (yBq(), EBq));
      await vy(A, (j) =>
        vN.default.createElement(H, { commands: Y, onDone: j }),
      );
    }
    (Jy6(!0), VB6(), pd(), i2());
    let { errors: $ } = $i();
    if ($.length === 0) await cmq(A);
    if (await cV1()) {
      let H = Ef6(await hO(!0)),
        { ClaudeMdExternalIncludesDialog: j } = await Promise.resolve().then(
          () => (Pi1(), j$q),
        );
      await vy(A, (J) =>
        vN.default.createElement(j, {
          onDone: J,
          isStandaloneDialog: !0,
          externalIncludes: H,
        }),
      );
    }
  }
  if ((imq(), TF(), jb8(), await _v6())) {
    let { GroveDialog: $ } = await Promise.resolve().then(() => (Ga1(), qZq));
    if (
      (await vy(A, (j) =>
        vN.default.createElement($, {
          showIfAlreadyViewed: !1,
          location: O ? "onboarding" : "policy_update_modal",
          onDone: j,
        }),
      )) === "escape"
    )
      return (Q("tengu_grove_policy_exited", {}), $K(0), !1);
  }
  if (process.env.ANTHROPIC_API_KEY && !VZ()) {
    let $ = mT(process.env.ANTHROPIC_API_KEY);
    if (LB6($) === "new") {
      let { ApproveApiKey: j } = await Promise.resolve().then(
        () => (q8A(), qBq),
      );
      await vy(
        A,
        (J) =>
          vN.default.createElement(j, { customApiKeyTruncated: $, onDone: J }),
        { onChangeAppState: hn },
      );
    }
  }
  if ((q === "bypassPermissions" || K) && !Rj6()) {
    let { BypassPermissionsModeDialog: $ } = await Promise.resolve().then(
      () => (RBq(), LBq),
    );
    await vy(A, (H) => vN.default.createElement($, { onAccept: H }));
  }
  if (q === "auto" && !Ca()) {
    let { AutoModeOptInDialog: $ } = await Promise.resolve().then(
      () => (Mx8(), vCq),
    );
    await vy(A, (H) =>
      vN.default.createElement($, {
        onAccept: H,
        onDecline: () => $K(1),
        declineExits: !0,
      }),
    );
  }
  if (z && z.length > 0) {
    let [{ isChannelsEnabled: $ }, { getClaudeAIOAuthTokens: H }] =
      await Promise.all([
        Promise.resolve().then(() => (fS8(), tJq)),
        Promise.resolve().then(() => ($A(), II)),
      ]);
    if (!$() || !H()?.accessToken)
      (D$6([...Ju(), ...z.map((j) => ({ ...j, dev: !0 }))]), w68(!0));
    else {
      let { DevChannelsDialog: j } = await Promise.resolve().then(
        () => (SBq(), hBq),
      );
      await vy(A, (J) =>
        vN.default.createElement(j, {
          channels: z,
          onAccept: () => {
            (D$6([...Ju(), ...z.map((M) => ({ ...M, dev: !0 }))]),
              w68(!0),
              J());
          },
        }),
      );
    }
  }
  if (_ && !D8().hasCompletedClaudeInChromeOnboarding) {
    let { ClaudeInChromeOnboarding: $ } = await Promise.resolve().then(
      () => (IBq(), CBq),
    );
    await vy(A, (H) => vN.default.createElement($, { onDone: H }));
  }
  return O;
}
