async function DE8(A, q, K) {
  let _ = (await A.getPromptForCommand(q, K)).map((J) =>
      J.type === "text" ? J.text : "",
    ).join(`
`),
    z = sh(A.allowedTools ?? []),
    w = JgY(K.getAppState, z),
    O = A.agent ?? "general-purpose",
    $ = K.options.agentDefinitions.activeAgents,
    H =
      $.find((J) => J.agentType === O) ??
      $.find((J) => J.agentType === "general-purpose") ??
      $[0];
  if (!H) throw Error("No agent available for forked execution");
  let j = [g8({ content: _ })];
  return {
    skillContent: _,
    modifiedGetAppState: w,
    baseAgent: H,
    promptMessages: j,
  };
}
