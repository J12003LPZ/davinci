function hcY(A) {
  let q = A.criticalSystemReminder_EXPERIMENTAL;
  if (!q) return [];
  return [{ type: "critical_system_reminder", content: q }];
}
