async function JX4(A, q) {
  let [K, Y] = await Promise.all([BH(), DX4()]),
    _ = null;
  {
    let J = QQ(A);
    _ = J
      ? `You are powered by the model named ${J}. The exact model ID is ${A}.`
      : `You are powered by the model ${A}.`;
  }
  let z = MX4(A),
    w = z
      ? `

Assistant knowledge cutoff is ${z}.`
      : null,
    O = Z8(),
    $ = cB8(),
    H = [
      `Primary working directory: ${O}`,
      $
        ? "This is a git worktree — an isolated copy of the repository. Run all commands from this directory. Do NOT `cd` to the original repository root."
        : null,
      [`Is a git repository: ${K}`],
      q && q.length > 0 ? "Additional working directories:" : null,
      q && q.length > 0 ? q : null,
      `Platform: ${i1.platform}`,
      XX4(),
      `OS Version: ${Y}`,
      _,
      w,
      `The most recent Claude model family is Claude 4.5/4.6. Model IDs — Opus 4.6: '${Ry1.opus}', Sonnet 4.6: '${Ry1.sonnet}', Haiku 4.5: '${Ry1.haiku}'. When building AI applications, default to the latest and most capable Claude models.`,
    ].filter((J) => J !== null),
    j = `
<fast_mode_info>
Fast mode for Claude Code uses the same ${yi9} model with faster output. It does NOT switch to a different model. It can be toggled with /fast.
</fast_mode_info>`;
  return [
    "# Environment",
    "You have been invoked in the following environment: ",
    ...oc(H),
    j,
  ].join(`
`);
}
