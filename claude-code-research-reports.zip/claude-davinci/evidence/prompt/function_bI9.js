function bI9(A, q) {
  if (q !== "User" && q !== "Project" && q !== "Local") return !1;
  let K = hA().claudeMdExcludes;
  if (!K || K.length === 0) return !1;
  let Y = { dot: !0 },
    _ = A.replaceAll("\\", "/"),
    z = xI9(K).filter((w) => w.length > 0);
  if (z.length === 0) return !1;
  return x34.default.isMatch(_, z, Y);
}
