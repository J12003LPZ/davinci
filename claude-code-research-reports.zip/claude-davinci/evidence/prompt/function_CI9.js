function CI9(A, q) {
  let K = new Set(),
    _ = new Lf({ gfm: !1 }).lex(A);
  function z(w) {
    for (let O of w) {
      if (O.type === "code" || O.type === "codespan") continue;
      if (O.type === "text") {
        let $ = O.text || "",
          H = /(?:^|\s)@((?:[^\s\\]|\\ )+)/g,
          j;
        while ((j = H.exec($)) !== null) {
          let J = j[1];
          if (!J) continue;
          let M = J.indexOf("#");
          if (M !== -1) J = J.substring(0, M);
          if (!J) continue;
          if (((J = J.replace(/\\ /g, " ")), J)) {
            if (
              J.startsWith("./") ||
              J.startsWith("~/") ||
              (J.startsWith("/") && J !== "/") ||
              (!J.startsWith("@") &&
                !J.match(/^[#%^&*()]+/) &&
                J.match(/^[a-zA-Z0-9._-]/))
            ) {
              let D = T4(J, NU6(q));
              K.add(D);
            }
          }
        }
      }
      if (O.tokens) z(O.tokens);
      if (O.items) z(O.items);
    }
  }
  return (z(_), [...K]);
}
