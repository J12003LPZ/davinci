function b94(A, q, K) {
  return { name: A, compute: q, cacheBreak: !0 };
}
