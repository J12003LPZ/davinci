function erY(A) {
  return {
    ...A,
    hasClaudeMdExternalIncludesApproved: !1,
    hasClaudeMdExternalIncludesWarningShown: !0,
  };
}
