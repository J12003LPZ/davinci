function sV_() {
  if (H7()) {
    (n8("info", "prefetch_system_context_non_interactive"), i2());
    return;
  }
  if (d_()) (n8("info", "prefetch_system_context_has_trust"), i2());
  else n8("info", "prefetch_system_context_skipped_no_trust");
}
