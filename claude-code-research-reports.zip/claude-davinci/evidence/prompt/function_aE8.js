function aE8(A) {
  if (Number(process.env.SLASH_COMMAND_TOOL_CHAR_BUDGET))
    return Number(process.env.SLASH_COMMAND_TOOL_CHAR_BUDGET);
  if (A) return Math.floor(A * St4 * ht4);
  return Ct4;
}
