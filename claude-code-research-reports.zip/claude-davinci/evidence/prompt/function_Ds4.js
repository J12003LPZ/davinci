async function Ds4(A, q, K, Y = [], _ = [], z) {
  let w = await A.getPromptForCommand(q, K);
  if (A.hooks) {
    let D = y8();
    $s4(
      K.setAppState,
      D,
      A.hooks,
      A.name,
      A.type === "prompt" ? A.skillRoot : void 0,
    );
  }
  let O = A.source ? `${A.source}:${A.name}` : A.name,
    $ = w.filter((D) => D.type === "text").map((D) => D.text).join(`

`);
  M$6(A.name, O, $, Yt()?.agentId ?? null);
  let H = MEY(A, q),
    j = sh(A.allowedTools ?? []),
    J = _.length > 0 || Y.length > 0 ? [..._, ...Y, ...w] : w,
    M = await HE8(
      MT6(
        w
          .filter((D) => D.type === "text")
          .map((D) => D.text)
          .join(" "),
        K,
        null,
        [],
        K.messages,
        "repl_main_thread",
      ),
    );
  return {
    messages: [
      g8({ content: H, uuid: z }),
      g8({ content: J, isMeta: !0 }),
      ...M,
      V4({ type: "command_permissions", allowedTools: j, model: A.model }),
    ],
    shouldQuery: !0,
    allowedTools: j,
    model: A.model,
    effort: A.effort,
    command: A,
  };
}
