async function x94(A) {
  let q = lB8();
  return Promise.all(
    A.map(async (K) => {
      if (!K.cacheBreak && q.has(K.name)) return q.get(K.name) ?? null;
      let Y = await K.compute();
      return (iB8(K.name, Y), Y);
    }),
  );
}
