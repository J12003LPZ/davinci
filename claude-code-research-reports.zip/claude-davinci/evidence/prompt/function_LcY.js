function LcY(A) {
  let q = EP6(),
    K = rB8();
  if (K === null) return (X$6(q), []);
  if (q === K) return [];
  return (kz.cache.clear?.(), X$6(q), [{ type: "date_change", newDate: q }]);
}
