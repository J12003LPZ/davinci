function TH8(A) {
  if (gA() === "vertex") return BD1;
  if (A?.isNonInteractive) {
    if (A.hasAppendSystemPrompt) return zu7;
    return wu7;
  }
  return BD1;
}
