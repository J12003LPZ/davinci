function iN_(A, q, K, Y, _, z, w, O, $, H, j, J) {
  let M = !1,
    X = !1,
    D = !1,
    P = null,
    W,
    f = A.outbound,
    Z = () => {
      if (
        (n8("info", "shutdown_signal", { signal: "SIGINT" }),
        W && !W.signal.aborted)
      )
        W.abort();
      Tq(0);
    };
  (process.on("SIGINT", Z),
    Iyq((V6) => {
      if (
        V6 === "default" ||
        V6 === "acceptEdits" ||
        V6 === "bypassPermissions" ||
        V6 === "plan" ||
        V6 === "auto" ||
        V6 === "dontAsk"
      )
        f.enqueue({
          type: "system",
          subtype: "status",
          status: null,
          permissionMode: V6,
          uuid: mX(),
          session_id: y8(),
        });
    }));
  let G = {
    abortController: null,
    inflightPromise: null,
    lastEmitted: null,
    pendingSuggestion: null,
    pendingLastEmittedEntry: null,
  };
  if (j.enableAuthStatus)
    P0.getInstance().subscribe((P6) => {
      f.enqueue({
        type: "auth_status",
        isAuthenticating: P6.isAuthenticating,
        output: P6.output,
        error: P6.error,
        uuid: mX(),
        session_id: y8(),
      });
    });
  let v = (V6) => {
    let P6 = IWq(V6);
    if (P6)
      f.enqueue({
        type: "rate_limit_event",
        rate_limit_info: P6,
        uuid: mX(),
        session_id: y8(),
      });
  };
  D66.add(v);
  let k = _,
    N = Lk6(_, Gu8(), bc),
    E = process.env.CLAUDE_CODE_RESUME_INTERRUPTED_TURN;
  if (J && J.kind !== "none" && E)
    (V(`[print.ts] Auto-resuming interrupted turn (kind: ${J.kind})`),
      YUq(k, J.message),
      qX({ mode: "prompt", value: J.message.message.content, uuid: mX() }));
  let R = ez6().map((V6) => {
      let P6 = V6.value === null ? "default" : V6.value,
        R6 = P6 === "default" ? q0() : v5(P6),
        I6 = iV(R6),
        W6 = fH8(R6),
        T6 = cH(V6.value),
        h6 = eD6(R6);
      return {
        value: P6,
        displayName: V6.label,
        description: V6.description,
        ...(I6
          ? {
              supportsEffort: !0,
              supportedEffortLevels: rB6(R6)
                ? [...gT]
                : gT.filter((F6) => F6 !== "max"),
            }
          : {}),
        ...(W6 ? { supportsAdaptiveThinking: !0 } : {}),
        ...(T6 ? { supportsFastMode: !0 } : {}),
        ...(h6 ? { supportsAutoMode: !0 } : {}),
      };
    }),
    m = j.userSpecifiedModel,
    I = [],
    g = [],
    u = new Set();
  function b(V6) {
    if (!FY6()) return;
    for (let P6 of V6) {
      if (P6.type !== "connected" || u.has(P6.name)) continue;
      if (P6.config.type === "sdk") continue;
      let R6 = P6.name;
      try {
        (P6.client.setRequestHandler(DU, async (I6, W6) => {
          r8(R6, `Elicitation request received in print mode: ${m6(I6)}`);
          let T6 = I6.params.mode === "url" ? "url" : "form";
          Q("tengu_mcp_elicitation_shown", { mode: T6 });
          let h6 = await vd6(R6, I6.params, W6.signal);
          if (h6)
            return (
              r8(R6, `Elicitation resolved by hook: ${m6(h6)}`),
              Q("tengu_mcp_elicitation_response", {
                mode: T6,
                action: h6.action,
              }),
              h6
            );
          let F6 = "url" in I6.params ? I6.params.url : void 0,
            U6 =
              "requestedSchema" in I6.params
                ? I6.params.requestedSchema
                : void 0,
            k6 =
              "elicitationId" in I6.params ? I6.params.elicitationId : void 0,
            C6 = await A.handleElicitation(
              R6,
              I6.params.message,
              U6,
              W6.signal,
              T6,
              F6,
              k6,
            ),
            o6 = await Td6(R6, C6, W6.signal, T6, k6);
          return (
            Q("tengu_mcp_elicitation_response", {
              mode: T6,
              action: o6.action,
            }),
            o6
          );
        }),
          P6.client.setNotificationHandler(xL6, (I6) => {
            let { elicitationId: W6 } = I6.params;
            (r8(R6, `Elicitation completion notification: ${W6}`),
              og({
                message: `MCP server "${R6}" confirmed elicitation ${W6} complete`,
                notificationType: "elicitation_complete",
              }),
              f.enqueue({
                type: "system",
                subtype: "elicitation_complete",
                mcp_server_name: R6,
                elicitation_id: W6,
                uuid: mX(),
                session_id: y8(),
              }));
          }),
          u.add(R6));
      } catch {}
    }
  }
  async function p() {
    let V6 = new Set(Object.keys(w)),
      P6 = new Set(I.map((h6) => h6.name)),
      R6 = Array.from(V6).some((h6) => !P6.has(h6)),
      I6 = Array.from(P6).some((h6) => !V6.has(h6)),
      W6 = I.some((h6) => h6.type === "pending");
    if (R6 || I6 || W6) {
      for (let U6 of I)
        if (!V6.has(U6.name)) {
          if (U6.type === "connected") await U6.cleanup();
        }
      let h6 = await fT4(w, (U6, k6) => A.sendMcpMessage(U6, k6));
      ((I = h6.clients), (g = h6.tools));
      let F6 = new Set([...P6, ...V6]);
      ($((U6) => ({
        ...U6,
        mcp: {
          ...U6.mcp,
          tools: [
            ...U6.mcp.tools.filter(
              (k6) => !Array.from(F6).some((C6) => k6.name.startsWith(VC(C6))),
            ),
            ...g,
          ],
        },
      })),
        ds4(I));
    }
  }
  p();
  let U = { clients: [], tools: [], configs: {} },
    d = null,
    r = 0;
  function t() {
    if (!d) return;
    let V6 = Math.min(r, k.length),
      P6 = k
        .slice(V6)
        .filter((R6) => R6.type === "user" || R6.type === "assistant");
    if (((r = k.length), P6.length > 0)) d.writeMessages(P6);
  }
  let e = Promise.resolve({
    response: { added: [], removed: [], errors: {} },
    sdkServersChanged: !1,
  });
  function q6(V6) {
    let P6 = async () => {
      let R6 = new Set(I.map((W6) => W6.name)),
        I6 = await zUq(V6, { configs: w, clients: I, tools: g }, U, $);
      for (let W6 of Object.keys(w)) delete w[W6];
      if (
        (Object.assign(w, I6.newSdkState.configs),
        (I = I6.newSdkState.clients),
        (g = I6.newSdkState.tools),
        (U = I6.newDynamicState),
        I6.sdkServersChanged)
      ) {
        let W6 = new Set(I.map((h6) => h6.name)),
          T6 = new Set([...R6, ...W6]);
        $((h6) => ({
          ...h6,
          mcp: {
            ...h6.mcp,
            tools: [
              ...h6.mcp.tools.filter(
                (F6) =>
                  !Array.from(T6).some((U6) => F6.name.startsWith(VC(U6))),
              ),
              ...g,
            ],
          },
        }));
      }
      return { response: I6.response, sdkServersChanged: I6.sdkServersChanged };
    };
    return ((e = e.then(P6, P6)), e);
  }
  async function H6() {
    try {
      if (
        (await Promise.all([
          Promise.resolve(),
          x78("headless_managed_settings_wait", () => eT8()),
        ]),
        await nFq())
      ) {
        let { servers: P6 } = await Q66(),
          R6 = {};
        for (let [T6, h6] of Object.entries(P6)) {
          let F6 = h6.type;
          if (
            F6 === void 0 ||
            F6 === "stdio" ||
            F6 === "sse" ||
            F6 === "http" ||
            F6 === "sdk"
          )
            R6[T6] = h6;
        }
        for (let [T6, h6] of Object.entries(w))
          if (h6.type === "sdk" && !(T6 in R6)) R6[T6] = h6;
        let { response: I6, sdkServersChanged: W6 } = await q6(R6);
        if (W6) p();
        V(
          `Headless MCP refresh: added=${I6.added.length}, removed=${I6.removed.length}`,
        );
      }
    } catch (V6) {
      $6(V6);
    }
  }
  let K6 = null;
  if (n6(process.env.CLAUDE_CODE_SYNC_PLUGIN_INSTALL)) K6 = H6();
  else H6();
  let o = pFq(() => !M),
    j6 = K,
    z6 = H;
  async function G6() {
    let { agentDefinitions: V6 } = await qV6($);
    j6 = await qW(Gu8());
    let P6 = z6.filter((R6) => R6.source === "flagSettings");
    z6 = [...V6.allAgents, ...P6];
  }
  let X6 = ZV6.subscribe(() => {
      (op(),
        qW(Gu8()).then((V6) => {
          j6 = V6;
        }));
    }),
    c = void 0;
  zf6(() => {
    if (W && IP8("now").length > 0) W.abort("interrupt");
  });
  let n = async () => {
      if (M) return;
      if (((M = !0), vV6("running"), o.stop(), await p(), K6)) {
        let V6 = parseInt(
          process.env.CLAUDE_CODE_SYNC_PLUGIN_INSTALL_TIMEOUT_MS || "",
          10,
        );
        if (V6 > 0) {
          let R6 = new Promise((W6) => setTimeout(W6, V6, "timeout"));
          if ((await Promise.race([K6, R6])) === "timeout")
            ($6(
              Error(
                `CLAUDE_CODE_SYNC_PLUGIN_INSTALL: plugin installation timed out after ${V6}ms`,
              ),
            ),
              Q("tengu_sync_plugin_install_timeout", { timeout_ms: V6 }));
        } else await K6;
        ((K6 = null), await G6());
        let { setupPluginHookHotReload: P6 } = await Promise.resolve().then(
          () => (SY6(), qR1),
        );
        P6();
      }
      try {
        let V6,
          P6 = !1,
          R6 = async () => {
            while ((V6 = hP8())) {
              if (
                V6.mode !== "prompt" &&
                V6.mode !== "orphaned-permission" &&
                V6.mode !== "task-notification"
              )
                throw Error(
                  "only prompt commands are supported in streaming mode",
                );
              let I6 = O(),
                W6 = [...I6.mcp.clients, ...I, ...U.clients];
              b(W6);
              let T6 = Up(I6.toolPermissionContext, I6.mcp.tools),
                h6 = ij(
                  AV6(
                    [...Y, ...g, ...U.tools],
                    T6,
                    I6.toolPermissionContext.mode,
                  ),
                  "name",
                );
              if (j.permissionPromptToolName)
                h6 = h6.filter((o6) => !O3(o6, j.permissionPromptToolName));
              let F6 = q68();
              if (F6 && !j.jsonSchema) {
                let o6 = l08(F6);
                if ("tool" in o6) h6 = [...h6, o6.tool];
              }
              if (V6.uuid) ng(V6.uuid, "started");
              if (V6.mode === "task-notification") {
                let o6 = typeof V6.value === "string" ? V6.value : "",
                  e6 = o6.match(/<task-id>([^<]+)<\/task-id>/),
                  $8 = o6.match(/<tool-use-id>([^<]+)<\/tool-use-id>/),
                  j8 = o6.match(/<output-file>([^<]+)<\/output-file>/),
                  i = o6.match(/<status>([^<]+)<\/status>/),
                  w6 = o6.match(/<summary>([^<]+)<\/summary>/),
                  x6 = (P1) =>
                    P1 === "completed" ||
                    P1 === "failed" ||
                    P1 === "stopped" ||
                    P1 === "killed",
                  g6 = i?.[1],
                  b6 = x6(g6)
                    ? g6 === "killed"
                      ? "stopped"
                      : g6
                    : "completed",
                  J8 = o6.match(/<usage>([\s\S]*?)<\/usage>/)?.[1] ?? "",
                  f8 = J8.match(/<total_tokens>(\d+)<\/total_tokens>/),
                  w8 = J8.match(/<tool_uses>(\d+)<\/tool_uses>/),
                  l8 = J8.match(/<duration_ms>(\d+)<\/duration_ms>/);
                f.enqueue({
                  type: "system",
                  subtype: "task_notification",
                  task_id: e6?.[1] ?? "",
                  tool_use_id: $8?.[1],
                  status: b6,
                  output_file: j8?.[1] ?? "",
                  summary: w6?.[1] ?? "",
                  usage:
                    f8 && w8
                      ? {
                          total_tokens: parseInt(f8[1], 10),
                          tool_uses: parseInt(w8[1], 10),
                          duration_ms: l8 ? parseInt(l8[1], 10) : 0,
                        }
                      : void 0,
                  session_id: y8(),
                  uuid: mX(),
                });
              }
              let U6 = V6.value;
              if (A instanceof Zu8 && V6.mode === "prompt")
                Q("tengu_bridge_message_received", { is_repl: !1 });
              if (
                (G.abortController?.abort(),
                (G.abortController = null),
                (G.pendingSuggestion = null),
                (G.pendingLastEmittedEntry = null),
                G.lastEmitted)
              ) {
                if (V6.mode === "prompt") {
                  let o6 =
                    typeof U6 === "string"
                      ? U6
                      : U6.find((e6) => e6.type === "text")?.text;
                  if (typeof o6 === "string")
                    VYq(
                      G.lastEmitted.text,
                      o6,
                      G.lastEmitted.emittedAt,
                      G.lastEmitted.promptId,
                      G.lastEmitted.generationRequestId,
                    );
                  G.lastEmitted = null;
                }
              }
              W = k5();
              let k6 = void 0,
                C6 = V6;
              if (
                (await Zq8(C6.workload ?? j.workload, async () => {
                  for await (let o6 of mFq({
                    commands: ij([...j6, ...I6.mcp.commands], "name"),
                    prompt: U6,
                    promptUuid: C6.uuid,
                    isMeta: C6.isMeta,
                    cwd: Gu8(),
                    tools: h6,
                    verbose: j.verbose,
                    mcpClients: W6,
                    thinkingConfig: j.thinkingConfig,
                    maxTurns: j.maxTurns,
                    maxBudgetUsd: j.maxBudgetUsd,
                    canUseTool: z,
                    userSpecifiedModel: m,
                    fallbackModel: j.fallbackModel,
                    jsonSchema: q68() ?? j.jsonSchema,
                    mutableMessages: k,
                    getReadFileCache: () => N,
                    setReadFileCache: (e6) => {
                      N = e6;
                    },
                    customSystemPrompt: j.systemPrompt,
                    appendSystemPrompt: j.appendSystemPrompt,
                    getAppState: O,
                    setAppState: $,
                    abortController: W,
                    replayUserMessages: j.replayUserMessages,
                    includePartialMessages: j.includePartialMessages,
                    handleElicitation: (e6, $8, j8) =>
                      A.handleElicitation(
                        e6,
                        $8.message,
                        void 0,
                        j8,
                        $8.mode,
                        $8.url,
                        "elicitationId" in $8 ? $8.elicitationId : void 0,
                      ),
                    agents: z6,
                    orphanedPermission: C6.orphanedPermission,
                    setSDKStatus: (e6) => {
                      f.enqueue({
                        type: "system",
                        subtype: "status",
                        status: e6,
                        session_id: y8(),
                        uuid: mX(),
                      });
                    },
                  }))
                    if ((t(), o6.type === "result")) {
                      for (let $8 of bf8()) f.enqueue($8);
                      let e6 = O();
                      if (
                        RL1(e6).some(
                          ($8) => $8.type === "local_agent" && $j($8),
                        )
                      )
                        P = o6;
                      else ((P = null), f.enqueue(o6));
                    } else {
                      for (let e6 of bf8()) f.enqueue(e6);
                      f.enqueue(o6);
                    }
                }),
                V6.uuid)
              )
                ng(V6.uuid, "completed");
              if (
                (t(),
                d?.sendResult(),
                j.promptSuggestions &&
                  process.env.CLAUDE_CODE_ENABLE_PROMPT_SUGGESTION !== "false")
              ) {
                G.abortController?.abort();
                let e6 = new AbortController();
                G.abortController = e6;
                let $8 = Pr6();
                if (!$8) jW("sdk_no_params", void 0, void 0, "sdk");
                else {
                  let j8 = { promise: null };
                  ((j8.promise = (async () => {
                    try {
                      let i = await Ld1(e6, k, O, $8, "sdk");
                      if (!i || e6.signal.aborted) return;
                      let w6 = {
                          type: "prompt_suggestion",
                          suggestion: i.suggestion,
                          uuid: mX(),
                          session_id: y8(),
                        },
                        x6 = {
                          text: i.suggestion,
                          emittedAt: Date.now(),
                          promptId: i.promptId,
                          generationRequestId: i.generationRequestId,
                        };
                      if (P)
                        ((G.pendingSuggestion = w6),
                          (G.pendingLastEmittedEntry = {
                            text: x6.text,
                            promptId: x6.promptId,
                            generationRequestId: x6.generationRequestId,
                          }));
                      else ((G.lastEmitted = x6), f.enqueue(w6));
                    } catch (i) {
                      if (
                        i instanceof Error &&
                        (i.name === "AbortError" ||
                          i.name === "APIUserAbortError")
                      ) {
                        jW("aborted", void 0, void 0, "sdk");
                        return;
                      }
                      $6(
                        i instanceof Error
                          ? i
                          : Error("SDK prompt suggestion generation failed"),
                      );
                    } finally {
                      if (G.inflightPromise === j8.promise)
                        G.inflightPromise = null;
                    }
                  })()),
                    (G.inflightPromise = j8.promise));
                }
              }
              (kR1(), TR1());
            }
          };
        do {
          for (let I6 of bf8()) f.enqueue(I6);
          (await R6(), (P6 = !1));
          {
            let I6 = O(),
              W6 = RL1(I6).some(
                (h6) => $j(h6) && h6.type !== "in_process_teammate",
              ),
              T6 = h96();
            if (W6 || T6) {
              if (((P6 = !0), !T6))
                await new Promise((h6) => setTimeout(h6, 100));
            }
          }
        } while (P6);
        if (P) {
          if ((f.enqueue(P), (P = null), G.pendingSuggestion)) {
            if ((f.enqueue(G.pendingSuggestion), G.pendingLastEmittedEntry))
              ((G.lastEmitted = {
                ...G.pendingLastEmittedEntry,
                emittedAt: Date.now(),
              }),
                (G.pendingLastEmittedEntry = null));
            G.pendingSuggestion = null;
          }
        }
      } catch (V6) {
        try {
          await A.write({
            type: "result",
            subtype: "error_during_execution",
            duration_ms: 0,
            duration_api_ms: 0,
            is_error: !0,
            num_turns: 0,
            stop_reason: null,
            session_id: y8(),
            total_cost_usd: 0,
            usage: HW,
            modelUsage: {},
            permission_denials: [],
            uuid: mX(),
            errors: [r6(V6), ...s76().map((P6) => P6.error)],
          });
        } catch {}
        (G.abortController?.abort(), $K(1));
        return;
      } finally {
        if ((await A.flushInternalEvents(), !iT8())) vV6("idle");
        ((M = !1), o.start());
      }
      if (h96()) {
        n();
        return;
      }
      {
        let P6 = O().teamContext;
        if (P6 && Xf(P6))
          while (!0) {
            let W6 = O();
            if (
              !(
                k$8(W6) ||
                (W6.teamContext &&
                  Object.keys(W6.teamContext.teammates).length > 0)
              )
            ) {
              V("[print.ts] No more active teammates, stopping poll");
              break;
            }
            let h6 = await q_6("team-lead", W6.teamContext?.teamName);
            if (h6.length > 0) {
              (V(`[print.ts] Team-lead found ${h6.length} unread messages`),
                await Hc6("team-lead", W6.teamContext?.teamName));
              let F6 = W6.teamContext?.teamName;
              for (let k6 of h6) {
                let C6 = oG(k6.text);
                if (C6 && F6) {
                  let o6 = C6.from;
                  V(`[print.ts] Processing shutdown_approved from ${o6}`);
                  let e6 = W6.teamContext?.teammates
                    ? Object.entries(W6.teamContext.teammates).find(
                        ([, $8]) => $8.name === o6,
                      )?.[0]
                    : void 0;
                  if (e6)
                    (M_6(F6, { agentId: e6, name: o6 }),
                      V(`[print.ts] Removed ${o6} from team file`),
                      await ne(F6, e6, o6, "shutdown"),
                      $(($8) => {
                        if (!$8.teamContext?.teammates) return $8;
                        if (!(e6 in $8.teamContext.teammates)) return $8;
                        let { [e6]: j8, ...i } = $8.teamContext.teammates;
                        return {
                          ...$8,
                          teamContext: { ...$8.teamContext, teammates: i },
                        };
                      }));
                }
              }
              let U6 = h6.map(
                (
                  k6,
                ) => `<${yj} teammate_id="${k6.from}"${k6.color ? ` color="${k6.color}"` : ""}>
${k6.text}
</${yj}>`,
              ).join(`

`);
              (qX({ mode: "prompt", value: U6, uuid: mX() }), n());
              return;
            }
            if (X && !D) {
              ((D = !0),
                V(
                  "[print.ts] Input closed with active teammates, injecting shutdown prompt",
                ),
                qX({ mode: "prompt", value: tFq, uuid: mX() }),
                n());
              return;
            }
            await new Promise((F6) => setTimeout(F6, 500));
          }
      }
      if (X)
        if (
          await (async () => {
            let P6 = O();
            if (pM1(P6)) await FM1($, P6);
            let R6 = O(),
              I6 = R6.teamContext;
            return (I6 && Object.keys(I6.teammates).length > 0) || k$8(R6);
          })()
        )
          (qX({ mode: "prompt", value: tFq, uuid: mX() }), n());
        else {
          if (G.inflightPromise)
            await Promise.race([
              G.inflightPromise,
              new Promise((P6) => setTimeout(P6, 5000)),
            ]);
          (G.abortController?.abort(),
            (G.abortController = null),
            await WN1(),
            X6(),
            D66.delete(v),
            f.done());
        }
    },
    A6 = null;
  if (oFq && sFq?.isKairosCronEnabled())
    ((A6 = oFq.createCronScheduler({
      onFire: (V6) => {
        if (X) return;
        (qX({
          mode: "prompt",
          value: V6,
          uuid: mX(),
          priority: "later",
          isMeta: !0,
          workload: Wq8,
        }),
          n());
      },
      isLoading: () => M || X,
      getJitterConfig: dN_?.getCronJitterConfig,
      isKilled: () => !sFq?.isKairosCronEnabled(),
    })),
      A6.start());
  let a = function (V6, P6) {
      f.enqueue({
        type: "control_response",
        response: {
          subtype: "success",
          request_id: V6.request_id,
          response: P6,
        },
      });
    },
    s = function (V6, P6) {
      f.enqueue({
        type: "control_response",
        response: { subtype: "error", request_id: V6.request_id, error: P6 },
      });
    },
    O6 = new Set();
  A.setUnexpectedResponseCallback(async (V6) => {
    await _Uq({
      message: V6,
      setAppState: $,
      handledToolUseIds: O6,
      onEnqueued: () => {
        n();
      },
    });
  });
  let J6 = new Map(),
    Z6 = new Map(),
    f6 = new Set(),
    y6 = new Map(),
    v6 = null;
  return (
    (async () => {
      let V6 = !1;
      n8("info", "cli_message_loop_started");
      for await (let P6 of A.structuredInput) {
        let R6 = "uuid" in P6 ? P6.uuid : void 0;
        if (R6 && P6.type !== "user" && P6.type !== "control_response")
          ng(R6, "completed");
        if (P6.type === "control_request") {
          if (P6.request.subtype === "interrupt") {
            if (W) W.abort();
            (G.abortController?.abort(),
              (G.abortController = null),
              (G.lastEmitted = null),
              (G.pendingSuggestion = null),
              a(P6));
          } else if (P6.request.subtype === "end_session") {
            if (
              (V(
                `[print.ts] end_session received, reason=${P6.request.reason ?? "unspecified"}`,
              ),
              W)
            )
              W.abort();
            (G.abortController?.abort(),
              (G.abortController = null),
              (G.lastEmitted = null),
              (G.pendingSuggestion = null),
              a(P6));
            break;
          } else if (P6.request.subtype === "initialize") {
            if (P6.request.sdkMcpServers && P6.request.sdkMcpServers.length > 0)
              for (let I6 of P6.request.sdkMcpServers)
                w[I6] = { type: "sdk", name: I6 };
            if (
              (await nN_(
                P6.request,
                P6.request_id,
                V6,
                f,
                K,
                R,
                A,
                !!j.enableAuthStatus,
                j,
                H,
                O,
              ),
              P6.request.promptSuggestions)
            )
              $((I6) => {
                if (I6.promptSuggestionEnabled) return I6;
                return { ...I6, promptSuggestionEnabled: !0 };
              });
            if (
              P6.request.agentProgressSummaries &&
              A1("tengu_slate_prism", !0)
            )
              WB8(!0);
            if (((V6 = !0), h96())) n();
          } else if (P6.request.subtype === "set_permission_mode") {
            let I6 = P6.request;
            $((W6) => ({
              ...W6,
              toolPermissionContext: rN_(
                I6,
                P6.request_id,
                W6.toolPermissionContext,
                f,
              ),
            }));
          } else if (P6.request.subtype === "set_model") {
            let I6 = P6.request.model ?? "default",
              W6 = I6 === "default" ? q0() : I6;
            ((m = W6), SW(W6), Wb8({ model: W6 }));
            let T6 = lVq(I6, cL(W6));
            k.push(...T6);
            for (let h6 of T6)
              if (
                typeof h6.message.content === "string" &&
                h6.message.content.includes(`<${FP}>`)
              )
                f.enqueue({
                  type: "user",
                  message: h6.message,
                  session_id: y8(),
                  parent_tool_use_id: null,
                  uuid: h6.uuid,
                  timestamp: h6.timestamp,
                  isReplay: !0,
                });
            a(P6);
          } else if (P6.request.subtype === "set_max_thinking_tokens") {
            if (P6.request.max_thinking_tokens === null)
              j.thinkingConfig = void 0;
            else if (P6.request.max_thinking_tokens === 0)
              j.thinkingConfig = { type: "disabled" };
            else
              j.thinkingConfig = {
                type: "enabled",
                budgetTokens: P6.request.max_thinking_tokens,
              };
            a(P6);
          } else if (P6.request.subtype === "mcp_status") {
            let I6 = O(),
              W6 = I6.mcp.clients,
              T6 = ij([...I6.mcp.tools, ...U.tools], "name"),
              h6 = new Set([
                ...W6.map((U6) => U6.name),
                ...I.map((U6) => U6.name),
              ]),
              F6 = [
                ...W6,
                ...I,
                ...U.clients.filter((U6) => !h6.has(U6.name)),
              ].map((U6) => {
                let k6;
                if (U6.config.type === "sse" || U6.config.type === "http")
                  k6 = {
                    type: U6.config.type,
                    url: U6.config.url,
                    headers: U6.config.headers,
                    oauth: U6.config.oauth,
                  };
                else if (U6.config.type === "claudeai-proxy")
                  k6 = {
                    type: "claudeai-proxy",
                    url: U6.config.url,
                    id: U6.config.id,
                  };
                else if (
                  U6.config.type === "stdio" ||
                  U6.config.type === void 0
                )
                  k6 = {
                    type: "stdio",
                    command: U6.config.command,
                    args: U6.config.args,
                  };
                let C6 =
                  U6.type === "connected"
                    ? tg(T6, U6.name).map((o6) => ({
                        name: o6.mcpInfo?.toolName ?? o6.name,
                        annotations: {
                          readOnly: o6.isReadOnly({}) || void 0,
                          destructive: o6.isDestructive?.({}) || void 0,
                          openWorld: o6.isOpenWorld?.({}) || void 0,
                        },
                      }))
                    : void 0;
                return {
                  name: U6.name,
                  status: U6.type,
                  serverInfo: U6.type === "connected" ? U6.serverInfo : void 0,
                  error: U6.type === "failed" ? U6.error : void 0,
                  config: k6,
                  scope: U6.config.scope,
                  tools: C6,
                };
              });
            a(P6, { mcpServers: F6 });
          } else if (P6.request.subtype === "mcp_message") {
            let I6 = P6.request,
              W6 = I.find((T6) => T6.name === I6.server_name);
            if (
              W6 &&
              W6.type === "connected" &&
              W6.client?.transport?.onmessage
            )
              W6.client.transport.onmessage(I6.message);
            a(P6);
          } else if (P6.request.subtype === "rewind_files") {
            let I6 = O(),
              W6 = await KUq(
                P6.request.user_message_id,
                I6,
                $,
                P6.request.dry_run ?? !1,
              );
            if (W6.canRewind || P6.request.dry_run) a(P6, W6);
            else s(P6, W6.error ?? "Unexpected error");
          } else if (P6.request.subtype === "cancel_async_message") {
            let I6 = P6.request.message_uuid,
              W6 = SP8((T6) => T6.uuid === I6);
            a(P6, { cancelled: W6.length > 0 });
          } else if (P6.request.subtype === "mcp_set_servers") {
            let { response: I6, sdkServersChanged: W6 } = await q6(
              P6.request.servers,
            );
            if ((a(P6, I6), W6)) p();
          } else if (P6.request.subtype === "mcp_reconnect") {
            let I6 = O(),
              { serverName: W6 } = P6.request;
            u.delete(W6);
            let T6 =
              Gk(W6) ??
              q.find((h6) => h6.name === W6)?.config ??
              I.find((h6) => h6.name === W6)?.config ??
              U.clients.find((h6) => h6.name === W6)?.config ??
              I6.mcp.clients.find((h6) => h6.name === W6)?.config ??
              null;
            if (!T6) s(P6, `Server not found: ${W6}`);
            else {
              let h6 = await Tl(W6, T6),
                F6 = VC(W6);
              if (
                ($((U6) => ({
                  ...U6,
                  mcp: {
                    ...U6.mcp,
                    clients: U6.mcp.clients.map((k6) =>
                      k6.name === W6 ? h6.client : k6,
                    ),
                    tools: [
                      ...qN(U6.mcp.tools, (k6) => k6.name?.startsWith(F6)),
                      ...h6.tools,
                    ],
                    commands: [
                      ...qN(U6.mcp.commands, (k6) => k6.name?.startsWith(F6)),
                      ...h6.commands,
                    ],
                    resources:
                      h6.resources && h6.resources.length > 0
                        ? { ...U6.mcp.resources, [W6]: h6.resources }
                        : C16(U6.mcp.resources, W6),
                  },
                })),
                (U = {
                  ...U,
                  clients: [
                    ...U.clients.filter((U6) => U6.name !== W6),
                    h6.client,
                  ],
                  tools: [
                    ...U.tools.filter((U6) => !U6.name?.startsWith(F6)),
                    ...h6.tools,
                  ],
                }),
                h6.client.type === "connected")
              )
                (b([h6.client]), a(P6));
              else {
                let U6 =
                  h6.client.type === "failed"
                    ? (h6.client.error ?? "Connection failed")
                    : `Server status: ${h6.client.type}`;
                s(P6, U6);
              }
            }
          } else if (P6.request.subtype === "mcp_toggle") {
            let I6 = O(),
              { serverName: W6, enabled: T6 } = P6.request;
            u.delete(W6);
            let h6 =
              Gk(W6) ??
              q.find((F6) => F6.name === W6)?.config ??
              I.find((F6) => F6.name === W6)?.config ??
              U.clients.find((F6) => F6.name === W6)?.config ??
              I6.mcp.clients.find((F6) => F6.name === W6)?.config ??
              null;
            if (!h6) s(P6, `Server not found: ${W6}`);
            else if (!T6) {
              WG6(W6, !1);
              let F6 = [...q, ...I, ...U.clients, ...I6.mcp.clients].find(
                (k6) => k6.name === W6,
              );
              if (F6 && F6.type === "connected") await vk(W6, h6);
              let U6 = VC(W6);
              ($((k6) => ({
                ...k6,
                mcp: {
                  ...k6.mcp,
                  clients: k6.mcp.clients.map((C6) =>
                    C6.name === W6
                      ? { name: W6, type: "disabled", config: h6 }
                      : C6,
                  ),
                  tools: qN(k6.mcp.tools, (C6) => C6.name?.startsWith(U6)),
                  commands: qN(k6.mcp.commands, (C6) =>
                    C6.name?.startsWith(U6),
                  ),
                  resources: C16(k6.mcp.resources, W6),
                },
              })),
                a(P6));
            } else {
              WG6(W6, !0);
              let F6 = await Tl(W6, h6),
                U6 = VC(W6);
              if (
                ($((k6) => ({
                  ...k6,
                  mcp: {
                    ...k6.mcp,
                    clients: k6.mcp.clients.map((C6) =>
                      C6.name === W6 ? F6.client : C6,
                    ),
                    tools: [
                      ...qN(k6.mcp.tools, (C6) => C6.name?.startsWith(U6)),
                      ...F6.tools,
                    ],
                    commands: [
                      ...qN(k6.mcp.commands, (C6) => C6.name?.startsWith(U6)),
                      ...F6.commands,
                    ],
                    resources:
                      F6.resources && F6.resources.length > 0
                        ? { ...k6.mcp.resources, [W6]: F6.resources }
                        : C16(k6.mcp.resources, W6),
                  },
                })),
                F6.client.type === "connected")
              )
                (b([F6.client]), a(P6));
              else {
                let k6 =
                  F6.client.type === "failed"
                    ? (F6.client.error ?? "Connection failed")
                    : `Server status: ${F6.client.type}`;
                s(P6, k6);
              }
            }
          } else if (P6.request.subtype === "mcp_authenticate") {
            let { serverName: I6 } = P6.request,
              W6 = O(),
              T6 =
                Gk(I6) ??
                q.find((h6) => h6.name === I6)?.config ??
                W6.mcp.clients.find((h6) => h6.name === I6)?.config ??
                null;
            if (!T6) s(P6, `Server not found: ${I6}`);
            else if (T6.type !== "sse" && T6.type !== "http")
              s(
                P6,
                `Server type "${T6.type}" does not support OAuth authentication`,
              );
            else
              try {
                J6.get(I6)?.abort();
                let h6 = new AbortController();
                J6.set(I6, h6);
                let F6,
                  U6 = new Promise((e6) => {
                    F6 = e6;
                  }),
                  k6 = TG6(I6, T6, (e6) => F6(e6), h6.signal, {
                    skipBrowserOpen: !0,
                    onWaitingForCallback: (e6) => {
                      Z6.set(I6, e6);
                    },
                  }),
                  C6 = await Promise.race([U6, k6.then(() => null)]);
                if (C6) a(P6, { authUrl: C6, requiresUserAction: !0 });
                else a(P6, { requiresUserAction: !1 });
                y6.set(I6, k6);
                let o6 = k6
                  .then(async () => {
                    if (Zk(I6)) return;
                    if (f6.has(I6)) return;
                    let e6 = await Tl(I6, T6),
                      $8 = VC(I6);
                    ($((j8) => ({
                      ...j8,
                      mcp: {
                        ...j8.mcp,
                        clients: j8.mcp.clients.map((i) =>
                          i.name === I6 ? e6.client : i,
                        ),
                        tools: [
                          ...qN(j8.mcp.tools, (i) => i.name?.startsWith($8)),
                          ...e6.tools,
                        ],
                        commands: [
                          ...qN(j8.mcp.commands, (i) => i.name?.startsWith($8)),
                          ...e6.commands,
                        ],
                        resources:
                          e6.resources && e6.resources.length > 0
                            ? { ...j8.mcp.resources, [I6]: e6.resources }
                            : C16(j8.mcp.resources, I6),
                      },
                    })),
                      (U = {
                        ...U,
                        clients: [
                          ...U.clients.filter((j8) => j8.name !== I6),
                          e6.client,
                        ],
                        tools: [
                          ...U.tools.filter((j8) => !j8.name?.startsWith($8)),
                          ...e6.tools,
                        ],
                      }));
                  })
                  .catch((e6) => {
                    V(`MCP OAuth failed for ${I6}: ${e6}`, { level: "error" });
                  })
                  .finally(() => {
                    if (J6.get(I6) === h6)
                      (J6.delete(I6),
                        Z6.delete(I6),
                        f6.delete(I6),
                        y6.delete(I6));
                  });
              } catch (h6) {
                s(P6, r6(h6));
              }
          } else if (P6.request.subtype === "mcp_oauth_callback_url") {
            let { serverName: I6, callbackUrl: W6 } = P6.request,
              T6 = Z6.get(I6);
            if (T6) {
              let h6 = !1;
              try {
                let F6 = new URL(W6);
                h6 =
                  F6.searchParams.has("code") || F6.searchParams.has("error");
              } catch {}
              if (!h6)
                s(
                  P6,
                  "Invalid callback URL: missing authorization code. Please paste the full redirect URL including the code parameter.",
                );
              else {
                (f6.add(I6), T6(W6));
                let F6 = y6.get(I6);
                if (F6)
                  try {
                    (await F6, a(P6));
                  } catch (U6) {
                    s(
                      P6,
                      U6 instanceof Error
                        ? U6.message
                        : "OAuth authentication failed",
                    );
                  }
                else a(P6);
              }
            } else s(P6, `No active OAuth flow for server: ${I6}`);
          } else if (P6.request.subtype === "claude_authenticate") {
            let { loginWithClaudeAi: I6 } = P6.request;
            (v6?.service.cleanup(),
              Q("tengu_oauth_flow_start", { loginWithClaudeAi: I6 ?? !0 }));
            let W6 = new yl(),
              T6,
              h6 = new Promise((U6) => {
                T6 = U6;
              }),
              F6 = W6.startOAuthFlow(
                async (U6, k6) => {
                  T6({ manualUrl: U6, automaticUrl: k6 });
                },
                { loginWithClaudeAi: I6 ?? !0, skipBrowserOpen: !0 },
              )
                .then(async (U6) => {
                  (await wz6(U6),
                    Q("tengu_oauth_success", { loginWithClaudeAi: I6 ?? !0 }));
                })
                .finally(() => {
                  if ((W6.cleanup(), v6?.service === W6)) v6 = null;
                });
            ((v6 = { service: W6, flow: F6 }),
              F6.catch((U6) =>
                V(`claude_authenticate flow ended: ${U6}`, { level: "info" }),
              ));
            try {
              let { manualUrl: U6, automaticUrl: k6 } = await Promise.race([
                h6,
                F6.then(() => {
                  throw Error(
                    "OAuth flow completed without producing auth URLs",
                  );
                }),
              ]);
              a(P6, { manualUrl: U6, automaticUrl: k6 });
            } catch (U6) {
              s(P6, r6(U6));
            }
          } else if (
            P6.request.subtype === "claude_oauth_callback" ||
            P6.request.subtype === "claude_oauth_wait_for_completion"
          )
            if (!v6) s(P6, "No active claude_authenticate flow");
            else {
              if (P6.request.subtype === "claude_oauth_callback")
                v6.service.handleManualAuthCodeInput({
                  authorizationCode: P6.request.authorizationCode,
                  state: P6.request.state,
                });
              let { flow: I6 } = v6;
              I6.then(
                () => {
                  let W6 = kP6();
                  a(P6, {
                    account: {
                      email: W6?.email,
                      organization: W6?.organization,
                      subscriptionType: W6?.subscription,
                      tokenSource: W6?.tokenSource,
                      apiKeySource: W6?.apiKeySource,
                      apiProvider: gA(),
                    },
                  });
                },
                (W6) => s(P6, r6(W6)),
              );
            }
          else if (P6.request.subtype === "mcp_clear_auth") {
            let { serverName: I6 } = P6.request,
              W6 = O(),
              T6 =
                Gk(I6) ??
                q.find((h6) => h6.name === I6)?.config ??
                W6.mcp.clients.find((h6) => h6.name === I6)?.config ??
                null;
            if (!T6) s(P6, `Server not found: ${I6}`);
            else if (T6.type !== "sse" && T6.type !== "http")
              s(P6, `Cannot clear auth for server type "${T6.type}"`);
            else {
              await Bd6(I6, T6);
              let h6 = await Tl(I6, T6),
                F6 = VC(I6);
              ($((U6) => ({
                ...U6,
                mcp: {
                  ...U6.mcp,
                  clients: U6.mcp.clients.map((k6) =>
                    k6.name === I6 ? h6.client : k6,
                  ),
                  tools: [
                    ...qN(U6.mcp.tools, (k6) => k6.name?.startsWith(F6)),
                    ...h6.tools,
                  ],
                  commands: [
                    ...qN(U6.mcp.commands, (k6) => k6.name?.startsWith(F6)),
                    ...h6.commands,
                  ],
                  resources:
                    h6.resources && h6.resources.length > 0
                      ? { ...U6.mcp.resources, [I6]: h6.resources }
                      : C16(U6.mcp.resources, I6),
                },
              })),
                a(P6, {}));
            }
          } else if (P6.request.subtype === "apply_flag_settings") {
            let I6 = H$6() ?? {},
              W6 = P6.request.settings;
            (GB8({ ...I6, ...W6 }), AX.notifyChange("flagSettings"), a(P6));
          } else if (P6.request.subtype === "get_settings") {
            let I6 = O(),
              W6 = vK(),
              T6 = iV(W6) ? LP6(W6, I6.effortValue) : void 0;
            a(P6, {
              ...lPA(),
              applied: {
                model: W6,
                effort: typeof T6 === "string" ? T6 : null,
              },
            });
          } else if (P6.request.subtype === "stop_task") {
            let { task_id: I6 } = P6.request;
            try {
              (await yL8(I6, { getAppState: O, setAppState: $ }), a(P6, {}));
            } catch (W6) {
              s(P6, r6(W6));
            }
          } else if (P6.request.subtype === "generate_session_title") {
            let { description: I6, persist: W6 } = P6.request,
              T6 = (W && !W.signal.aborted ? W : k5()).signal;
            (async () => {
              try {
                let h6 = await Px8(I6, T6);
                if (h6 && W6)
                  try {
                    Ks1(y8(), h6);
                  } catch (F6) {
                    $6(F6);
                  }
                a(P6, { title: h6 });
              } catch (h6) {
                s(P6, r6(h6));
              }
            })();
          } else if (P6.request.subtype === "side_question") {
            let { question: I6 } = P6.request;
            (async () => {
              try {
                let W6 = Pr6();
                if (!W6) {
                  a(P6, { response: null });
                  return;
                }
                let T6 = await kh8({
                  question: I6,
                  cacheSafeParams: {
                    ...W6,
                    toolUseContext: {
                      ...W6.toolUseContext,
                      abortController: k5(),
                    },
                  },
                });
                a(P6, { response: T6.response });
              } catch (W6) {
                s(P6, r6(W6));
              }
            })();
          } else if (P6.request.subtype === "remote_control")
            if (P6.request.enabled)
              if (d)
                a(P6, {
                  session_url: nD(d.bridgeSessionId, d.sessionIngressUrl),
                  connect_url: i66(d.environmentId, d.sessionIngressUrl),
                  environment_id: d.environmentId,
                });
              else {
                let I6;
                try {
                  let { initReplBridge: W6 } = await Promise.resolve().then(
                      () => (Bt1(), mt1),
                    ),
                    T6 = await W6({
                      onInboundMessage(h6) {
                        let F6 = Gb8(h6);
                        if (!F6) return;
                        let { content: U6, uuid: k6 } = F6;
                        (qX({
                          value: U6,
                          mode: "prompt",
                          uuid: k6,
                          skipSlashCommands: !0,
                        }),
                          n());
                      },
                      onPermissionResponse(h6) {
                        A.injectControlResponse(h6);
                      },
                      onInterrupt() {
                        W?.abort();
                      },
                      onSetModel(h6) {
                        let F6 = h6 === "default" ? q0() : h6;
                        ((m = F6), SW(F6));
                      },
                      onSetMaxThinkingTokens(h6) {
                        if (h6 === null) j.thinkingConfig = void 0;
                        else if (h6 === 0)
                          j.thinkingConfig = { type: "disabled" };
                        else
                          j.thinkingConfig = {
                            type: "enabled",
                            budgetTokens: h6,
                          };
                      },
                      onStateChange(h6, F6) {
                        if (h6 === "failed") I6 = F6;
                        (V(
                          `[bridge:sdk] State change: ${h6}${F6 ? ` — ${F6}` : ""}`,
                        ),
                          f.enqueue({
                            type: "system",
                            subtype: "bridge_state",
                            state: h6,
                            detail: F6,
                            uuid: mX(),
                            session_id: y8(),
                          }));
                      },
                      initialMessages: k.length > 0 ? k : void 0,
                    });
                  if (!T6) s(P6, I6 ?? "Remote Control initialization failed");
                  else
                    ((d = T6),
                      (r = k.length),
                      A.setOnControlRequestSent((h6) => {
                        T6.sendControlRequest(h6);
                      }),
                      A.setOnControlRequestResolved((h6) => {
                        T6.sendControlCancelRequest(h6);
                      }),
                      a(P6, {
                        session_url: nD(
                          T6.bridgeSessionId,
                          T6.sessionIngressUrl,
                        ),
                        connect_url: i66(
                          T6.environmentId,
                          T6.sessionIngressUrl,
                        ),
                        environment_id: T6.environmentId,
                      }));
                } catch (W6) {
                  s(P6, r6(W6));
                }
              }
            else {
              if (d)
                (A.setOnControlRequestSent(void 0),
                  A.setOnControlRequestResolved(void 0),
                  await d.teardown(),
                  (d = null));
              a(P6);
            }
          else
            s(P6, `Unsupported control request subtype: ${P6.request.subtype}`);
          continue;
        } else if (P6.type === "control_response") {
          if (j.replayUserMessages) f.enqueue(P6);
          continue;
        } else if (P6.type === "keep_alive") continue;
        else if (P6.type === "update_environment_variables") continue;
        else if (P6.type === "assistant" || P6.type === "system") {
          let I6 = yC8([P6]);
          if ((k.push(...I6), P6.type === "assistant" && j.replayUserMessages))
            f.enqueue(P6);
          continue;
        }
        if (P6.type !== "user") continue;
        if (((V6 = !0), P6.uuid)) {
          let I6 = y8(),
            W6 = await zs1(I6, P6.uuid);
          if (W6 || ku8.has(P6.uuid)) {
            if (
              (V(`Skipping duplicate user message: ${P6.uuid}`),
              j.replayUserMessages)
            )
              (V(
                `Sending acknowledgment for duplicate user message: ${P6.uuid}`,
              ),
                f.enqueue({
                  type: "user",
                  message: P6.message,
                  session_id: I6,
                  parent_tool_use_id: null,
                  uuid: P6.uuid,
                  timestamp: P6.timestamp,
                  isReplay: !0,
                }));
            if (W6) ng(P6.uuid, "completed");
            continue;
          }
          cN_(P6.uuid);
        }
        (qX({
          mode: "prompt",
          value: await gt1(P6, P6.message.content),
          uuid: P6.uuid,
          priority: P6.priority,
        }),
          n());
      }
      if (((X = !0), A6?.stop(), !M)) {
        if (G.inflightPromise)
          await Promise.race([
            G.inflightPromise,
            new Promise((P6) => setTimeout(P6, 5000)),
          ]);
        (G.abortController?.abort(),
          (G.abortController = null),
          await WN1(),
          X6(),
          D66.delete(v),
          f.done());
      }
    })(),
    f
  );
}
