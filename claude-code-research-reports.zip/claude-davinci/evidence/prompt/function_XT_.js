function XT_(A) {
  return { ...A, hasTrustDialogAccepted: !0 };
}
