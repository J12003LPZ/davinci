function MB(A) {
  let q = n1();
  if (A === "ExperimentalUltraClaudeMd") return MB("User");
  switch (A) {
    case "User":
      return PG(d1(), "CLAUDE.md");
    case "Local":
      return PG(q, "CLAUDE.local.md");
    case "Project":
      return PG(q, "CLAUDE.md");
    case "Managed":
      return PG(uW(), "CLAUDE.md");
    case "ExperimentalUltraClaudeMd":
      return PG(d1(), "ULTRACLAUDE.md");
    case "AutoMem":
      return v48();
  }
  return va3.getTeamMemEntrypoint();
}
