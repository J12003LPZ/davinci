function Q5(A) {
  return A.map((q) => {
    if (typeof q.message.content === "string")
      return {
        ...q,
        message: { ...q.message, content: Ov(q.message.content) },
      };
    else if (Array.isArray(q.message.content)) {
      let K = q.message.content.map((Y) => {
        if (Y.type === "text") return { ...Y, text: Ov(Y.text) };
        return Y;
      });
      return { ...q, message: { ...q.message, content: K } };
    }
    return q;
  });
}
