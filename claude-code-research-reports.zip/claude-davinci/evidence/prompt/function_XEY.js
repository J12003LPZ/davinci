async function XEY(A, q, K, Y, _ = []) {
  let z = gp(A, K);
  if (!z) throw new hu(`Unknown command: ${A}`);
  if (z.type !== "prompt")
    throw Error(
      `Unexpected ${z.type} command. Expected 'prompt' command. Use /${A} directly in the main conversation.`,
    );
  return Ds4(z, q, Y, [], _);
}
