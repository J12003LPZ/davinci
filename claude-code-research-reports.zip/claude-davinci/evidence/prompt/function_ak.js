function ak(A) {
  let q = A.filter((H) => H.source === "built-in"),
    K = A.filter((H) => H.source === "plugin"),
    Y = A.filter((H) => H.source === "userSettings"),
    _ = A.filter((H) => H.source === "projectSettings"),
    z = A.filter((H) => H.source === "policySettings"),
    w = A.filter((H) => H.source === "flagSettings"),
    O = [q, K, Y, _, w, z],
    $ = new Map();
  for (let H of O) for (let j of H) $.set(j.agentType, j);
  return Array.from($.values());
}
