function d_() {
  return (lC7 ||= Na3());
}
