async function* kk({
  agentDefinition: A,
  promptMessages: q,
  toolUseContext: K,
  canUseTool: Y,
  isAsync: _,
  canShowPermissionPrompts: z,
  forkContextMessages: w,
  querySource: O,
  override: $,
  model: H,
  maxTurns: j,
  preserveToolUseResults: J,
  availableTools: M,
  allowedTools: X,
  onCacheSafeParams: D,
  contentReplacementState: P,
  useExactTools: W,
  worktreePath: f,
  description: Z,
  transcriptSubdir: G,
  onQueryProgress: v,
}) {
  let k = K.getAppState(),
    N = k.toolPermissionContext.mode,
    E = K.setAppStateForTasks ?? K.setAppState,
    h = cZ6(A.model, K.options.mainLoopModel, H, N),
    R = $?.agentId ? $.agentId : mI();
  if (G) Fg1(R, G);
  if (Ec()) {
    let n = K.agentId ?? y8();
    fP8(R, A.agentType, n);
  }
  let I = [...(w ? gR1(w) : []), ...q],
    g = w !== void 0 ? $b(K.readFileState) : xc(bc),
    [u, b] = await Promise.all([
      $?.userContext ?? kz(),
      $?.systemContext ?? i2(),
    ]),
    p = A.permissionMode,
    U = () => {
      let n = K.getAppState(),
        A6 = n.toolPermissionContext;
      if (
        p &&
        n.toolPermissionContext.mode !== "bypassPermissions" &&
        n.toolPermissionContext.mode !== "acceptEdits" &&
        n.toolPermissionContext.mode !== "auto"
      )
        A6 = { ...A6, mode: p };
      let a = z !== void 0 ? !z : p === "bubble" ? !1 : _;
      if (a) A6 = { ...A6, shouldAvoidPermissionPrompts: !0 };
      if (_ && !a) A6 = { ...A6, awaitAutomatedChecksBeforeDialog: !0 };
      if (X !== void 0)
        A6 = {
          ...A6,
          alwaysAllowRules: {
            cliArg: n.toolPermissionContext.alwaysAllowRules.cliArg,
            session: [...X],
          },
        };
      let s = A.effort !== void 0 ? A.effort : n.effortValue;
      if (A6 === n.toolPermissionContext && s === n.effortValue) return n;
      return { ...n, toolPermissionContext: A6, effortValue: s };
    },
    d = W ? M : Dl(A, M, _).resolvedTools,
    r = Array.from(k.toolPermissionContext.additionalWorkingDirectories.keys()),
    t = $?.systemPrompt ? $.systemPrompt : iq(await fEY(A, K, h, r, d)),
    e = $?.abortController
      ? $.abortController
      : _
        ? new AbortController()
        : K.abortController,
    q6 = [];
  for await (let n of pg1(R, A.agentType, e.signal))
    if (n.additionalContexts && n.additionalContexts.length > 0)
      q6.push(...n.additionalContexts);
  if (q6.length > 0) {
    let n = V4({
      type: "hook_additional_context",
      content: q6,
      hookName: "SubagentStart",
      toolUseID: DEY(),
      hookEvent: "SubagentStart",
    });
    I.push(n);
  }
  if (A.hooks) cf4(E, R, A.hooks, `agent '${A.agentType}'`, !0);
  let H6 = A.skills ?? [];
  if (H6.length > 0) {
    let n = await vh(G9()),
      A6 = [];
    for (let O6 of H6) {
      let J6 = ZEY(O6, n, A);
      if (!J6) {
        V(
          `[Agent: ${A.agentType}] Warning: Skill '${O6}' specified in frontmatter was not found`,
          { level: "warn" },
        );
        continue;
      }
      let Z6 = XT6(J6, n);
      if (Z6.type !== "prompt") {
        V(
          `[Agent: ${A.agentType}] Warning: Skill '${O6}' is not a prompt-based skill`,
          { level: "warn" },
        );
        continue;
      }
      A6.push({ skillName: O6, skill: Z6 });
    }
    let { formatSkillLoadingMetadata: a } = await Promise.resolve().then(
        () => (XE8(), ME8),
      ),
      s = await Promise.all(
        A6.map(async ({ skillName: O6, skill: J6 }) => ({
          skillName: O6,
          skill: J6,
          content: await J6.getPromptForCommand("", K),
        })),
      );
    for (let { skillName: O6, skill: J6, content: Z6 } of s) {
      V(`[Agent: ${A.agentType}] Preloaded skill '${O6}'`);
      let f6 = a(O6, J6.progressMessage);
      I.push(g8({ content: [{ type: "text", text: f6 }, ...Z6] }));
    }
  }
  let {
      clients: K6,
      tools: o,
      cleanup: j6,
    } = await PEY(A, K.options.mcpClients),
    z6 = o.length > 0 ? ij([...d, ...o], "name") : d,
    G6 = {
      isNonInteractiveSession: W
        ? K.options.isNonInteractiveSession
        : _
          ? !0
          : (K.options.isNonInteractiveSession ?? !1),
      appendSystemPrompt: K.options.appendSystemPrompt,
      tools: z6,
      commands: [],
      debug: K.options.debug,
      verbose: K.options.verbose,
      mainLoopModel: h,
      thinkingConfig: W ? K.options.thinkingConfig : { type: "disabled" },
      mcpClients: K6,
      mcpResources: K.options.mcpResources,
      agentDefinitions: K.options.agentDefinitions,
      ...(W && { querySource: O }),
    },
    X6 = ri6(K, {
      options: G6,
      agentId: R,
      agentType: A.agentType,
      messages: I,
      readFileState: g,
      abortController: e,
      getAppState: U,
      shareSetAppState: !_,
      shareSetResponseLength: !0,
      criticalSystemReminder_EXPERIMENTAL:
        A.criticalSystemReminder_EXPERIMENTAL,
      contentReplacementState: P,
    });
  if (J) X6.preserveToolUseResults = !0;
  if (D)
    D({
      systemPrompt: t,
      userContext: u,
      systemContext: b,
      toolUseContext: X6,
      forkContextMessages: I,
    });
  (await Fp(I, R).catch((n) =>
    V(`Failed to record sidechain transcript: ${n}`),
  ),
    await ai6(R, {
      agentType: A.agentType,
      ...(f && { worktreePath: f }),
      ...(Z && { description: Z }),
    }).catch((n) => V(`Failed to write agent metadata: ${n}`)));
  let c = I.length > 0 ? I[I.length - 1].uuid : null;
  try {
    for await (let n of th({
      messages: I,
      systemPrompt: t,
      userContext: u,
      systemContext: b,
      canUseTool: Y,
      toolUseContext: X6,
      querySource: O,
      maxTurns: j ?? A.maxTurns,
    })) {
      if (
        (v?.(),
        n.type === "stream_event" &&
          n.event.type === "message_start" &&
          n.ttftMs != null)
      ) {
        K.pushApiMetricsEntry?.(n.ttftMs);
        continue;
      }
      if (n.type === "attachment") {
        if (n.attachment.type === "max_turns_reached") {
          V(`[Agent
: $
{
  agentDefinition.agentType
}
