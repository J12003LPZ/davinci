async function oyY(A, q, K, Y, _, z, w) {
  let O = Date.now(),
    $ = mI(),
    H = Bp().has(q),
    j = Ft4(A),
    J = A.source === "bundled";
  Q("tengu_skill_tool_invocation", {
    command_name: H || J || j ? q : "custom",
    _PROTO_skill_name: q,
    execution_context: "fork",
    ...{},
    ...!1,
    ...(A.pluginInfo && {
      plugin_name: j ? A.pluginInfo.pluginManifest.name : "third-party",
      plugin_repository: j ? A.pluginInfo.repository : "third-party",
    }),
  });
  let {
      modifiedGetAppState: D,
      baseAgent: P,
      promptMessages: W,
      skillContent: f,
    } = await DE8(A, K || "", Y),
    Z = A.effort !== void 0 ? { ...P, effort: A.effort } : P,
    G = [];
  V(`SkillTool executing forked skill ${q} with agent ${Z.agentType}`);
  try {
    for await (let N of kk({
      agentDefinition: Z,
      promptMessages: W,
      toolUseContext: { ...Y, getAppState: D },
      canUseTool: _,
      isAsync: !1,
      querySource: "agent:custom",
      model: A.model,
      availableTools: Y.options.tools,
      override: { agentId: $ },
    }))
      if ((G.push(N), (N.type === "assistant" || N.type === "user") && w)) {
        let E = vM([N]);
        for (let h of E)
          if (
            h.message.content.some(
              (m) => m.type === "tool_use" || m.type === "tool_result",
            )
          )
            w({
              toolUseID: `skill_${z.message.id}`,
              data: {
                message: h,
                type: "skill_progress",
                prompt: f,
                agentId: $,
              },
            });
      }
    let v = PE8(G, "Skill execution completed");
    G.length = 0;
    let k = Date.now() - O;
    return (
      V(`SkillTool forked skill ${q} completed in ${k}ms`),
      {
        data: {
          success: !0,
          commandName: q,
          status: "forked",
          agentId: $,
          result: v,
        },
      }
    );
  } finally {
    yr($);
  }
}
