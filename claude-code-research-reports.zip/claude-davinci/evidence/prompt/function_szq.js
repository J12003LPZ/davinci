async function szq(A, q, K, Y, _, z, w, O, $, H, j, J) {
  if (Y === "ipynb") {
    let E = await H54(K),
      h = m6(E),
      R = Buffer.byteLength(h);
    if (R > O)
      throw Error(`Notebook content (${Sq(R)}) exceeds maximum allowed size (${Sq(O)}). Use ${E7} with jq to read specific portions:
  cat "${A}" | jq '.cells[:20]' # First 20 cells
  cat "${A}" | jq '.cells[100:120]' # Cells 100-120
  cat "${A}" | jq '.cells | length' # Count total cells
  cat "${A}" | jq '.cells[] | select(.cell_type=="code") | .source' # All code sources`);
    await ozq(h, Y, $);
    let m = await O8().stat(K);
    (H.set(q, {
      content: h,
      timestamp: Math.floor(m.mtimeMs),
      offset: _,
      limit: z,
    }),
      j.nestedMemoryAttachmentTriggers?.add(q));
    let I = { type: "notebook", file: { filePath: A, cells: E } };
    return (
      Jx({ operation: "read", tool: "FileReadTool", filePath: q, content: h }),
      { data: I }
    );
  }
  if (tzq.has(Y)) {
    let E = await ac1(K, $);
    (j.nestedMemoryAttachmentTriggers?.add(q),
      Jx({
        operation: "read",
        tool: "FileReadTool",
        filePath: q,
        content: E.file.base64,
      }));
    let h = E.file.dimensions ? vf6(E.file.dimensions) : null;
    return {
      data: E,
      ...(h && { newMessages: [g8({ content: h, isMeta: !0 })] }),
    };
  }
  if (VP6(Y)) {
    if (w) {
      let u = xD1(w),
        b = await MV1(K, u ?? void 0);
      if (!b.success) throw Error(b.error.message);
      (Q("tengu_pdf_page_extraction", {
        success: !0,
        pageCount: b.data.file.count,
        fileSize: b.data.file.originalSize,
        hasPageRange: !0,
      }),
        Jx({
          operation: "read",
          tool: "FileReadTool",
          filePath: q,
          content: `PDF pages ${w}`,
        }));
      let U = (await mdY(b.data.file.outputDir))
          .filter((r) => r.endsWith(".jpg"))
          .sort(),
        d = await Promise.all(
          U.map(async (r) => {
            let t = Dw6.join(b.data.file.outputDir, r),
              e = await BdY(t),
              q6 = await JE(e, e.length, "jpeg");
            return {
              type: "image",
              source: {
                type: "base64",
                media_type: `image/${q6.mediaType}`,
                data: q6.buffer.toString("base64"),
              },
            };
          }),
        );
      return {
        data: b.data,
        ...(d.length > 0 && { newMessages: [g8({ content: d, isMeta: !0 })] }),
      };
    }
    let E = await D08(K);
    if (E !== null && E > q08)
      throw Error(
        `This PDF has ${E} pages, which is too many to read at once. Use the pages parameter to read specific page ranges (e.g., pages: "1-5"). Maximum ${m96} pages per request.`,
      );
    let R = await O8().stat(K);
    if (!lB6() || R.size > EK4) {
      let u = await MV1(K);
      if (u.success)
        Q("tengu_pdf_page_extraction", {
          success: !0,
          pageCount: u.data.file.count,
          fileSize: u.data.file.originalSize,
        });
      else
        Q("tengu_pdf_page_extraction", {
          success: !1,
          available: u.error.reason !== "unavailable",
          fileSize: R.size,
        });
    }
    if (!lB6())
      throw Error(
        `Reading full PDFs is not supported with this model. Use a newer model (Sonnet 3.5 v2 or later), or use the pages parameter to read specific page ranges (e.g., pages: "1-5", maximum ${m96} pages per request). Page extraction requires poppler-utils: install with \`brew install poppler\` on macOS or \`apt-get install poppler-utils\` on Debian/Ubuntu.`,
      );
    let I = await y54(K);
    if (!I.success) throw Error(I.error.message);
    let g = I.data;
    return (
      Jx({
        operation: "read",
        tool: "FileReadTool",
        filePath: q,
        content: g.file.base64,
      }),
      {
        data: g,
        newMessages: [
          g8({
            content: [
              {
                type: "document",
                source: {
                  type: "base64",
                  media_type: "application/pdf",
                  data: g.file.base64,
                },
              },
            ],
            isMeta: !0,
          }),
        ],
      }
    );
  }
  let M = _ === 0 ? 0 : _ - 1,
    {
      content: X,
      lineCount: D,
      totalLines: P,
      totalBytes: W,
      readBytes: f,
      mtimeMs: Z,
    } = await B96(K, M, z, z === void 0 ? O : void 0, j.abortController.signal);
  (await ozq(X, Y, $),
    H.set(q, { content: X, timestamp: Math.floor(Z), offset: _, limit: z }),
    j.nestedMemoryAttachmentTriggers?.add(q));
  for (let E of ldY) E(K, X);
  let G = {
    type: "text",
    file: { filePath: A, content: X, numLines: D, startLine: _, totalLines: P },
  };
  if (NZ6(q)) ezq.set(G, Z);
  Jx({ operation: "read", tool: "FileReadTool", filePath: q, content: X });
  let v = idY(q),
    k = S56(q),
    N = gdY("sha256").update(q).digest("hex").slice(0, 16);
  return (
    Q("tengu_session_file_read", {
      totalLines: P,
      readLines: D,
      totalBytes: W,
      readBytes: f,
      offset: _,
      ...(z !== void 0 && { limit: z }),
      ...(k !== void 0 && { ext: k }),
      ph: N,
      ...(J !== void 0 && { messageID: J }),
      is_session_memory: v === "session_memory",
      is_session_transcript: v === "session_transcript",
    }),
    { data: G }
  );
}
