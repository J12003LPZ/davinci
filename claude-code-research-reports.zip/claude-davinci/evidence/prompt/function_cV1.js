async function cV1() {
  let A = ow();
  if (
    A.hasClaudeMdExternalIncludesApproved ||
    A.hasClaudeMdExternalIncludesWarningShown
  )
    return !1;
  return x08(await hO(!0));
}
