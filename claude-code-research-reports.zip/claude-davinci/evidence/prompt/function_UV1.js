async function UV1(A, q) {
  let K = [],
    Y = c$8();
  if ((K.push(...(await VU6(A, Y, "Managed", q, !1))), gH("userSettings"))) {
    let _ = l$8();
    K.push(...(await VU6(A, _, "User", q, !0)));
  }
  return K;
}
