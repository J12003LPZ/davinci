function HZ8(A, q, K, Y) {
  if (!gf6()) return [];
  let _ = [];
  if (TE() && lr6(K) && Aw6(q)) _.push({ serverName: fk, block: oR8 });
  let z = l94(A, Y ?? [], _);
  if (!z) return [];
  return [{ type: "mcp_instructions_delta", ...z }];
}
