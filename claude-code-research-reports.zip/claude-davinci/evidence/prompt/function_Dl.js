function Dl(A, q, K = !1, Y = !1) {
  let { tools: _, disallowedTools: z, source: w, permissionMode: O } = A,
    $ = Y
      ? q
      : pR1({
          tools: q,
          isBuiltIn: w === "built-in",
          isAsync: K,
          permissionMode: O,
        }),
    H = new Set(
      z?.map((Z) => {
        let { toolName: G } = pH(Z);
        return G;
      }) ?? [],
    ),
    j = $.filter((Z) => !H.has(Z.name));
  if (_ === void 0 || (_.length === 1 && _[0] === "*"))
    return {
      hasWildcard: !0,
      validTools: [],
      invalidTools: [],
      resolvedTools: j,
    };
  let M = new Map();
  for (let Z of j) M.set(Z.name, Z);
  let X = [],
    D = [],
    P = [],
    W = new Set(),
    f;
  for (let Z of _) {
    let { toolName: G, ruleContent: v } = pH(Z);
    if (G === Aq) {
      if (v) f = v.split(",").map((N) => N.trim());
      if (!Y) {
        X.push(Z);
        continue;
      }
    }
    let k = M.get(G);
    if (k) {
      if ((X.push(Z), !W.has(k))) (P.push(k), W.add(k));
    } else D.push(Z);
  }
  return {
    hasWildcard: !1,
    validTools: X,
    invalidTools: D,
    resolvedTools: P,
    allowedAgentTypes: f,
  };
}
