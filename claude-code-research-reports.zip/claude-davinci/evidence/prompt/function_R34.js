function R34(A) {
  let { displayName: q, memoryDir: K, extraGuidelines: Y } = A,
    _ = O8(),
    z = K + I_,
    w = "";
  try {
    w = _.readFileSync(z, { encoding: "utf-8" });
  } catch {}
  let O = [
    `# ${q}`,
    "",
    `You have a persistent ${q} directory at \`${K}\`. ${kU6} Its contents persist across conversations.`,
    "",
    `As you work, consult your memory files to build on previous experience. When you encounter a mistake that seems like it could be common, check your ${q} for relevant notes — and if nothing is written yet, record what you learned.`,
    "",
    "Guidelines:",
    `- \`${I_}\` is always loaded into your system prompt — lines after ${HH} will be truncated, so keep it concise`,
    "- Create separate topic files (e.g., `debugging.md`, `patterns.md`) for detailed notes and link to them from MEMORY.md",
    "- Update or remove memories that turn out to be wrong or outdated",
    "- Organize memory semantically by topic, not chronologically",
    "- Use the Write and Edit tools to update your memory files",
    "",
    "What to save:",
    "- Stable patterns and conventions confirmed across multiple interactions",
    "- Key architectural decisions, important file paths, and project structure",
    "- User preferences for workflow, tools, and communication style",
    "- Solutions to recurring problems and debugging insights",
    "",
    "What NOT to save:",
    "- Session-specific context (current task details, in-progress work, temporary state)",
    "- Information that might be incomplete — verify against project docs before writing",
    "- Anything that duplicates or contradicts existing CLAUDE.md instructions",
    "- Speculative or unverified conclusions from reading a single file",
    "",
    "Explicit user requests:",
    '- When the user asks you to remember something across sessions (e.g., "always use bun", "never auto-commit"), save it — no need to wait for multiple interactions',
    "- When the user asks to forget or stop remembering something, find and remove the relevant entries from your memory files",
    "- When the user corrects you on something you stated from memory, you MUST update or remove the incorrect entry. A correction means the stored memory is wrong — fix it at the source before continuing, so the same mistake does not repeat in future conversations.",
    ...(Y ?? []),
    "",
  ];
  if ((O.push(...Ue(K)), w.trim())) {
    let $ = w.trim().split(`
`),
      H = $.length > HH,
      j = q === L34 ? "auto" : "agent";
    TU6(K, {
      content_length: w.length,
      line_count: $.length,
      was_truncated: H,
      memory_type: j,
    });
    let J = w.trim();
    if (H)
      J =
        $.slice(0, HH).join(`
`) +
        `

> WARNING: ${I_} is ${$.length} lines (limit: ${HH}). Only the first ${HH} lines were loaded. Move detailed content into separate topic files and keep ${I_} as a concise index.`;
    O.push(`## ${I_}`, "", J);
  } else
    O.push(
      `## ${I_}`,
      "",
      `Your ${I_} is currently empty. When you notice a pattern worth preserving across sessions, save it here. Anything in ${I_} will be included in your system prompt next time.`,
    );
  return O.join(`
`);
}
