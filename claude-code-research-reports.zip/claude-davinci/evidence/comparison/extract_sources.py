"""Read-only LF-indexed source snapshots for the Wave 3 comparison."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/workspace/davinci')
OUT = Path(__file__).resolve().parent
PIN = '53e999a7fc24c721c484a710093eeeff611641bf'
SLICES = {
    'turn_loop': ('crates/davinci-agent/src/turn.rs', [(333, 489), (593, 645), (694, 1054)]),
    'turn_retry': ('crates/davinci-agent/src/turn.rs', [(1194, 1369)]),
    'turn_dispatch': ('crates/davinci-agent/src/turn.rs', [(1496, 1618), (1769, 1850), (1951, 2371), (2383, 2525), (2960, 3136), (3158, 3315), (3954, 4215)]),
    'ledger': ('crates/davinci-agent/src/tool_ledger.rs', [(762, 1010)]),
    'scheduler': ('crates/davinci-agent/src/scheduler.rs', [(70, 285)]),
    'operation_dispatcher': ('crates/davinci-agent/src/runtime/operations/adapters/tools.rs', [(60, 327)]),
    'recovery': ('crates/davinci-agent/src/runtime/operations/recovery.rs', [(15, 172), (177, 330)]),
    'completion': ('crates/davinci-agent/src/completion.rs', [(246, 435)]),
    'completion_gate': ('crates/davinci-agent/src/prompt/capabilities/gate.rs', [(59, 134)]),
    'agent_context': ('crates/davinci-agent/src/lib.rs', [(1695, 1749), (1779, 1805), (2459, 2499), (2627, 2683), (3792, 3815), (3845, 3907), (3950, 4180)]),
    'turn_context': ('crates/davinci-agent/src/turn_context.rs', [(21, 161)]),
    'prompt_turn': ('crates/davinci-agent/src/prompt/turn.rs', [(19, 144)]),
    'prompt_session': ('crates/davinci-agent/src/prompt/session.rs', [(8, 152), (177, 240)]),
    'context_loader': ('crates/davinci-agent/src/context.rs', [(47, 116)]),
    'compaction': ('crates/davinci-agent/src/compaction.rs', [(133, 209), (229, 278), (302, 413)]),
    'context_vm_mode': ('crates/davinci-agent/src/runtime/context_vm/types.rs', [(6, 52)]),
    'cache_prefix': ('crates/davinci-agent/src/cache_stability.rs', [(18, 69)]),
    'events': ('crates/davinci-agent/src/events.rs', [(5, 59)]),
    'subagent': ('crates/davinci-agent/src/subagent.rs', [(302, 398), (661, 1028), (1030, 1218), (1361, 1400)]),
    'worktree': ('crates/davinci-agent/src/runtime/worktree.rs', [(285, 389)]),
    'team': ('crates/davinci-agent/src/runtime/team.rs', [(35, 183), (288, 375), (407, 484)]),
    'mailbox': ('crates/davinci-agent/src/runtime/mailbox.rs', [(231, 369), (615, 675), (698, 750)]),
    'tasks': ('crates/davinci-agent/src/runtime/tasks.rs', [(922, 1048), (1465, 1625)]),
    'task_tools': ('crates/davinci-agent/src/runtime/tools_task.rs', [(153, 180), (290, 445)]),
    'host_main': ('crates/davinci-coding-agent/src/main.rs', [(882, 930), (1180, 1254), (2433, 2681), (2693, 2779), (4476, 4537)]),
    'host_settings': ('crates/davinci-coding-agent/src/settings.rs', [(1441, 1464)]),
    'codex_transport': ('crates/davinci-ai/src/codex.rs', [(123, 133), (472, 536), (582, 668), (742, 816)]),
    'codex_capabilities': ('crates/davinci-ai/src/codex_capabilities.rs', [(53, 169)]),
    'stream_route': ('crates/davinci-ai/src/stream.rs', [(940, 1074), (1140, 1172), (1683, 1740), (2179, 2245)]),
    'public_ws': ('crates/davinci-ai/src/codex_ws.rs', [(1224, 1234), (1490, 1505)]),
    'responses_decoder': ('crates/davinci-ai/src/stream_decoder.rs', [(811, 884), (956, 991)]),
    'wire_manifest': ('crates/davinci-ai/src/responses_request.rs', [(58, 145)]),
    'subscription_policy': ('crates/davinci-ai/src/subscription_policy.rs', [(12, 88)]),
}

def main():
    head = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    assert head == PIN, (head, PIN)
    index = {'pin': head, 'method': 'UTF-8 split on LF only; inclusive one-based spans', 'sources': []}
    for name, (relative, spans) in SLICES.items():
        source = ROOT / relative
        raw = source.read_bytes()
        lines = raw.decode('utf-8').split('\n')
        excerpt = ''.join(f'### {relative}:{start}-{end}\n' + ''.join(f'{i+1}: {lines[i]}\n' for i in range(start-1, end)) for start, end in spans)
        target = OUT / (name + '.txt')
        target.write_text(excerpt)
        index['sources'].append({'path': relative, 'sha256': hashlib.sha256(raw).hexdigest(), 'spans': spans, 'excerpt': target.name, 'excerpt_sha256': hashlib.sha256(excerpt.encode()).hexdigest()})
    (OUT / 'source_index.json').write_text(json.dumps(index, indent=2) + '\n')
    patterns = [r'recover_attempt\(', r'RecoveryEngine::run_authorized|RecoveryEngine::reduce']
    for i, pattern in enumerate(patterns):
        result = subprocess.run(['rg', '-n', pattern, str(ROOT / 'crates'), '--glob', '*.rs'], capture_output=True, text=True)
        (OUT / f'callers_{i}.txt').write_text(result.stdout + result.stderr)
    status = subprocess.check_output(['git', '-C', str(ROOT), 'status', '--short'], text=True)
    (OUT / 'inspection.json').write_text(json.dumps({'head': head, 'git_status_short': status, 'tests_run': [], 'provider_calls': [], 'rtk': 'not present in PATH; raw shell used', 'commands': ['python3 evidence/comparison/extract_sources.py', 'git -C /workspace/davinci rev-parse HEAD', 'git -C /workspace/davinci status --short', 'rg callers recorded in callers_*.txt']}, indent=2) + '\n')
    print(f'Indexed {len(SLICES)} source files at {head}; git status entries: {len(status.splitlines())}; no tests or provider calls.')

if __name__ == '__main__':
    main()
