# Experiment evidence index

The authoritative full run set is `runs/rerun-final/` (EXP-01 through EXP-14), summarized by [`summary-rerun-final.json`](summary-rerun-final.json). EXP-15 is a targeted follow-up in `runs/rerun-memory/`, summarized by [`summary-rerun-memory.json`](summary-rerun-memory.json). Each `result.json` is the canonical per-scenario record: exact CLI args/cwd/Node version, isolated environment names and safe values, timestamps, captured HTTP request/response JSON and SSE bytes, stdout/stderr, process exit, and side-effect snapshot. Both summaries show request counts, exits, and timestamps; they do not hide the nonzero EXP-14 target failure.

The common CLI invocation is `node /workspace/research/claude-davinci/artifacts/claude-2.1.80/cli.js --print --output-format stream-json --verbose --no-session-persistence ... <prompt>`. Common isolated environment values are stored in every result record. The fixture uses the synthetic key string `sk-ant-local-fixture-only`, an ephemeral `127.0.0.1` URL, fixture model `claude-fixture-model`, a 30-second per-process deadline, a three-request cap, and `CLAUDE_CODE_MAX_RETRIES=0`. The system prompt cases use empty setting sources except EXP-15, which explicitly selects project sources. No values are taken from the ambient environment except the harness executable itself; the child PATH is fixed.

| ID | Canonical capture | Input variation | Observed outcome |
|---|---|---|---|
| EXP-01 | [`EXP-01/result.json`](runs/rerun-final/EXP-01/result.json) | Plain final-text request; synthetic text response | Exit 0, one request, success, one turn. |
| EXP-02 | [`EXP-02/result.json`](runs/rerun-final/EXP-02/result.json) | `--tools Read --dangerously-skip-permissions`; Read tool_use then final | Exit 0, two requests; matching Read tool_result appears in the next request before final text. |
| EXP-03 | [`EXP-03/result.json`](runs/rerun-final/EXP-03/result.json) | EXP-02 with `--max-turns 1`; Read tool_use | Exit 0, one request; Read executed and tool_result event emitted, then `error_max_turns`, two turns. |
| EXP-04 | [`EXP-04/result.json`](runs/rerun-final/EXP-04/result.json) | `--tools Write --permission-mode dontAsk`; controlled Write request | Exit 0, two requests; denial recorded in tool_result and `permission_denials`; target absent. |
| EXP-05 | [`EXP-05/result.json`](runs/rerun-final/EXP-05/result.json) | `--tools Read,Write --dangerously-skip-permissions --max-turns 1`; two Reads plus one Write in one response | Exit 0, one request; all tool results emitted and fixture Write occurred before `error_max_turns`. No timing instrumentation; no concurrency/barrier guarantee inferred. |
| EXP-06 | [`EXP-06/result.json`](runs/rerun-final/EXP-06/result.json) | Synthetic `stop_reason=max_tokens`, then text | Exit 0, two requests, success, one turn; recovery observed for this bounded response sequence. |
| EXP-07 | [`EXP-07/result.json`](runs/rerun-final/EXP-07/result.json) | Valid text stream, omitted stop_reason | Exit 0, one request, success with `stop_reason:null`. |
| EXP-08 | [`EXP-08/result.json`](runs/rerun-final/EXP-08/result.json) | Read tool_use paired with `stop_reason=end_turn`; max turns 1 | Exit 0, one request; Read ran and final record was `error_max_turns`, stop reason remained end_turn. |
| EXP-09 | [`EXP-09/result.json`](runs/rerun-final/EXP-09/result.json) | Default noninteractive system prompt | Exit 0, one request; raw system/tools/messages shape captured, including billing, cache annotations, and user reminder/currentDate. |
| EXP-10 | [`EXP-10/result.json`](runs/rerun-final/EXP-10/result.json) | `--system-prompt 'CUSTOM FIXTURE SYSTEM BLOCK'` | Exit 0, one request; custom prompt block present; ordinary default instruction block absent in this print invocation. |
| EXP-11 | [`EXP-11/result.json`](runs/rerun-final/EXP-11/result.json) | `--append-system-prompt 'APPENDED FIXTURE SYSTEM BLOCK'` | Exit 0, one request; default instructions plus appended block captured. |
| EXP-12 | [`EXP-12/result.json`](runs/rerun-final/EXP-12/result.json) | Research-owned CLAUDE.md but `--setting-sources ''` | Exit 0, one request; CLAUDE.md sentinel absent from request. |
| EXP-13 | [`EXP-13/result.json`](runs/rerun-final/EXP-13/result.json) | `--system-prompt ''`, CLAUDE.md fixture, empty setting sources | Exit 0, one request; default instruction block and CLAUDE.md sentinel absent; reminder/prompt remain. |
| EXP-14 | [`EXP-14/result.json`](runs/rerun-final/EXP-14/result.json) | message_start missing its message object, then malformed event JSON | Exit 1, one request; `.usage` error. This compound input does not isolate malformed JSON; independent audit controls below do. |
| EXP-15 | [`EXP-15/result.json`](runs/rerun-memory/EXP-15/result.json) | Research-owned CLAUDE.md with `--setting-sources project` | Exit 0, one request; CLAUDE.md sentinel appears in user system-reminder context. |

## Preliminary, failed, and unrun records

- Earlier directories contain preliminary records whose chronology was not reliably preserved by the original overwrite-prone runner. For example, retained `runs/EXP-01` and `runs/EXP-03` have successful requests, `--verbose`, and a misspelled traffic-disable flag; `runs/rerun-corrected/EXP-03` already has the correct flag. Read each record's command/environment rather than assigning a failure/configuration state from the directory name. Originally described zero-request failures are not proven retained by these examples.
- `runs/rerun-final/` is authoritative for EXP-01–EXP-14 and uses the correctly spelled `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC`. Thirteen CLI invocations exited 0; EXP-14 intentionally/observably exited 1 on the malformed-stream scenario. All 14 issued at most two requests; no request cap or deadline was reached.
- `runs/rerun-memory/EXP-15/` is the authoritative project-source follow-up; it uses the corrected isolated environment and does not overwrite the original absent-source captures.
- The harness performs no automated assertions over scenario outcomes. `node --check` passed; the captured CLI result fields, request counts, tool-result events, and fixture files were inspected directly. EXP-14 remains a target failure, not a harness failure.
- This experiment specialist did not exercise native 2.1.302 runtime behavior or time safe-tool concurrency/barriers. The lead separately recorded native version/file inventory below. All fixture API behavior is synthetic; provider cache behavior, production retries, actual spend, task quality, and cross-version parity remain untested.

## Audit controls and non-overwriting reproductions

- [`AUD-STREAM-A`](../audit/controls/runs/rerun-final/AUD-STREAM-A/result.json): missing message_start.message alone; one request, exit1, same `.usage` error.
- [`AUD-STREAM-B`](../audit/controls/runs/rerun-final/AUD-STREAM-B/result.json): valid start plus broken JSON; two requests, second nonstreaming, exit0 with final text.
- [`AUD-STREAM-C`](../audit/controls/runs/rerun-final/AUD-STREAM-C/result.json): valid SSE control; one request, exit0.
- The audit's [`control-harness.cjs`](../audit/control-harness.cjs) and snapshot preserve the independent differential protocol. Avoid overwriting retained control directories when reproducing it.
- After AUD-02 the main runner writes only fresh `reproductions/<run-label>/` paths, records a harness hash, and uses explicit source selection. Lead checks of EXP-12/13/15 are at [`lead-reproduction-validation`](reproductions/lead-reproduction-validation/summary.json); all exited0 and reproduce the negative/positive memory selection. Historical captures remain unchanged.
- Native 2.1.302 version/file/section inventory was separately recorded by the lead in [`artifact-observations.json`](../artifact-observations.json); this is not runtime-mechanism or cross-version parity evidence.
