#!/usr/bin/env node
// Controlled local Messages API fixture for the pinned Claude Code 2.1.80 CLI.
// The server binds only to 127.0.0.1 and writes request/response captures under
// evidence/experiments. It never forwards requests or uses real credentials.
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { once } = require('node:events');

const root = path.resolve(__dirname, '..');
const artifact = path.join(root, 'artifacts/claude-2.1.80/cli.js');
const evidence = path.join(root, 'evidence/experiments');
const node = process.execPath;
const deadlineMs = 30000;
const globalRequestCap = 3;
const syntheticKey = 'sk-ant-local-fixture-only';
const scenarios = [
  { id: 'EXP-01', name: 'ordinary-final', prompt: 'Say fixture final.', response: ['text'] },
  { id: 'EXP-02', name: 'tool-use-result-final', prompt: 'Read the fixture note.', args: ['--tools','Read','--dangerously-skip-permissions'], response: ['read-tool','text'] },
  { id: 'EXP-03', name: 'max-turns-one-after-tool', prompt: 'Read the fixture note.', args: ['--tools','Read','--dangerously-skip-permissions','--max-turns','1'], response: ['read-tool'] },
  { id: 'EXP-04', name: 'permission-denied-write', prompt: 'Write the fixture file.', args: ['--tools','Write','--permission-mode','dontAsk'], response: ['write-tool'], expectDenied: true },
  { id: 'EXP-05', name: 'safe-tools-and-write-barrier', prompt: 'Read twice then write.', args: ['--tools','Read,Write','--dangerously-skip-permissions','--max-turns','1'], response: ['multi-tools'] },
  { id: 'EXP-06', name: 'output-max-tokens-recovery', prompt: 'Recover from the output limit.', response: ['max-tokens','text'] },
  { id: 'EXP-07', name: 'missing-stop-reason', prompt: 'Handle the incomplete response.', response: ['missing-stop'] },
  { id: 'EXP-08', name: 'contradictory-stop-and-tool-use', prompt: 'Handle tool use with end turn.', args: ['--tools','Read','--dangerously-skip-permissions','--max-turns','1'], response: ['tool-end-turn'] },
  { id: 'EXP-09', name: 'default-system-prompt', prompt: 'Observe request prompt.', response: ['text'] },
  { id: 'EXP-10', name: 'custom-system-prompt', prompt: 'Observe request prompt.', args: ['--system-prompt','CUSTOM FIXTURE SYSTEM BLOCK'], response: ['text'] },
  { id: 'EXP-11', name: 'appended-system-prompt', prompt: 'Observe request prompt.', args: ['--append-system-prompt','APPENDED FIXTURE SYSTEM BLOCK'], response: ['text'] },
  { id: 'EXP-12', name: 'claude-md-system-prompt', prompt: 'Observe request prompt.', response: ['text'], claudeMd: true },
  { id: 'EXP-13', name: 'empty-custom-system-prompt', prompt: 'Observe request prompt.', args: ['--system-prompt',''], response: ['text'], claudeMd: true },
  { id: 'EXP-14', name: 'malformed-stream-fallback', prompt: 'Recover from a malformed stream.', response: ['malformed-stream','text'] },
  { id: 'EXP-15', name: 'claude-md-project-source', prompt: 'Observe project memory context.', response: ['text'], claudeMd: true, settingSources: 'project' },
];
const runLabel = process.argv[2] ? 'rerun-memory' : 'rerun-final';

function mkdir(p) { fs.mkdirSync(p, { recursive: true }); }
function now() { return new Date().toISOString(); }
function writeJson(p, value) { fs.writeFileSync(p, JSON.stringify(value, null, 2) + '\n'); }
function blockText(text) { return { type: 'text', text }; }
function assistant(content, stop_reason = 'end_turn', extra = {}) {
  return { id: 'msg_fixture', type: 'message', role: 'assistant', model: 'claude-fixture-model', content,
    stop_reason, stop_sequence: null, usage: { input_tokens: 17, output_tokens: 5, cache_creation_input_tokens: 0, cache_read_input_tokens: 0 }, ...extra };
}

function responseFor(kind) {
  if (kind === 'text') return assistant([blockText('Synthetic fixture final.')]);
  if (kind === 'read-tool') return assistant([{ type: 'tool_use', id: 'toolu_read_1', name: 'Read', input: { file_path: path.join(evidence, 'fixtures', 'read-note.txt') } }], 'tool_use');
  if (kind === 'write-tool') return assistant([{ type: 'tool_use', id: 'toolu_write_1', name: 'Write', input: { file_path: path.join(evidence, 'fixtures', 'denied-write.txt'), content: 'SHOULD_NOT_BE_WRITTEN' } }], 'tool_use');
  if (kind === 'multi-tools') return assistant([
    { type: 'tool_use', id: 'toolu_read_a', name: 'Read', input: { file_path: path.join(evidence, 'fixtures', 'read-note.txt') } },
    { type: 'tool_use', id: 'toolu_read_b', name: 'Read', input: { file_path: path.join(evidence, 'fixtures', 'read-note.txt') } },
    { type: 'tool_use', id: 'toolu_write_a', name: 'Write', input: { file_path: path.join(evidence, 'fixtures', 'safe-write.txt'), content: 'controlled fixture write' } },
  ], 'tool_use');
  if (kind === 'max-tokens') return assistant([blockText('Synthetic partial output.')], 'max_tokens');
  if (kind === 'missing-stop') { const m = assistant([blockText('Synthetic missing stop reason.')]); delete m.stop_reason; return m; }
  if (kind === 'tool-end-turn') return assistant([{ type: 'tool_use', id: 'toolu_end_1', name: 'Read', input: { file_path: path.join(evidence, 'fixtures', 'read-note.txt') } }], 'end_turn');
  if (kind === 'malformed-stream') return assistant([blockText('Synthetic malformed stream response.')]);
  throw new Error(`Unknown response kind ${kind}`);
}

function sse(response, omitStopReason = false) {
  const events = [];
  events.push(['message_start', { type: 'message_start', message: { ...response, content: [], usage: { input_tokens: 17, output_tokens: 0 } } }]);
  response.content.forEach((block, index) => {
    events.push(['content_block_start', { type: 'content_block_start', index, content_block: block.type === 'tool_use'
      ? { type: 'tool_use', id: block.id, name: block.name, input: {} } : { type: 'text', text: '' } }]);
    if (block.type === 'tool_use') {
      events.push(['content_block_delta', { type: 'content_block_delta', index, delta: { type: 'input_json_delta', partial_json: JSON.stringify(block.input) } }]);
    } else events.push(['content_block_delta', { type: 'content_block_delta', index, delta: { type: 'text_delta', text: block.text } }]);
    events.push(['content_block_stop', { type: 'content_block_stop', index }]);
  });
  events.push(['message_delta', { type: 'message_delta', delta: omitStopReason ? {} : { stop_reason: response.stop_reason, stop_sequence: null }, usage: { output_tokens: 5 } }]);
  events.push(['message_stop', { type: 'message_stop' }]);
  return events.map(([event, data]) => `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`).join('');
}

async function runScenario(s) {
  const dir = path.join(evidence, 'runs', runLabel, s.id);
  const cwd = path.join(dir, 'workspace');
  const home = path.join(dir, 'home');
  const config = path.join(dir, 'config');
  mkdir(cwd); mkdir(home); mkdir(config);
  for (const f of ['denied-write.txt','safe-write.txt']) {
    const p = path.join(evidence,'fixtures',f);
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
  fs.writeFileSync(path.join(evidence, 'fixtures', 'read-note.txt'), 'Synthetic fixture note.\n');
  if (s.claudeMd) fs.writeFileSync(path.join(cwd, 'CLAUDE.md'), 'CLAUDE.MD FIXTURE SYSTEM BLOCK\n');
  const settingArgs = s.settingSources ? ['--setting-sources',s.settingSources] : s.claudeMd ? [] : ['--setting-sources',''];
  const commands = ['--print','--output-format','stream-json','--verbose','--no-session-persistence', ...settingArgs, ...(s.args || []), s.prompt];
  const requests = [];
  const responses = [];
  let requestCount = 0;
  const server = http.createServer(async (req, res) => {
    const chunks = [];
    for await (const chunk of req) chunks.push(chunk);
    const raw = Buffer.concat(chunks).toString('utf8');
    let body;
    try { body = JSON.parse(raw); } catch { body = { parse_error: true, raw }; }
    const capture = { at: now(), method: req.method, path: req.url, headers: Object.fromEntries(Object.entries(req.headers).filter(([k]) => !['x-api-key','authorization'].includes(k))), body };
    requests.push(capture); requestCount++;
    if (req.headers['x-api-key'] !== syntheticKey) {
      res.writeHead(401, { 'content-type':'application/json' }); const payload = { error: { type:'authentication_error', message:'fixture rejected non-synthetic key' } }; res.end(JSON.stringify(payload)); responses.push({ at:now(), status:401, body:payload }); return;
    }
    const kind = s.response[requestCount - 1] || 'text';
    let message = responseFor(kind);
    if (requestCount > globalRequestCap) { res.writeHead(429, { 'content-type':'application/json' }); const payload={error:{type:'rate_limit_error',message:'fixture global request cap'}};res.end(JSON.stringify(payload));responses.push({at:now(),status:429,body:payload});return; }
    if (kind === 'malformed-stream') {
      const payloadText = 'event: message_start\ndata: {"type":"message_start"}\n\nevent: content_block_start\ndata: {broken-json\n\n';
      responses.push({ at:now(), status:200, content_type:'text/event-stream', response:message, sse:payloadText, deliberatelyMalformed:true });
      res.writeHead(200, { 'content-type':'text/event-stream', 'cache-control':'no-cache', 'connection':'close' }); res.end(payloadText); return;
    }
    const omit = kind === 'missing-stop';
    const payloadText = sse(message, omit);
    responses.push({ at: now(), status:200, content_type:'text/event-stream', response:message, sse:payloadText });
    res.writeHead(200, { 'content-type':'text/event-stream', 'cache-control':'no-cache', 'connection':'close' }); res.end(payloadText);
  });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  const address = server.address();
  const env = {
    PATH: '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:/usr/bin:/bin',
    HOME: home,
    TMPDIR: dir,
    CLAUDE_CONFIG_DIR: config,
    NO_COLOR: '1',
    TERM: 'dumb',
    CI: '1',
    DISABLE_AUTOUPDATER: '1',
    DISABLE_TELEMETRY: '1',
    CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1',
    CLAUDE_CODE_DISABLE_FEEDBACK: '1',
    CLAUDE_CODE_MAX_RETRIES: '0',
    ANTHROPIC_API_KEY: syntheticKey,
    ANTHROPIC_BASE_URL: `http://127.0.0.1:${address.port}`,
    ANTHROPIC_MODEL: 'claude-fixture-model',
  };
  const fullArgs = [artifact, ...commands];
  const commandRecord = { executable: node, args: fullArgs, cwd, nodeVersion: process.version, envNames: Object.keys(env).sort(), envSafeValues: Object.fromEntries(Object.entries(env).filter(([k]) => k !== 'ANTHROPIC_API_KEY')), envSyntheticKeyLabel: 'ANTHROPIC_API_KEY=sk-ant-local-fixture-only (local-only synthetic key)' };
  const start = now();
  const child = spawn(node, fullArgs, { cwd, env, stdio:['ignore','pipe','pipe'] });
  let stdout = '', stderr = '';
  child.stdout.setEncoding('utf8').on('data', x => stdout += x);
  child.stderr.setEncoding('utf8').on('data', x => stderr += x);
  let timer;
  const deadline = new Promise(resolve => { timer = setTimeout(() => { child.kill('SIGKILL'); resolve({ timeout:true }); }, deadlineMs); });
  const exited = new Promise(resolve => child.once('close', (code, signal) => resolve({ code, signal })));
  const exit = await Promise.race([deadline, exited]); clearTimeout(timer);
  await new Promise(resolve => server.close(resolve));
  const end = now();
  const sideEffects = {};
  for (const f of ['denied-write.txt','safe-write.txt']) {
    const p = path.join(evidence,'fixtures',f); sideEffects[f] = { exists:fs.existsSync(p), content:fs.existsSync(p) ? fs.readFileSync(p,'utf8') : null };
  }
  const result = { id:s.id, scenario:s.name, label:'synthetic loopback Messages API experiment', startedAt:start, endedAt:end, deadlineMs, globalRequestCap, command:commandRecord, exit, requestCount, requests, responses, stdout, stderr, sideEffects };
  writeJson(path.join(dir,'result.json'),result);
  return result;
}

async function main() {
  mkdir(evidence); mkdir(path.join(evidence,'fixtures')); mkdir(path.join(evidence,'runs'));
  const selected = process.argv[2] ? scenarios.filter(s => process.argv[2].split(',').includes(s.id)) : scenarios;
  const summaries=[];
  for (const s of selected) {
    try { summaries.push(await runScenario(s)); }
    catch (e) { summaries.push({id:s.id,scenario:s.name,harnessFailure:String(e),at:now()}); }
    writeJson(path.join(evidence,`summary-${runLabel}.json`), summaries.map(x => ({id:x.id,scenario:x.scenario,exit:x.exit,requestCount:x.requestCount,harnessFailure:x.harnessFailure,startedAt:x.startedAt,endedAt:x.endedAt})));
    process.stdout.write(`${s.id} ${s.name} complete\n`);
  }
  writeJson(path.join(evidence,'summary-rerun-corrected.json'), summaries.map(x => ({id:x.id,scenario:x.scenario,exit:x.exit,requestCount:x.requestCount,harnessFailure:x.harnessFailure,startedAt:x.startedAt,endedAt:x.endedAt})));
  process.stdout.write(JSON.stringify(summaries.map(x=>({id:x.id,scenario:x.scenario,exit:x.exit,requestCount:x.requestCount,harnessFailure:x.harnessFailure})),null,2)+'\n');
}
main().catch(e => { process.stderr.write(String(e.stack||e)+'\n'); process.exitCode=1; });
