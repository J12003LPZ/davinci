"""Independent read-only integrity/capture audit; outputs only to evidence/audit."""
import base64, hashlib, json, pathlib, re, tarfile

root = pathlib.Path('/workspace/research/claude-davinci')
out = root / 'evidence/audit'
manifest = json.loads((root/'evidence/artifact-manifest.json').read_text())
result = {'artifacts': [], 'indexes': {}, 'captures': []}
for f in manifest['files']:
    p = pathlib.Path(f['path']); b = p.read_bytes()
    result['artifacts'].append({'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
                                'manifest_matches': len(b) == f['bytes'] and hashlib.sha256(b).hexdigest() == f['sha256']})
tgz = root/'artifacts/anthropic-ai-claude-code-2.1.80.tgz'
actual_integrity = 'sha512-' + base64.b64encode(hashlib.sha512(tgz.read_bytes()).digest()).decode()
result['tarball_integrity'] = {'actual': actual_integrity, 'manifest_matches': actual_integrity == manifest['npm_integrity']}
raw = (root/'artifacts/claude-2.1.80/cli.js').read_bytes()
pretty_bytes = (root/'artifacts/claude-2.1.80/cli.pretty.js').read_bytes()
lines = pretty_bytes.decode().split('\n')  # LF, never splitlines: JS strings contain U+2028/U+2029.
result['pretty_lf_lines'] = len(lines)
with tarfile.open(tgz) as t:
    members = {}
    for n in ['package/cli.js', 'package/package.json']:
        b = t.extractfile(n).read()
        members[n] = {'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}
        if n.endswith('cli.js'): members[n]['matches_extracted_raw'] = b == raw
        else: members[n]['package'] = json.loads(b)
    result['tar_members'] = members
for kind, key in [('context','functions'), ('prompt','locations')]:
    index = json.loads((root/f'evidence/{kind}/source_index.json').read_text())
    checks = []
    for row in index[key]:
        name = row.get('function',row.get('identifier'))
        needle = row['raw_needle'].encode(); start=row['pretty_line_start']; end=row['pretty_line_end']
        snippet = '\n'.join(lines[start-1:end]) + '\n'
        check = {'identifier': name, 'start':start,'end':end,'raw_offset_matches': raw.find(needle)==row['raw_byte_offset'],
                 'needle_count_matches':raw.count(needle)==row['raw_needle_occurrences'],
                 'needle_unique':raw.count(needle)==1,'first_line':lines[start-1]}
        file = root/f'evidence/{kind}'/('function_'+name.replace('$','DOLLAR')+'.js')
        if file.exists(): check['verbatim_excerpt'] = file.read_text()==snippet
        checks.append(check)
    result['indexes'][kind] = checks
for i in range(1,16):
    p=root/'evidence/experiments/runs'/('rerun-memory' if i==15 else 'rerun-final')/f'EXP-{i:02d}'/'result.json'
    d=json.loads(p.read_text()); events=[json.loads(s) for s in d['stdout'].split('\n') if s.strip()]
    terminals=[e for e in events if e.get('type')=='result']
    requests=d['requests']; responses=d['responses']
    row={'id': d['id'], 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'exit':d['exit'],
         'request_count_recorded':d['requestCount'], 'request_count_actual':len(requests),'responses':len(responses),
         'loopback':d['command']['envSafeValues']['ANTHROPIC_BASE_URL'].startswith('http://127.0.0.1:'),
         'traffic_flag':d['command']['envSafeValues'].get('CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC'),
         'args':d['command']['args'],'terminal':[ {k:t.get(k) for k in ['subtype','is_error','num_turns','stop_reason','result','errors','usage','total_cost_usd','permission_denials']} for t in terminals],
         'tool_result_events':[], 'memory_marker_system':[], 'memory_marker_messages':[],
         'side_effects':d['sideEffects'],'sse_start_valid_message':[]}
    for e in events:
        if e.get('type')=='user':
            row['tool_result_events'] += [b for b in e.get('message',{}).get('content',[]) if isinstance(b,dict) and b.get('type')=='tool_result']
    for req in requests:
        row['memory_marker_system'].append('CLAUDE.MD FIXTURE SYSTEM BLOCK' in json.dumps(req['body'].get('system')))
        row['memory_marker_messages'].append('CLAUDE.MD FIXTURE SYSTEM BLOCK' in json.dumps(req['body'].get('messages')))
    for res in responses:
        first=res.get('sse','').split('\n\n')[0]
        data=next((l[len('data: '):] for l in first.split('\n') if l.startswith('data: ')), '{}')
        row['sse_start_valid_message'].append(isinstance(json.loads(data).get('message'),dict))
    result['captures'].append(row)
(out/'recomputed.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'artifacts_all_match':all(a['manifest_matches'] for a in result['artifacts']),
                  'tarball_integrity_match':result['tarball_integrity']['manifest_matches'],
                  'tar_cli_matches':result['tar_members']['package/cli.js']['matches_extracted_raw'],
                  'indexes':{k:{'count':len(v),'failures':[x for x in v if not all(x.get(c,True) for c in ['raw_offset_matches','needle_count_matches','needle_unique','verbatim_excerpt'])]} for k,v in result['indexes'].items()},
                  'captures':[{k:r[k] for k in ['id','exit','request_count_actual','sse_start_valid_message','memory_marker_system','memory_marker_messages']} for r in result['captures']]},indent=2))
