#!/usr/bin/env python3
"""Recompute artifact identity, integrity and research provenance without credentials."""
import base64
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
EXPECTED_INTEGRITY = "YAgNNr3fzn3xaTNm+CYgebdEinU9D0HxGUT2C1N2Ej2HCvt5AjrSoU8vTgccxx4oPkj1R4gpuZWi1rTKvxNaPQ=="

def digest(path, algorithm="sha256"):
    h = hashlib.new(algorithm)
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h

def main():
    tarball = ARTIFACTS / "anthropic-ai-claude-code-2.1.80.tgz"
    assert base64.b64encode(digest(tarball, "sha512").digest()).decode() == EXPECTED_INTEGRITY
    files = [tarball, ARTIFACTS / "claude-2.1.80/cli.js", ARTIFACTS / "claude-2.1.80/cli.pretty.js", ARTIFACTS / "claude-2.1.302-linux-x64"]
    node = "/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node"
    observations = []
    for command in [
        [node, str(ARTIFACTS / "claude-2.1.80/cli.js"), "--version"],
        [str(ARTIFACTS / "claude-2.1.302-linux-x64"), "--version"],
        ["file", str(ARTIFACTS / "claude-2.1.302-linux-x64")],
        ["readelf", "-SW", str(ARTIFACTS / "claude-2.1.302-linux-x64")],
    ]:
        process = subprocess.run(command, text=True, capture_output=True, timeout=20)
        observations.append({"command": command, "exit_code": process.returncode, "stdout": process.stdout, "stderr": process.stderr})
        assert process.returncode == 0
    inventory = ROOT / "evidence/artifact-observations.json"
    inventory.write_text(json.dumps(observations, indent=2) + "\n")
    result = {
        "primary_target": "@anthropic-ai/claude-code@2.1.80",
        "source": "https://registry.npmjs.org/@anthropic-ai/claude-code/-/claude-code-2.1.80.tgz",
        "npm_integrity_sha512_verified": True,
        "npm_integrity": "sha512-" + EXPECTED_INTEGRITY,
        "format_derivative": "prettier@3.6.2 --parser babel; identifiers unchanged",
        "separate_native_inventory": "Claude Code 2.1.302, not evidence of 2.1.80 parity",
        "command_observations": str(inventory),
        "davinci_commit": subprocess.check_output(["git", "-C", "/workspace/davinci", "rev-parse", "HEAD"], text=True).strip(),
        "files": [{"path": str(p), "bytes": p.stat().st_size, "sha256": digest(p).hexdigest()} for p in files],
    }
    output = ROOT / "evidence/artifact-manifest.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
