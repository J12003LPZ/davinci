#!/usr/bin/env python3
"""Index final research deliverables and retained captures without changing inputs."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]

def main():
    reports = [ROOT / "README.md", ROOT / "RESEARCH_PROTOCOL.md"]
    for folder in ("final", "wave1", "wave2", "wave3"):
        reports.extend(sorted((ROOT / folder).glob("*.md")))
    broken = []
    checked = 0
    for report in reports:
        for target in re.findall(r"\]\(([^)]+)\)", report.read_text()):
            if target.startswith(("http:", "https:", "#", "app:")):
                continue
            target = target.split("#")[0]
            path = Path(target) if target.startswith("/") else report.parent / target
            checked += 1
            if not path.exists():
                broken.append({"report": str(report.relative_to(ROOT)), "target": target})
    assert not broken, broken
    validation = json.loads((ROOT / "evidence/validation.json").read_text())
    assert validation["passed"]
    files = reports + sorted((ROOT / "scripts").glob("*"))
    files += [ROOT / "evidence/artifact-manifest.json", ROOT / "evidence/artifact-observations.json", ROOT / "evidence/validation.json", ROOT / "evidence/experiments/INDEX.md"]
    for folder in ("context", "prompt", "comparison", "proposals"):
        path = ROOT / f"evidence/{folder}/source_index.json"
        if path.exists():
            files.append(path)
    for number in range(1, 16):
        run = "rerun-memory" if number == 15 else "rerun-final"
        files.append(ROOT / f"evidence/experiments/runs/{run}/EXP-{number:02}/result.json")
    for suffix in ("A", "B", "C"):
        files.append(ROOT / f"evidence/audit/controls/runs/rerun-final/AUD-STREAM-{suffix}/result.json")
    for number in (12, 13, 15):
        files.append(ROOT / f"evidence/experiments/reproductions/lead-reproduction-validation/EXP-{number}/result.json")
    result = {
        "scope": "final reports, scripts, source indexes and canonical/control/reproduction captures; artifact hashes are separately retained",
        "claude_source_version": "2.1.80",
        "native_inventory_only_version": "2.1.302",
        "davinci_commit": validation["davinci_head"],
        "davinci_status": validation["davinci_status"],
        "checked_report_links": checked,
        "broken_links": broken,
        "evidence_assertions": len(validation["checks"]),
        "files": [{"path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(set(files)) if p.is_file()],
    }
    path = ROOT / "evidence/deliverable-manifest.json"
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"indexed_files": len(result["files"]), "report_links": checked, "broken_links": len(broken), "output": str(path)}))

if __name__ == "__main__":
    main()
