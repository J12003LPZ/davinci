#!/usr/bin/env python3
"""Validate retained evidence, not task quality or production provider behavior."""
import hashlib
import json
from pathlib import Path
import subprocess
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
checks = []

def verify(name, condition):
    checks.append({"check": name, "passed": bool(condition)})

def load(path):
    return json.loads(path.read_text())

def terminal(record):
    events = []
    for line in record["stdout"].split("\n"):
        try:
            value = json.loads(line)
        except (ValueError, TypeError):
            continue
        if isinstance(value, dict) and value.get("type") == "result":
            events.append(value)
    verify(record["id"] + " has one terminal result", len(events) == 1)
    return events[-1] if events else {}

def main():
    manifest = load(ROOT / "evidence/artifact-manifest.json")
    for record in manifest["files"]:
        path = Path(record["path"])
        verify("artifact bytes/hash: " + path.name,
               path.stat().st_size == record["bytes"] and hashlib.sha256(path.read_bytes()).hexdigest() == record["sha256"])

    records = {}
    for number in range(1, 16):
        identity = f"EXP-{number:02}"
        run = "rerun-memory" if number == 15 else "rerun-final"
        record = load(ROOT / f"evidence/experiments/runs/{run}/{identity}/result.json")
        records[identity] = record
        result = terminal(record)
        expected_code = 1 if number == 14 else 0
        expected_subtype = "error_during_execution" if number == 14 else "error_max_turns" if number in (3, 5, 8) else "success"
        expected_requests = 2 if number in (2, 4, 6) else 1
        verify(identity + " retained terminal/requests", record["exit"]["code"] == expected_code and result.get("subtype") == expected_subtype and record["requestCount"] == expected_requests)
        env = record["command"]["envSafeValues"]
        verify(identity + " isolated provider/config", urlparse(env["ANTHROPIC_BASE_URL"]).hostname == "127.0.0.1" and env["CLAUDE_CONFIG_DIR"].startswith(str(ROOT)) and env["CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC"] == "1")
        verify(identity + " captured auth headers excluded", all("authorization" not in r["headers"] and "x-api-key" not in r["headers"] for r in record["requests"]))
        if number in (3, 5):
            verify(identity + " limit is not error boolean", result.get("is_error") is False and result.get("num_turns") == 2)

    verify("denied write remains absent in snapshot", records["EXP-04"]["sideEffects"]["denied-write.txt"]["exists"] is False)
    verify("allowed fixture write recorded", records["EXP-05"]["sideEffects"]["safe-write.txt"]["content"] == "controlled fixture write")
    for number in (12, 13, 15):
        record = records[f"EXP-{number}"]
        body = record["requests"][0]["body"]
        verify(f"EXP-{number} memory source selection", ("CLAUDE.MD FIXTURE SYSTEM BLOCK" in json.dumps(body["messages"])) == (number == 15) and "CLAUDE.MD FIXTURE SYSTEM BLOCK" not in json.dumps(body["system"]))
        reproduced = load(ROOT / f"evidence/experiments/reproductions/lead-reproduction-validation/EXP-{number}/result.json")
        body2 = reproduced["requests"][0]["body"]
        verify(f"EXP-{number} repaired-runner reproduction", reproduced["exit"]["code"] == 0 and ("CLAUDE.MD FIXTURE SYSTEM BLOCK" in json.dumps(body2["messages"])) == (number == 15))

    for suffix in ("A", "B", "C"):
        record = load(ROOT / f"evidence/audit/controls/runs/rerun-final/AUD-STREAM-{suffix}/result.json")
        result = terminal(record)
        verify("audit stream control " + suffix, record["exit"]["code"] == (1 if suffix == "A" else 0) and record["requestCount"] == (2 if suffix == "B" else 1) and result.get("subtype") == ("error_during_execution" if suffix == "A" else "success"))
        if suffix == "B":
            verify("audit fallback request is nonstreaming", not record["requests"][1]["body"].get("stream", False))

    repo = "/workspace/davinci"
    head = subprocess.check_output(["git", "-C", repo, "rev-parse", "HEAD"], text=True).strip()
    status = subprocess.check_output(["git", "-C", repo, "status", "--porcelain=v1"], text=True)
    verify("DaVinci source pin unchanged", head == "53e999a7fc24c721c484a710093eeeff611641bf")
    verify("DaVinci tracked/untracked status clean", status == "")
    output = {"scope": "retained evidence assertions; no provider or DaVinci execution", "checks": checks, "passed": all(c["passed"] for c in checks), "canonical_scenarios": 15, "canonical_exit_zero": 14, "canonical_exit_nonzero": 1, "audit_controls": 3, "repaired_runner_reproductions": 3, "davinci_head": head, "davinci_status": status}
    (ROOT / "evidence/validation.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"passed": output["passed"], "checks": len(checks), "failed": [c for c in checks if not c["passed"]], "output": str(ROOT / "evidence/validation.json")}))
    return 0 if output["passed"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
