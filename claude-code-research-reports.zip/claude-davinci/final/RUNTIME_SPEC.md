# Claude Code runtime specification — pinned 2.1.80

Integrated specification and comparison. Exact evidence classifications and remaining limits are preserved below; the separate audit records independent challenges and corrections.

## Artifact and evidence contract

**Source-verified identity.** This specification describes the official distributed npm `@anthropic-ai/claude-code@2.1.80` implementation, not an imagined upstream source tree. The npm tarball's published SHA-512 integrity was independently recomputed. The raw bundle SHA-256 is `0b146fe609bd591feb8e6ba689d146b56265076c9c23cee1a351cd2df74b4ec1`. `cli.pretty.js` is a Prettier 3.6.2 derivative with unchanged identifiers, SHA-256 `b6daf37bb2bb905a09d62f2c513de6d7f0f8a556c688a80c7961af8de1516fcf`. Source citations below refer to LF-based lines in that derivative at `/workspace/research/claude-davinci/artifacts/claude-2.1.80/cli.pretty.js` (abbreviated **P**). Each wave report supplies raw-byte offsets/needles for reproduction. See [artifact manifest](../evidence/artifact-manifest.json).

**Experimentally observed identity only.** The separately installed native ELF reports version 2.1.302. Its copied SHA-256 is `60d7eb7f12fbb28a52533fe8be5884097403562aa02dc73991a021c7067e29a5`. Native strings are insufficient to prove implementation parity. **Unknown:** whether any particular 2.1.80 internal mechanism remains present/enabled in 2.1.302. Nothing below silently bridges that version gap.

DaVinci comparison targets Rust commit `53e999a7fc24c721c484a710093eeeff611641bf`; no DaVinci modifications are authorized. No third-party decompiled documentation supplies implementation proof. The uploaded leanrea document was a routing/reference guide, not a replacement for the user's requested research and evidence rules.

Four labels are used: **source-verified** for concrete implementation; **experimentally observed** for retained controlled execution; **inferred** for an explicitly stated interpretation; **unknown** where evidence is absent. A source-verified conditional branch is not proof of runtime activation. A prompt is not enforcement. A mock server is not the Anthropic backend. A source feature is not a measured task-success improvement.

## End-to-end control flow

**Source-verified composition; diagram is a descriptive reconstruction, not original source.**

```mermaid
flowchart TD
    A[Invocation, configuration and admitted tools] --> B[Prompt and per-turn context assembly]
    B --> C[th delegates to zgY]
    C --> D[History suffix and normalization]
    D --> E{Auto-compaction due and enabled?}
    E -- yes --> F[Session-memory path or generated summary]
    F --> G[Replace active model context at compact boundary]
    E -- no --> H{Blocking input limit?}
    G --> H
    H -- yes --> Z[Terminate with input-limit evidence]
    H -- no --> I[uZ6 and request generator build Messages request]
    I --> J[Stream content blocks and capture stop reason]
    J --> K{Any assistant tool_use blocks?}
    K -- yes --> L[Validate, authorize, execute and collect tool results]
    L --> M{Abort, hook stop, turn limit?}
    M -- no --> D
    M -- yes --> Z
    K -- no --> N{Output recovery or blocking stop hook?}
    N -- retry --> D
    N -- finish --> Z
    Z --> O[uFq.submitMessage emits terminal result]
```

### S1. Invocation selects policy, tools and prompt inputs

**Source-verified; T-ADM-01 and T-PERM claims.** Tool candidates pass through `pR1` and `Dl` (P:320074–320140), combining capability/mode filters and requested allow/disallow sets. Tool exposure and permission-to-execute are distinct: making a tool schema visible does not grant execution. `JM` evaluates permission at call time; the interactive approval wrapper `S4Y` handles unresolved requests, interruption and recheck. Headless permission handling is a distinct consumer path. `dontAsk` transforms unresolved ask into deny. Mode/classifier/hook rules have conditional paths; see [tools report](../wave1/tools.md) for exact precedence.

**Source-verified; PROMPT-01–PROMPT-15, [prompt report](../wave2/prompt.md).** Interactive `qS` (P:463201–463222) chooses a truthy override outright, otherwise a truthy main-agent prompt, custom prompt or `HX` default, followed by append. Headless CLI `lN_`→`mFq`→`uFq.submitMessage` uses a different predicate: any string, including an empty string, replaces `HX` application defaults and suppresses `i2` system context. Custom-agent CLI selection can supply an otherwise missing headless prompt. `$Eq` still prepends attribution and identity headers, so application-prompt replacement does not replace the entire final wire array.

`HX` (P:304166–304209) builds modular engineering/action/tool/style guidance, then conditional memory/environment/MCP and other sections. `kz`/`hO` load settings-gated memory into user-context sections; `qR8` wraps those in a meta user message. `i2` supplies the Git-startup snapshot as system context on paths that retain it. Scoped attachments can add later reminders without changing the base system prompt. The memory-loading gates, include recursion, trust, tools and skill invocation paths have separate enforcement; instruction text itself is not enforcement. `CLAUDE_CODE_EXTRA_BODY`, when explicitly supplied, is spread after several computed request fields and can override them, so a predicted request is conditional on that input being absent or accounted for.

### S2. A model turn derives active history from durable/session history

**Source-verified; LOOP-01, CTX-01.** `th` delegates to async generator `zgY` (P:450346–450945). Each iteration takes the suffix selected by `Xk` (P:544646–544650), beginning at the latest `compact_boundary` if present. It can replace large tool results, calls the nominal microcompact dependency, evaluates auto-compaction and checks blocking limits. `qR8` prepends user context as a meta `<system-reminder>`; `MYq` adds system-context sections. `$Eq` later runs `YX`, pairing repair `sVq`, media trimming and wire conversion. Progress records and boundary metadata do not simply become API messages.

**Source-verified; CTX-09, LOOP-09.** Default `lg` is a message-content pass-through (P:317852–317854). `qw6` is initialized null with no located assignment; the guarded reactive-compaction path does not activate through that object in this bundle. `$Eq`'s cache-edit controlling local value remains false. Do not describe these dormant paths as operational history reduction. Custom injected dependencies are a separate scope.

### S3. Context pressure can replace history before the next request

**Source-verified; CTX-02–CTX-08.** Usage accounting plus local estimates, not a tokenizer on every turn, determines pressure. `hf` uses the latest valid assistant usage plus estimates of following entries. Text commonly estimates characters/4; image/document blocks have fixed estimate costs. Those estimates are not server token counts.

`ig`, `eQ6`, `IY6` (P:318129–318173) derive limits from model window and output reserve. With a 200k window and output allowance at least20k, effective input is180k, auto-compaction threshold167k and blocking limit177k. Model rules, positive window overrides and percentage overrides can change these values. **Unknown:** actual production flags and account/model eligibility.

`sW4` attempts session-memory compaction then generated compaction, with a three-failure circuit breaker carried in the query-chain tracking object. `bZ6` creates a boundary, generated summary and selected restored state; `$l` orders boundary, summary, optional kept tail, attachments and hook results. Session-memory compaction has separate enablement, a saved summary file and a dependency-safe recent tail. Manual `/compact` has its own command path and ordinarily does not inject the automatic immediate-continuation instruction. **Unknown:** retained task accuracy; no benchmark evaluates summary fidelity here.

### S4. The adapter constructs a request and streams content

**Source-verified; LOOP-02, LOOP-08, CTX-11–CTX-16.** `uZ6` delegates request construction/streaming to `$Eq`; request execution includes `.beta.messages.create(...stream:true)` (P:546140ff). The client uses SDK `maxRetries:0`; `Uf8` supplies Claude Code's retry policy. Default wrapper budget is ten retries plus the original attempt unless overridden; classification, backoff and model fallback are separate from agent-turn continuation.

Wire input includes normalized messages, system blocks, tool schemas, model/output/thinking options and conditional betas. Stream events assemble text/thinking/tool-input blocks and record `stop_reason`. Selected failures may fall back to non-streaming. This fallback is not proof that already-started tool side effects were canceled or undone.

**Source-verified; CTX-11–CTX-15.** Cache annotations are request fields: final normalized-message content (or penultimate when `skipCacheWrite`) and system blocks. Static/dynamic system grouping and one-hour TTL are conditional. Ordinary generated cache control can omit TTL. **Unknown:** backend cache key, retention actually granted, hit rate, task-success effect, latency or subscription savings. Returned usage-counter plumbing alone establishes none of these outcomes.

### S5. Tool presence drives continuation; execution has two schedulers

**Source-verified; LOOP-03, T-SCH-01–T-SCH-06.** `zgY` collects assistant `tool_use` blocks and chooses tool continuation based on their presence, separately from stored API stop reason. It may begin tools while streaming only when the streaming execution gate enables `Jr6`.

`Jr6.addTool` normalizes and parses input, evaluates the tool's `isConcurrencySafe`, then queues it. Safe calls can overlap other safe calls; an unsafe queued call forms a barrier. This class does not itself impose the fallback path's numerical cap. `getCompletedResults` can publish later safe completions while earlier safe calls run; results retain `tool_use_id` association.

When the streaming runner is absent, `rL8`/`FBY` form adjacent safe groups separated by unsafe singletons; `QBY`/`$E8` run safe groups with `pBY`'s default cap10, while `UBY` serializes unsafe groups. The per-tool `jr6`→`IBY`→`xBY` pipeline resolves/validates, processes hooks and permissions, invokes the tool and normalizes errors. A safety predicate is not a permission grant or a side-effect rollback guarantee.

`Jr6.discard()` sets a flag, not an abort call. Conditional fallback can therefore discard delivery from an already-running invocation without directly canceling it. Interrupt behavior varies per tool; a default blocking behavior differs from cancelable tools. Bash error tool-results trigger a particular sibling-abort path. **Unknown:** universal effect cancellation, exactly-once external effects or safe automatic re-execution after process loss.

### S6. Tool outcomes and terminal checks choose the next state

**Source-verified; LOOP-04–LOOP-07.** After results, `zgY` refreshes attachments/context and increments the turn count. `maxTurns` is checked before starting the next model turn, after tool work for the current response. Abort during streaming and abort during tools return distinct reasons. A no-tool response can complete, encounter an error/output-exhaustion continuation, or pass through a blocking/preventing stop hook. Output exhaustion can resume up to three times on the traced path; that does not activate input-too-long reactive compaction.

`uFq.submitMessage` (P:606648ff) translates generator events into protocol records and terminal subtypes. `success`, turn/budget limit, structured-output retry exhaustion and execution error are separate outcomes. Some limit subtypes have `is_error:false`; callers must examine subtype and other evidence rather than assuming that boolean alone means task completion. **Unknown:** whether a final answer actually satisfies the user's task without external verification.

### S7. Session persistence is distinct from external-effect recovery

**Source-verified; LOOP persistence finding and T-REC claims.** `uFq.submitMessage` collects conversation events and, under its persistence guard, calls `Gx`; that path UUID-deduplicates and inserts a message chain. Compact boundaries and restored summaries determine future active context; this is not equivalent to deleting the stored transcript.

**Unknown:** a general crash-safe transaction joining arbitrary shell/filesystem/MCP side effects to a committed tool result, external idempotency or exactly-once delivery. A transcript append, normalized tool-pairing error, or `/rewind` suggestion is not such a transaction. The report does not claim these mechanisms are absent from every Claude version or unexamined path.

## Delegation and worktree sub-state machines

**Source-verified; D-01–D-12, [delegation report](../wave1/delegation.md).** Agent invocation resolves fork/definition/named teammate, model, tool set, permission context and optional worktree. Foreground streams finish synchronously; background launch returns a handle and later local states include completed, killed or failed. These states are not proof of task success. Named teams have an opt-in/feature gate; schema visibility alone does not establish account availability.

Teams store config, task JSON and mailbox files. Task creation locks ID allocation; automatic claim checks owner/completion/blockers under a lock, then transitions status separately. Ordinary TaskUpdate does not use the same claim protocol. Mailbox appends/mark-read use locks, but read and mark-read are separate, and the append helper catches errors. Shutdown request/approval/rejection is a concrete message protocol; a helper's normal return is not end-to-end delivery confirmation. TeamDelete uses member state and cleanup helpers. **Unknown:** global ownership transactionality, reliable/once-only message delivery, stale-state recovery and crash safety.

Agent worktrees and interactive EnterWorktree/ExitWorktree have different callers. `An6`/`Ap1` create/reuse; unchanged Git worktrees can be removed, changed worktrees retained, and hook-backed agent worktrees retained. Cleanup may log removal failure and clear metadata/state, leaving an orphan risk. Exact failure behavior is source evidence, not an experimentally induced failure here. No research command creates a worktree in DaVinci.

## Controlled observations

**Experimentally observed; pinned 2.1.80, local simulated Messages API.** Fifteen scenarios are indexed in [canonical experiment evidence](../evidence/experiments/INDEX.md). EXP-01–14 use `runs/rerun-final`; EXP-15 uses `runs/rerun-memory`. Fourteen invocations exited0; the malformed-stream invocation exited1. These are recorded outcomes, not fifteen passing automated assertions. The harness does not automatically assert every scenario. Earlier harness/configuration attempts remain retained and are not substituted for the authoritative runset.

| State or request property | Retained observation | Interpretation boundary |
|---|---|---|
| Ordinary text / tool continuation | EXP-01 emitted final text in one request; EXP-02 sent matching fixture Read tool_result in a second request. | Scripted provider behavior; no model task ability measured. |
| Turn-limit boundary | EXP-03 Read and EXP-05 fixture Write ran before `error_max_turns`; exit0, `is_error:false`, `num_turns:2`, no second request. | A zero process exit or false error flag is insufficient task-success evidence. |
| Permission boundary | EXP-04 `dontAsk` denied fixture Write, sent an error tool_result and recorded denial; target file remained absent. | One tool/mode/input, not exhaustive permission validation. |
| Recovery / stop metadata | EXP-06 output max_tokens caused a second request; EXP-07 absent stop_reason emitted success/null; EXP-08 contradictory end_turn plus tool_use still executed Read. | Synthetic protocol inputs support the client-state distinction; backend behavior remains untested. |
| Tool scheduling | EXP-05 returned both reads and performed the controlled Write. | No start/end timing instrumentation; parallelism/barrier timing remains source-verified only. |
| Prompt replacement | EXP-09–11 captured default/custom/append; EXP-13 empty custom suppressed default application instructions while internal headers and user reminders remained. | Print/headless path only; interactive precedence is separately source-verified. |
| Project memory | EXP-12 with empty settings sources omitted CLAUDE.md; EXP-15 with project sources included its marker in user messages, not wire system. | Controlled source selection, not all memory/trust branches. |
| Cache shape | Captures include selected ephemeral annotations and an unannotated billing block. | Request annotations do not measure backend cache reads, TTL granted or savings. |
| Compound malformed stream | EXP-14 omitted the required message object from message_start and also sent broken event JSON; exit1, `.usage` error, one request. AUD-STREAM-A reproduced that failure with only the missing message object. | The original first event was not valid. Exact thrown access remains inferred without a stack trace. |
| Stream fallback differential | AUD-STREAM-B used a valid message_start followed by broken JSON: second request was non-streaming, exit0 with final text. AUD-STREAM-C valid SSE control used one request and exited0. | Experimentally observed fallback for that malformed-JSON shape; no general recovery guarantee follows. |

The local provider supplies synthetic usage; CLI cost/usage fields derived from it are not actual spend or measured efficiency. No live authenticated model request or task-quality benchmark was run. Isolated child configuration and loopback provider settings bound the fixtures; no comprehensive packet capture establishes all ancillary network activity. Interactive prompt approval, enabled teams, worktree cleanup fault injection, timed scheduling and production cache behavior remain untested.

**Source-verified plus inferred boundary.** `$Eq` reads optional `J8.message?.usage` before yielding stream events; `uFq.submitMessage` reads `W6.event.message.usage` without that guard (P:546214–546219,606988–606990). The missing-object control is consistent with an exception in this outer consumer, outside the adapter fallback. That exact thrown origin is **inferred**, not instrumented. See [independent audit AUD-01](../wave3/audit.md) and its retained controls.

## Comparison and recommendation boundary

**Source-verified; DaVinci commit `53e999a7fc24c721c484a710093eeeff611641bf`.** The Rust runtime is not missing the general mechanisms present in Claude. Its active turn flow is `Agent::run_loop_body` → provider request/completion → stop/tool-call normalization → no-tool completion gates or `execute_tool_batch` → policy/contract/intent admission → lane scheduling → dispatch-boundary authorization/effect permit → result persistence → transcript delivery → next model turn or `finish_run`. See [the full comparison](../wave3/comparison.md) and [indexed Rust excerpts](../evidence/comparison/source_index.json) for exact inclusive spans and file hashes. In the compact table, unqualified Rust paths resolve under `/workspace/davinci/crates/davinci-agent/src`; `main.rs` resolves under `/workspace/davinci/crates/davinci-coding-agent/src`; `davinci-ai/src/...` resolves under `/workspace/davinci/crates`.

| Domain | Verified Rust mechanism and transition | Comparison implication |
|---|---|---|
| Loop/completion | `turn.rs:333–489,694–1054` `run_loop_body`; `prompt/capabilities/gate.rs:79–125` `evaluate_completion`; `completion.rs:246–435` requirement/hook queues. Tool results continue; no-tool answers can trigger bounded reminders/verification. | These are active host checks, not just prompts. Neither runtime's terminal record proves task correctness. CMP-01. |
| Turn-limit terminal contract | `turn.rs:405–428` emits/persists an assistant notice, calls `finish_run`; `events.rs:43–48` `AgentEnd` lacks a reason. `main.rs:4476–4537,2693–2778` print/worker consumers can classify nonempty zero-exit output as completion. | **Inferred risk:** an exhausted worker can be treated as completed. Typed outcomes should preserve natural completion on the last allowed turn, side-effect history and cancellation. CMP-02; REC-01. |
| Scheduling | `scheduler.rs:70–87,147–285` `lane_for_capability`, `run_lanes_with_cancel`, `run_group`; `turn.rs:1496–1618,1769–1806` batch/route integration. Missing capability fails serial; safe lanes refill with cap8; shared writers/effect claims serialize. | Existing bounded scheduling should remain. Claude's optional streaming overlap introduces a different fallback/effect window; no comparative timing benchmark supports replacing either scheduler. CMP-04. |
| Permissions and dispatch | `turn.rs:1969–2371,3000–3135,3954–4215` preparation, permission, revision recheck and final dispatch. Denied/unstarted work does not receive an effect permit. | Preserve authority revalidation and committed-result markers. A visible schema, model instruction or safe lane cannot authorize an effect. CMP-05. |
| Persistence/recovery | `runtime/operations/adapters/tools.rs:60–299` `ToolOperationDispatcher` intent→authorize/queue→dispatch→commit/outbox; `tool_ledger.rs:762–924` reserve/begin integration. | Active journal/ledger integration is distinct from helper-only recovery. Located direct callers of `recover_attempt` and `RecoveryEngine::reduce/run_authorized` are tests; do not claim universal automatic repair. Arbitrary external effects are not atomic with the journal. CMP-06. |
| Context | `compaction.rs:133–413` accounting/cut/summary; `lib.rs:3792–4180` fold/compact/commit; `turn.rs:482–645,694–713` mode selection and bounded overflow recovery. | Persistence precedes live history replacement on these paths. Context VM Off/Shadow/Active/Hybrid are conditional; comparative summary accuracy and current mode remain unknown. CMP-07. |
| Prompts/cache | `prompt/session.rs:131–240`, `prompt/turn.rs:19–144`, `turn_context.rs:29–41,92–161`, `lib.rs:1704–1796,2672–2682` compose stable/appended/project context. `cache_stability.rs:18–69` checks prefixes. | Custom application prompts still receive other context. Offline prefix equality, native replay and backend cache hits are three different claims. Do not copy Anthropic headers/TTL into the Codex subscription route. CMP-08/09. |
| Provider continuation | `davinci-ai/src/stream.rs:978–1172,1692–1735,2179–2245`; `codex.rs:472–653,742–816` backend continuation; separate public websocket selection. | Actual call-site route gates outrank capability structs/comments. Public-plan constraints strip unsupported stored-continuation/cache fields; no API-key fallback or backend capability was enabled by this research. CMP-09. |
| Delegation/tasks | `subagent.rs:701–1218`; `main.rs:2460–2778` worker construction; `runtime/team.rs:407–484`, `mailbox.rs:231–369,615–750`, `tasks.rs:922–1048,1465–1625`. Scoped children, authority intersections, receipts/revisions and lifecycle events. | These are existing coordination mechanisms. Claude's implicit parent fork differs from DaVinci's scoped worker; neither is a measured task-quality advantage. CMP-10. |
| Worktree cleanup | `runtime/worktree.rs:285–389` dirty checks and `release_lease`. Removal/fallback errors can be ignored before dropping lease/emitting removed. | **Inferred risk:** orphan state and misleading cleanup success. Retain dirty-state protections and truthful ownership until verified removal. CMP-11; REC-02. |

### Prioritized decisions

1. **REC-01, high:** make terminal outcomes explicit across Agent/CLI/RPC/worker consumers. The source gap is the reasonless terminal contract, not absence of a turn limit or verification gates.
2. **REC-02, high:** make worktree cleanup return truthful partial/failure state and retain recoverable tracking until removal is verified. Do not force-delete dirty work or reproduce Claude's ignored cleanup result.
3. **REC-03, medium/conditional:** evaluate bounded text-only output continuation after fixing terminal/exit consumers. DaVinci already rejects partial tool dispatch and reports output-limit failure in print mode; any continuation must preserve those protections and not leave a recovered old Length event controlling final status.
4. **REC-04, measurement gate:** run a separately authorized, pinned, route-specific benchmark before changing prompt/context/delegation defaults or asserting savings. Reuse existing offline checks, preserve model/effort, and record task success/required-information recall, actual attempts, fresh/cached/output tokens, latency, failures and available subscription windows separately.

The detailed scopes, source anchors, validation scenarios, risks and acceptance gates are in [prioritized recommendations](RECOMMENDATIONS.md). These are future-work proposals; no implementation or live benchmark is part of this research phase. Expected engineering benefit is **inferred**; measured comparative task success, savings and production frequencies remain **unknown**.

## Evidence access and reproduction

Start with [the research index](../README.md), [artifact manifest](../evidence/artifact-manifest.json), [canonical CLI captures](../evidence/experiments/INDEX.md), [independent audit](../wave3/audit.md) and [contradiction resolutions](CONTRADICTIONS.md). Every specialist report has actual function identifiers, source locations, transitions and reproduction anchors. Descriptive excerpt labels are explicitly separate from source names; no unpublished original module tree is invented.

The main fixture runner now writes unique reproduction directories and refuses to overwrite them. Run from `/workspace`:

```sh
python3 /workspace/research/claude-davinci/scripts/artifact_manifest.py
node /workspace/research/claude-davinci/scripts/experiment_fixture.js EXP-12,EXP-13,EXP-15
```

This rechecks identity and reproduces the memory-selection controls against an owned simulated provider; it is not a real model task benchmark. The canonical evidence and initial audit snapshot remain retained. No DaVinci source changes, installed-binary replacement, account login, paid API setup or live provider benchmark were performed.
