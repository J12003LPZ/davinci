# Prioritized recommendations for DaVinci

These are research-phase proposals for Rust commit `53e999a7fc24c721c484a710093eeeff611641bf`, not implemented changes. The comparison target is official Claude Code npm2.1.80. Native2.1.302 parity, comparative task quality and subscription savings are unknown.

The lead's decision is to retain DaVinci's existing authority, scheduling, journal, completion-evidence and request-prefix mechanisms. Prioritize truthful terminal and cleanup state before optional recovery or efficiency tuning. Detailed source excerpts and future validation cases are in the independently reviewable [proposal report](../wave3/recommendation-proposals.md) and [Rust evidence index](../evidence/proposals/source_index.json).

| Priority | Recommendation | Evidence and proposed outcome | Dependencies |
|---|---|---|---|
| P1 correctness | REC-01: explicit settled terminal outcomes | A coordinator limit can end with an ordinary assistant notice and reasonless AgentEnd; worker consumers can read nonempty zero-exit output as completed. Distinguish normal loop completion, limits, cancellation and failures. | Preserve event compatibility and host settlement. |
| P1 recoverability | REC-02: truthful worktree cleanup | Removal errors can be ignored before lease deletion and a removed event. Retain identity and partial cleanup state until required postconditions are proven. | Preserve dirty/unreadable-state protection and ownership boundaries. |
| P2 conditional recovery | REC-03: bounded text-only output continuation | Existing decoder/loop already reject partial tool calls and print mode reports Length failure. Evaluate a bounded continuation only for genuinely tool-free text. | REC-01, since earlier recovered Length can still poison current exit handling. |
| Evidence gate before tuning | REC-04: matched route/model/effort benchmark | Source richness, synthetic usage and cache annotations do not prove useful completion or savings. Benchmark one declared treatment with failures and missing accounting retained. | Separately authorized finite live campaign; no API-key fallback. |

## REC-01: explicit terminal state across the Agent and host

**Source-verified problem.** `Agent::run_loop_body`, `/workspace/davinci/crates/davinci-agent/src/turn.rs:402–428`, checks `max_model_turns` before another loop iteration, persists an assistant notice and calls `finish_run`. `AgentEvent::AgentEnd` in `events.rs:43–48` has no terminal reason. `print_text_exit`, `/workspace/davinci/crates/davinci-coding-agent/src/main.rs:4476–4537`, does not classify that notice; `run_worker_turn` at2693–2706 accepts zero exit plus nonempty text. The worker path can then report completed. This is a verified consumer chain; an incorrectly completed real task is **inferred risk**, not experimentally observed here.

The bound counts coordinator turns, not provider attempts inside retry-capable completion. It does not forbid an Nth-turn final answer, and tools from the last admitted response can already have executed before the next iteration is refused. Keep those semantics explicit. `print_text_exit` also scans backward over all MessageUpdate events, so a recovered earlier Length can still yield failure after a later successful answer.

**Proposed scope, not existing code:** add a compatible versioned terminal descriptor and a shared consumer reducer. Represent normal loop completion, model/output limits, abort and provider/persistence/admission/session failures without parsing prose. Treat absent legacy reasons as unknown, not automatically successful. Let the host settle session calls before the single final terminal event; persistence or session failure must override a provisional answer. Preserve earlier failed runs in multi-prompt invocation results. Update print/JSON/RPC, oneshot, multi-worker, async and teammate consumers together.

**Future validation:** deterministic fixtures for cap1+Read, final answer exactly at cap, queued reminder at cap, retries versus counted turns, Length→successful recovery, success→settlement failure, legacy events and each worker consumer. Assert one settled terminal event, no duplicate effect, no task-completed status for an exhausted worker, and retained partial output. Existing tests are source-defined coverage only; no such new tests were run or added during research.

**Inferred benefit:** more truthful status, safer delegation and auditable limits. **Unknown:** incident frequency or task-success gain. Compatibility and failure-precedence regressions are the main implementation risks.

## REC-02: checked cleanup and retained tracking

**Source-verified problem.** `WorktreeManager::release_lease`, `/workspace/davinci/crates/davinci-agent/src/runtime/worktree.rs:327–386`, can discard failures from Git removal, directory fallback and owned-branch deletion, then drop the lease and emit WorktreeRemoved. It can still return errors from other checks; the claim is not that every call returns Ok. `is_dirty/check_dirty` at283–323 already preserve dirty and unreadable Git state and should remain.

Caller semantics differ. `/workspace/davinci/crates/davinci-agent/src/subagent.rs` discards release results in rollback493–513, async1063–1074 and single-worker oneshot1175–1185. The multi-worker branch1261–1277 handles a returned error, but cannot see failures already ignored inside release_lease. **Inferred risk:** an orphan directory/registration/branch without truthful tracking. No worktree-fault experiment or production incidence measurement was run.

**Proposed scope:** check command results and independent directory/Git-registration/owned-branch postconditions. Retain the lease or a cleanup-pending receipt until required postconditions hold; report partial state rather than a blanket preserved/deleted boolean. Propagate it through every caller. Retry only unresolved components owned by the exact lease after fresh safety checks. In-memory retained state improves same-process retry only; crash recovery needs an explicit durable intent/receipt in the existing persistence owner. No broad destructive startup sweep is proposed.

**Future validation:** disposable Git fixtures with dirty/unreadable state, Git-remove failure, directory-remove failure, branch failure after directory success, missing path with stale registration, identity mismatch, idempotent retry and all caller variants. Verify tracking and truthful events after each fault. A durable version must also fault before/after receipt persistence. Preserve explicit force requirements and unrelated branches/files.

**Inferred benefit:** recoverable cleanup and truthful ownership. **Unknown:** platform failure rates and operational savings. Durable-state migration and accidental overbroad deletion are risks to control.

## REC-03: optional bounded recovery for text output limits

**Source-verified difference.** Claude's source and synthetic EXP-06 continue after max_tokens. DaVinci `ResponsesDecoder::finalize`, `/workspace/davinci/crates/davinci-ai/src/stream_decoder.rs:786–884`, and `map_stop_reason:956–991` classify/strip incomplete tool calls. `/workspace/davinci/crates/davinci-agent/src/turn.rs:719–745,805–847` already provides a bounded smaller-tool-call retry when partial calls were dropped. Genuinely text-only Length does not select that branch; print mode already exits nonzero. Do not call it silent print success or missing all truncation recovery.

**Proposed scope:** after REC-01, evaluate an explicitly bounded, initially opt-in continuation for visible tool-free partial text. Persist partial output and the continuation request before another model call; respect turn/request/deadline/cancel limits, ordinary completion gates and provider-native replay rules. Keep Error/Aborted/context-overflow and malformed/dropped tool calls on their existing paths. Never execute a partial call or replay a prior mutation to obtain more text. Preserve an explicit output-limit outcome when disabled/exhausted.

**Future validation:** text Length→Stop, repeated Length budget exhaustion, policy off/zero, cancellation/cap before retry, dropped/raw partial calls, no-text/non-text fragments, persistence failure, retained replay/prefix rules and no repeated prior effect. Test decoder, coordinator and host reducer together. No default change is justified by the one successful Claude fixture.

**Inferred benefit:** salvage some truncated answers. **Unknown:** route-specific frequency, task utility and cost. Extra calls, repeated fragments and misleading completion are material risks. Keep optional until matched evidence supports promotion.

## REC-04: measurement before performance or quality claims

**Source-verified existing capability.** DaVinci already has `cache_stability.rs`, request manifests, native replay, provider telemetry and `scripts/bench/bench.py`. Its route gates distinguish public-plan and marked backend paths; public-plan constraints strip unsupported stored-continuation/cache shapes. Native replay, warm transport and provider cache reuse are separate contracts. This research did not re-run historical route probes or a live task benchmark.

The current strict `scripts/bench/subscription_campaign.py::prepare` at13–41 hard-pins `gpt-6-luna/high`, one arm, SSE and no retries. It cannot honor arbitrary selected models or benchmark ordinary WebSocket/backend behavior simply by changing an environment value. Do not silently downgrade the user's model/effort or bypass admission. Any future exact-pin/route extension must retain finite budgets and auth/cleanup checks.

**Future measurement plan:** freeze baseline/candidate source and binary hashes, fixtures, settings, prompt/tool projection, context mode, route/transport, exact model/effort and finite task/request/time budgets. Run offline conformance first. A separately requested live campaign uses the existing subscription route without API-key fallback, one declared treatment at a time, matched tasks/order and independent task checks. Keep failures, limits, denials, timeouts, unknown accounting and cleanup failures in denominators.

Report task correctness and retained-information recall alongside actual attempts, fresh/cached/output tokens, latency, retry/continuation/reminder counts and available subscription windows. Missing telemetry stays unknown. The local fixture's usage/cost fields are synthetic, not spend or savings. A passing public screening fixture is not a protected holdout; a small diagnostic sample is not a general success-rate claim.

**Decision:** deterministic status/cleanup fixes can proceed as a separately authorized coding task. Efficiency-driven prompt/context/team changes and REC-03 promotion should wait for the declared matched evaluation. No model-quality, task-success or savings improvement is claimed here.

## Preserved boundaries

- Keep capability-driven serial barriers, dispatch-time policy revisions, durable intent/effect/result evidence, completion-evidence gates and scoped worker authority.
- Preserve the user's Codex subscription route and explicit model/effort; no paid API setup or fallback.
- Do not copy dormant Claude microcompaction/reactive branches, unbounded streaming concurrency or ignored cleanup/mailbox errors.
- Do not infer exactly-once arbitrary external effects, real cache hits or native2.1.302 parity from this research.

The [runtime specification](RUNTIME_SPEC.md), [comparison](../wave3/comparison.md), [independent audit](../wave3/audit.md) and [resolution register](CONTRADICTIONS.md) provide the evidence chain. Proposed types/states/test cases in the detailed report are explicitly future designs, not invented existing implementation.
