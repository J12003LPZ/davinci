"""Prepare review-fix trees on a disposable runner; never change remote refs."""
from __future__ import annotations
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import urllib.request

REPO = 'J12003LPZ/davinci'
HEADS = {'pr84': 'b30783f610597f8448a35097ef5e1ad4c55e509d', 'pr85': '06bc2f8aa93fee58568cd37fe68ef5a6d24810e3', 'pr86': 'a7a59af4cc2781296c1f69f7dc214da784790bce'}
ROOT = Path(os.environ['RUNNER_TEMP']) / 'davinci-review-prepared'
SOURCE = Path(__file__).resolve().parent

def git(*args: str, cwd: Path | None = None) -> str:
    return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()

def run(*args: str, cwd: Path) -> None:
    subprocess.run(args, cwd=cwd, check=True)

def apply(work: Path, changes: list[dict], groups: set[str]) -> list[str]:
    outputs = {}
    for change in changes:
        if change['group'] not in groups:
            continue
        relative = change['path']
        path = work / relative
        if not path.resolve().is_relative_to(work.resolve()) or path.is_symlink():
            raise RuntimeError(f'Unsafe source path: {relative}')
        if 'create' in change:
            if path.exists() or relative in outputs:
                raise RuntimeError(f'New file already exists: {relative}')
            outputs[relative] = change['create']
            continue
        source = outputs.get(relative)
        if source is None:
            source = path.read_text(encoding='utf-8')
        before = change['before']
        if source.count(before) != 1:
            raise RuntimeError(f'Expected one exact source anchor in {relative}')
        outputs[relative] = source.replace(before, change['after'], 1)
    for relative, content in outputs.items():
        path = work / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8')
    rust = [path for path in outputs if path.endswith('.rs')]
    if rust:
        run('rustfmt', '--edition', '2021', '--config', 'skip_children=true', *rust, cwd=work)
    run('git', 'diff', '--check', cwd=work)
    return list(outputs)

def prepare() -> None:
    ROOT.mkdir(parents=True, exist_ok=False)
    changes = json.loads((SOURCE / 'review_changes.json').read_text())
    for sha in HEADS.values():
        run('git', 'fetch', '--no-tags', '--depth=100', 'origin', sha, cwd=Path.cwd())
    manifests = []
    for group in ('pr85', 'pr86', 'integration'):
        work = ROOT / group
        base = HEADS['pr84'] if group == 'integration' else HEADS[group]
        run('git', 'worktree', 'add', '--detach', str(work), base, cwd=Path.cwd())
        run('git', 'config', 'user.name', 'Review preparation', cwd=work)
        run('git', 'config', 'user.email', 'review-preparation@users.noreply.github.com', cwd=work)
        if group == 'integration':
            for dependency in ('pr85', 'pr86'):
                run('git', '-c', 'core.hooksPath=/dev/null', 'merge', '--no-ff', '--no-edit', HEADS[dependency], cwd=work)
            groups = {'pr85', 'pr86', 'integration'}
        else:
            groups = {group}
        patched = apply(work, changes, groups)
        run('git', 'add', '--', *patched, cwd=work)
        paths = git('diff', '--cached', '--name-only', cwd=work).splitlines()
        if set(paths) != set(patched):
            raise RuntimeError(f'Unexpected edits for {group}: {paths}')
        if group == 'integration':
            paths = git('diff', '--cached', '--name-only', base, cwd=work).splitlines()
        entries = []
        for path in paths:
            index = git('ls-files', '--stage', '--', path, cwd=work)
            if not index:
                entries.append({'path': path, 'mode': '100644', 'type': 'blob', 'sha': None})
                continue
            mode, sha, _ = index.split(None, 2)
            entry = {'path': path, 'mode': mode, 'type': 'blob', 'sha': sha}
            if path in patched:
                data = (work / path).read_bytes()
                expected = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
                if expected != sha:
                    raise RuntimeError(f'Index/content mismatch: {path}')
                entry['local_file'] = str(work / path)
            entries.append(entry)
        manifest = {'group': group, 'parent': base, 'base_tree': git('rev-parse', f'{base}^{{tree}}', cwd=work), 'entries': entries, 'patched': patched}
        manifests.append(manifest)
        print(f'PREPARED {group}: {len(patched)} patched source files; {len(entries)} tree entries', flush=True)
    (ROOT / 'manifest.json').write_text(json.dumps(manifests, indent=2))

def api(path: str, payload: dict) -> dict:
    request = urllib.request.Request(f'https://api.github.com/repos/{REPO}/{path}', data=json.dumps(payload).encode(), headers={'Authorization': 'Bearer ' + os.environ['GH_TOKEN'], 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json', 'X-GitHub-Api-Version': '2022-11-28'}, method='POST')
    with urllib.request.urlopen(request, timeout=60) as response:
        return json.load(response)

def upload() -> None:
    # Upload immutable Git objects only. The GitHub plugin performs all commits
    # and branch updates after review, using non-force fast-forward writes.
    manifests = json.loads((ROOT / 'manifest.json').read_text())
    uploaded = set()
    results = []
    for manifest in manifests:
        entries = []
        for entry in manifest['entries']:
            entry = dict(entry)
            local_file = entry.pop('local_file', None)
            if local_file and entry['sha'] not in uploaded:
                data = Path(local_file).read_bytes()
                blob = api('git/blobs', {'content': base64.b64encode(data).decode(), 'encoding': 'base64'})
                if blob['sha'] != entry['sha']:
                    raise RuntimeError('Uploaded blob hash mismatch')
                uploaded.add(blob['sha'])
            entries.append(entry)
        tree = api('git/trees', {'base_tree': manifest['base_tree'], 'tree': entries})
        result = {'group': manifest['group'], 'parent': manifest['parent'], 'tree': tree['sha'], 'patched': manifest['patched']}
        results.append(result)
        print('PREPARED_TREE ' + json.dumps(result), flush=True)
    (ROOT / 'trees.json').write_text(json.dumps(results, indent=2))
    with open(os.environ['GITHUB_STEP_SUMMARY'], 'a') as summary:
        summary.write('## Prepared immutable trees (no branch updates)\n\n```json\n' + json.dumps(results, indent=2) + '\n```\n')

if __name__ == '__main__':
    if sys.argv[1:] == ['prepare']:
        prepare()
    elif sys.argv[1:] == ['upload']:
        upload()
    else:
        raise SystemExit('Expected prepare or upload')
